# Provisioning the SharePoint site

`Provision-IntakeSite.ps1` creates everything the canvas rebuild needs on an existing SharePoint site:

- **14 lists**:
  - Configuration: IntakeTeams, IntakeTeamMembers, IntakeSubTeams, IntakeRequestTypes, IntakeQuestions, IntakeQuestionRules, IntakeQAConfig, IntakeTransitions.
  - Transactions: IntakeRequests, IntakeTasks, IntakeWorkPackages, IntakeAnswers, IntakeInternalAnswers, IntakeActivity.
- **All columns**, copied from the proof-of-concept schema. Three changes from the POC:
  - Answers move from JSON columns to the two answer lists.
  - Activity moves to the IntakeActivity list.
  - Legacy columns are dropped.
- **Indexes** on every column used in filters.
- **Configuration rows** from the POC:
  - 13 teams, 5 sub-teams, 18 request types, 23 questions, 26 question rules and 2 QA rules;
  - 30 stage transitions.
- **Permission groups** (Intake Requestors, Team Members, Managers, Admins):
  - "own items only" on IntakeRequests and IntakeAnswers;
  - restricted IntakeInternalAnswers;
  - read-only IntakeActivity.

## Before you run it
1. Install PowerShell 7.2+ and PnP.PowerShell 2.x: `Install-Module PnP.PowerShell -Scope CurrentUser`.
2. Have an Entra app registration for PnP interactive sign-in. Your admin may already have one; you pass its client ID.
3. Create the target site (team or communication site) and make sure you are a Site Owner.
4. Open the script and review the **seed values**. Manager names and emails in IntakeTeams, and sub-team leads in IntakeSubTeams, are POC demo people. Replace them, or edit the lists after the run.

## Run
```powershell
./Provision-IntakeSite.ps1 -SiteUrl https://<tenant>.sharepoint.com/sites/<site> -ClientId <app-registration-id> -EmailDomain <your-domain.com>
```
Options:
- `-SkipSeed` creates the structure only.
- `-ReseedConfig` adds config rows even if a list already has rows.
- `-SkipPermissions` leaves permissions to your admin.

The script is safe to re-run: existing lists, columns and seeded lists are skipped.

## After the run
- Add your flow service account to **Intake Admins**.
- Add people to IntakeTeamMembers, and add requestors to Intake Requestors (or grant all staff).
- Give the Team Members and Managers groups a permission level that includes **Override List Behaviors**. Without it, the "own items only" settings also hide other people's intakes from them.
- Continue with `02-prompts/S01-app-setup-shell-roles.md`.
