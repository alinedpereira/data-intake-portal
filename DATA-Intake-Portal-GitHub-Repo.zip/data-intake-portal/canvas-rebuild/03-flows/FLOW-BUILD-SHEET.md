# Flow build sheet – D.A.T.A. Intake Portal (Power Automate)

Build every flow **inside the same solution** as the canvas app, using **connection references** owned by a service account, and **environment variables** for anything that differs between environments.

## Environment variables
| Name | Example | Used by |
|---|---|---|
| `env_SiteUrl` | https://contoso.sharepoint.com/sites/intake-requests | all |
| `env_AppUrl` | Power Apps play link for the app | links in emails and cards |
| `env_DmlTeam` | P&BB DMO | F2, F7 (which team's manager is the DML) |
| `env_StalledDays` | 7 | F8 |
| `env_AdminEmail` | intake-admins@contoso.com | failure alerts |

## Flow map
| ID | Name (no spaces) | Trigger | Called by |
|---|---|---|---|
| C1 | `IntakeAppendActivity` | Manually trigger a flow (child) | every flow |
| C2 | `IntakeStageEngine` | Manually trigger a flow (child) | F2, F5, F7 |
| F1 | `IntakeProcessSubmission` | Power Apps (V2) | New Intake submit (S03) |
| F2 | `IntakeChangeStage` | Power Apps (V2) | every stage/assign/re-route button (S05–S07, S10) |
| F3 | `IntakeAnswersChanged` | Power Apps (V2) | edit dialog, internal details, prioritization (S06, S10) |
| F4 | `IntakeWorkPackageChange` | Power Apps (V2) | work package actions (S08) |
| F5 | `IntakeTaskUpdated` | SharePoint – When an item is created or modified (IntakeTasks) | automatic |
| F6 | `IntakeAskRequestor` | Power Apps (V2) | ask / answer / comment / log (S05–S07) |
| F7 | `IntakeDmlApproval` | Manually trigger a flow (child) | C2 when an intake enters DML Approval |
| F8 | `IntakeDailyDigest` | Recurrence (weekdays 07:00) | automatic |
| H1 | `IntakeListFiles` | Power Apps (V2) | files galleries (S05, S08) |

Standard pattern for every flow: **Scope "Try"** → actions; **Scope "Catch"** (Configure run after: has failed / timed out) → Send an email to `env_AdminEmail` with the flow run link `concat('https://make.powerautomate.com/environments/', workflow()?['tags']?['environmentName'], '/flows/', workflow()?['name'], '/runs/', workflow()?['run']?['name'])` → Respond to a PowerApp with ok = "false".

Power Apps (V2) outputs must be text/number/boolean; return arrays as JSON text and use `ParseJSON` in the app.

---

## C1 `IntakeAppendActivity` (child)
**Inputs:** RequestItemId (number), WorkPackageId (number, 0 if none), TaskId (number, 0), EntryText (text), ActorName (text), ActorRole (text), IsInternal (yes/no)
1. **Create item** – IntakeActivity: Title = `substring(EntryText, 0, min(length(EntryText), 250))`, RequestItemId, WorkPackageId, TaskId, EntryText, ActorName, ActorRole, IsInternal.
2. **Respond to a PowerApp or flow** – ok = "true".

> Copilot in Power Automate: *"Create a child flow with a manual trigger taking RequestItemId, WorkPackageId, TaskId, EntryText, ActorName, ActorRole and IsInternal, that creates an item in the SharePoint list IntakeActivity and responds ok = true."*

---

## F1 `IntakeProcessSubmission`
**Inputs:** IntakeId (number). **Outputs:** requestnumber (text), ok, message.
1. **Get item** – IntakeRequests, Id = IntakeId.
2. **Compose RequestNumber**
   ```
   concat('INT-', formatDateTime(utcNow(), 'yyyyMMdd'), '-',
     substring(concat('00000', string(triggerBody()['number'])), length(string(triggerBody()['number'])), 5))
   ```
3. **Routing fallback** – Condition `empty(body('Get_item')?['RoutedTeam']?['Value'])`:
   - Get items IntakeRequestTypes, Filter Query `Level1 eq '@{body('Get_item')?['RequestTypeL1']?['Value']}' and Title eq '@{body('Get_item')?['RequestTypeL2']}'`, Top 1.
   - If `first(...)?['AskFocusArea']` → Get items IntakeTeams `FocusArea eq '@{body('Get_item')?['AnalyticsDomain']?['Value']}'`; team = its Title. Else team = `first(...)?['DefaultTeam']`.
   - Set variable `Team` (string).
4. **Score** (only if the team has scored rules):
   - Get items IntakeQuestionRules `Team eq '@{variables('Team')}' and IsScored eq 1 and IsActive eq 1`.
   - **Filter array** rules where L1/L2 match or are blank:
     `@and(or(empty(item()?['RequestTypeL1']), equals(item()?['RequestTypeL1'], body('Get_item')?['RequestTypeL1']?['Value'])), or(empty(item()?['RequestTypeL2']), equals(item()?['RequestTypeL2'], body('Get_item')?['RequestTypeL2'])))`
   - **Select** `ScoredKeys` = `item()?['QuestionKey']`.
   - Get items IntakeAnswers `RequestItemId eq @{triggerBody()['number']}`.
   - **Filter array** answers where `contains(body('Select_ScoredKeys'), item()?['QuestionKey'])` and `not(empty(item()?['Points']))`.
   - Initialize variable Score (float) 0; **Apply to each** filtered answer → Increment variable by `float(item()?['Points'])`.
   - Score is valid only if `equals(length(body('Filter_answers')), length(union(body('Select_ScoredKeys'), json('[]'))))`; otherwise leave blank.
5. **Update item** IntakeRequests: Title = existing Title (required by the action), RequestNumber, RoutedTeam Value = Team, Status Value = `Submitted`, RequestStatus Value = `Submitted`, BacklogScore = score or null.
6. **Create new folder** – Documents library, path = RequestNumber.
7. **QA task** – Get items IntakeQAConfig `Level1 eq '…' and Level2 eq '…' and RequiresQA eq 1`; if any → Create item IntakeTasks: Title "QA testing", RequestItemId, RequestNumber, RequestTitle, WorkPackageId 0, TaskType "QA/Testing", TaskStatus "Not started".
8. **Run child flow C1** – "Intake submitted", ActorRole Requestor.
9. **Notify** – Get items IntakeTeams `Title eq Team` → Post adaptive card in a chat with Flow bot to ManagerEmail ("New intake {number}: {title}", priority, needed by, button Open → `concat(parameters('env_AppUrl'), '?intakeId=', triggerBody()['number'])`). Send an email (V2) to the requestor confirming the number.
10. **Respond to a PowerApp** – requestnumber = RequestNumber, ok = "true".

**Test:** submit an OMP intake with >$20MM and Existing pattern → number assigned, Status Submitted, BacklogScore 4, folder created, manager card received.

---

## C2 `IntakeStageEngine` (child) and F2 `IntakeChangeStage` (Power Apps wrapper)
F2 has the same inputs and simply runs C2 and returns its response, so F5 and F7 can reuse the engine.
**Inputs:** IntakeId (number), Action (text: Move | Assign | Reroute), Target (text: stage, owner email, or team), Reason (text), ActorEmail (text; "system" for automation). **Outputs:** ok, message.

1. **Get item** IntakeRequests.
2. **Variables:** `Current` = Status Value; `Lifecycle` = `if(and(equals(RequestTypeL1,'Data Risk Assessment'), equals(RequestTypeL2,'IAAP Request')), 'IAAP', 'Standard')`; `ActorRoles` (array) = [].
3. **Actor roles** (append to ActorRoles):
   - `system` → "System".
   - Get items IntakeTeams `Title eq '{RoutedTeam}' and ManagerEmail eq '{ActorEmail}'` → if any, "Manager".
   - Get items IntakeTeams `Title eq '{env_DmlTeam}' and ManagerEmail eq '{ActorEmail}'` → if any, "DML".
   - `equals(toLower(Owner Email), toLower(ActorEmail))` → "Owner".
   - `equals(toLower(Requestor Email), toLower(ActorEmail))` → "Requestor".
4. **Switch on Action**
   - **Move**
     1. Get items IntakeTransitions `FromStage eq '{Current}' and ToStage eq '{Target}' and IsActive eq 1`.
     2. Filter array: `@and(or(equals(item()?['Lifecycle']?['Value'],'Any'), equals(item()?['Lifecycle']?['Value'], variables('Lifecycle'))), contains(variables('ActorRoles'), item()?['AllowedRole']?['Value']))`
     3. If empty → Respond ok "false", message `concat('You cannot move this intake from ', Current, ' to ', Target, '.')`. Terminate.
     4. If `first(body('Filter_array'))?['ReasonRequired']` and `empty(Reason)` → Respond ok "false", "A reason is required."
     5. **Update item**: Status = Target; RequestStatus = `first(body('Filter_array'))?['RequestStatus']`; RequirementsSignedOff = true when Current = 'Requirements sign-off' and Target = 'Approved'; AcceptanceSignedOff = true when Current = 'Acceptance sign-off' and Target = 'Closed'.
     6. **Entry text** (Compose):
        ```
        if(and(contains(variables('ActorRoles'),'Requestor'), equals(variables('Current'),'Requirements sign-off'), equals(Target,'Approved')), 'Requirements signed off',
        if(and(contains(variables('ActorRoles'),'Requestor'), equals(variables('Current'),'Acceptance sign-off'), equals(Target,'Closed')), 'Work accepted and closed',
        if(not(empty(Reason)), concat('Moved to ', Target, ': ', Reason), concat('Moved to ', Target))))
        ```
        (Send-backs read "Moved to Assigned / Under Review: <reason>"; adjust wording to taste.)
     7. Run C1. Notify per the matrix below.
     8. If Target = 'DML Approval' → Run child F7 (F7 responds immediately, then waits for the approval).
   - **Assign** (allowed for Manager)
     1. Get user profile (V2) for Target.
     2. New status: if Current in (Submitted, Queued) → 'In Progress' when Lifecycle = IAAP, else 'Assigned / Under Review'; otherwise keep Current. RequestStatus from the matching IntakeTransitions row.
     3. Update item: Owner Claims = Target, Status, RequestStatus.
     4. C1: `concat('Owner set to ', displayName, if(changed, concat('; moved to ', newStatus), ''))`. Notify the owner (Teams) and the requestor (email).
   - **Reroute** (Manager, reason required)
     1. Update item: RoutedTeam = Target; if Current is a pre-work stage (Submitted, Queued, Assigned / Under Review, Requirements sign-off, Approved) → Status Queued, RequestStatus Queued.
     2. Clear Owner with **Send an HTTP request to SharePoint**: POST `_api/web/lists/getbytitle('IntakeRequests')/items(@{IntakeId})`, headers `X-HTTP-Method: MERGE`, `IF-MATCH: *`, `Content-Type: application/json;odata=nometadata`, body `{"OwnerId": null}`.
     3. C1: `concat('Re-routed from ', oldTeam, ' to ', Target, ': ', Reason)`. Notify the new team's manager.
5. **Respond** ok "true".

**Tests:** requestor cannot move to In Progress; owner moves Assigned → Requirements sign-off; requestor sends back without a reason (refused) and with a reason (accepted); manager reopens Closed with a reason; IAAP assign goes straight to In Progress.

---

## F3 `IntakeAnswersChanged`
**Inputs:** IntakeId, Audience (Requestor | Internal), ChangeText, ActorEmail, ScoreOverride (number; −1 = recalculate). **Outputs:** ok, score.
1. Get item IntakeRequests; Get user profile (V2) for ActorEmail; work out ActorRole as in C2.
2. Run C1 with EntryText = ChangeText, IsInternal = `equals(Audience, 'Internal')`.
3. If Audience = Requestor: score = ScoreOverride when ≥ 0, else recalculate exactly as F1 step 4. If the score changed, Update item BacklogScore and Run C1 `concat('Score recalculated to ', score)` (or "set to … (override)").
4. Respond ok "true", score.

---

## F4 `IntakeWorkPackageChange`
**Inputs:** Id (number: work package ID, or the **intake** ID when Action = Create), Action (Create | Update | Remove | Move | Comment), Target (text: status for Move, JSON of fields for Create/Update, comment text for Comment), Reason, ActorEmail.
1. **Create**: Parse JSON Target → Get items IntakeWorkPackages `RequestItemId eq Id` (to compute SortOrder = count + 1) → Create item (Title, WPDescription, SubTeam, WPOwner Claims = OwnerEmail, WPDueDate, WPPriority, WPStatus "Not started", RequestItemId, RequestNumber, SortOrder) → Create new folder `RequestNumber/WP-{new ID}` → C1 on the package ("Work package created") **and** on the intake (`concat('Work package "', Title, '" created')`) → notify the package owner.
2. **Move**: Get the package and its intake. Allowed: owner or manager for Requirements / In progress / QA/Review / Ready for acceptance; requestor only for Accepted or Sent back when the package is Ready for acceptance (reason required for Sent back). Update WPStatus. C1 on the package. **Also log on the intake** only when Target is Ready for acceptance (`… sent for the requestor's acceptance`), Accepted (`… accepted (complete)`), or Sent back (`… sent back by requestor: <reason>`). Notify: requestor on Ready for acceptance; owner on Sent back. After Accepted: Get items `RequestItemId eq X and WPStatus ne 'Accepted'`; if none → Teams message to the manager "All work packages accepted; close the intake."
3. **Update**: Parse JSON → Update item → C1 on the package only ("Details updated: …").
4. **Remove** (manager): Delete item (and tasks with that WorkPackageId) → C1 on the intake (`Work package "…" removed`).
5. **Comment**: C1 on the package only.
6. Respond ok.

---

## F5 `IntakeTaskUpdated`
**Trigger:** SharePoint – When an item is created or modified (IntakeTasks). **Trigger conditions:**
```
@equals(triggerBody()?['TaskType']?['Value'], 'QA/Testing')
@equals(triggerBody()?['TaskStatus']?['Value'], 'In progress')
@or(equals(triggerBody()?['WorkPackageId'], null), equals(triggerBody()?['WorkPackageId'], 0))
```
1. **Get changes for an item or a file (properties only)** since `triggerOutputs()?['body/{TriggerWindowStartToken}']`; continue only if `body('Get_changes')?['ColumnHasChanged']?['TaskStatus']`.
2. Get item IntakeRequests (RequestItemId). If Status = In Progress → Run child C2 with Action Move, Target "QA Testing", ActorEmail "system".
3. Run C1 on the intake: "QA testing started (task …)".

Add a second, untriggered-condition branch (or a separate flow) to notify the assignee when AssignedTo changes.

---

## F6 `IntakeAskRequestor`
**Inputs:** IntakeId, Mode (Ask | Answer | Comment | Log), Text, ActorEmail.
- **Ask** (owner/manager): Update item AwaitingRequestor = true, OpenQuestion = Text, QuestionAskedBy = actor name, QuestionAskedOn = utcNow(), RequestorAnswer = null → C1 "Question for the requestor: …" → email + Teams to the requestor with the app link.
- **Answer** (requestor): Update AwaitingRequestor = false, RequestorAnswer = Text, AnsweredOn = utcNow() → C1 "Requestor answered: …" → Teams to the person who asked.
- **Comment**: C1 with the text (visible to all).
- **Log**: C1 with the text (used for small field changes such as Reference).
Respond ok.

---

## F7 `IntakeDmlApproval` (child)
**Inputs:** IntakeId.
1. **Respond to a PowerApp or flow** immediately (so C2/F2 do not wait).
2. Get item; Get items IntakeTeams `Title eq env_DmlTeam` → DML email.
3. Get items IntakeAnswers for the intake (to show the data owner and PII answers).
4. **Start and wait for an approval** (Approve/Reject – First to respond) to the DML: title `concat('DML approval: ', RequestNumber, ' ', Title)`; details include requestor, team, type, data owner, contains PII, needed by and the app link.
5. Outcome Approve → Run C2 Move to `if(IAAP, 'Closed', 'Acceptance sign-off')`, actor = DML email, reason = comments. Reject → Run C2 Move to 'In Progress' with reason = comments.

---

## F8 `IntakeDailyDigest`
**Trigger:** Recurrence, weekdays 07:00 (your time zone).
1. Get items IntakeTeams. **Apply to each** team:
   - Get items IntakeRequests `RoutedTeam eq '{team}' and Status ne 'Closed'`.
   - Overdue: Filter array `less(item()?['NeededBy'], utcNow())`.
   - Awaiting requestor: Filter array `or(item()?['AwaitingRequestor'], equals(item()?['Status']?['Value'],'Requirements sign-off'), equals(item()?['Status']?['Value'],'Acceptance sign-off'))`.
   - Stalled: for each open intake, Get items IntakeActivity `RequestItemId eq X and Created ge '{addDays(utcNow(), -env_StalledDays)}'` Top 1; none → stalled.
   - If any list is non-empty → **Create HTML table** and Send an email (V2) to the manager.

---

## H1 `IntakeListFiles`
**Inputs:** FolderPath (text, e.g. `INT-20261019-00037` or `INT-20261019-00037/WP-1`). **Outputs:** files (text, JSON array).
1. **Get files (properties only)** – Documents library, Limit entries to folder = `/Shared Documents/@{FolderPath}`.
2. **Select** `{"name": item()?['{FilenameWithExtension}'], "url": item()?['{Link}']}`.
3. Respond files = `string(body('Select'))`.

---

## Notification matrix
| Event | Flow | To | Channel |
|---|---|---|---|
| Intake submitted | F1 | Team manager; requestor | Teams card; email |
| Owner assigned | C2 | Owner; requestor | Teams; email |
| Requirements sign-off requested | C2 | Requestor | Email + Teams |
| Requestor sends back | C2 | Owner, manager | Teams |
| Question asked / answered | F6 | Requestor / asker | Email, Teams |
| Work package created / sent back | F4 | Package owner | Teams |
| Work package ready for acceptance | F4 | Requestor | Email |
| All work packages accepted | F4 | Manager | Teams |
| DML approval needed | F7 | DMO manager | Approvals |
| Acceptance sign-off requested | C2 | Requestor | Email |
| Closed / reopened | C2 | Requestor, owner | Email |
| Overdue / stalled | F8 | Manager | Daily email |

## Build order
C1 → C2 + F2 → F1 → H1 → F6 → F3 → F5 → F4 → F7 → F8. Test each with the cases above before wiring its screen.
