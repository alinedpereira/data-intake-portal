import { useState } from "react";
import { CheckCircle2, FlaskConical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FolderFiles } from "@/components/request-files";
import { useConfirm } from "@/hooks/use-confirm";
import { QA_STAGE, requestNumber, type IntakeRequest } from "@/lib/intake";
import { QA_EVIDENCE_FOLDER, QA_TASK_TYPE } from "@/lib/qa";
import { taskNumber, taskStatusOf, useTaskPage } from "@/lib/tasks";

/**
 * QA Testing controls for a QA-enabled request.
 * Managers: move In Progress → QA Testing (when no QA task exists), record results,
 * add evidence and mark QA complete (→ Acceptance). Assignees see the evidence read-only.
 */
export function QaPanel({
  r,
  role,
  status,
  busy,
  onMoveToQa,
  onRecord,
  onComplete,
}: {
  r: IntakeRequest;
  role: string;
  status: string;
  busy: boolean;
  onMoveToQa: () => void;
  onRecord: (note: string) => void;
  onComplete: () => void;
}) {
  const confirm = useConfirm();
  const [result, setResult] = useState("");
  const tasksQ = useTaskPage(`RequestItemId eq ${Number(r.ID)}`, undefined, 200);
  const qaTasks = (tasksQ.data?.rows ?? []).filter((t) => t.TaskType?.Value === QA_TASK_TYPE);
  const isManager = role === "Manager";
  const inQa = status === QA_STAGE;
  const evidenceFolder = `${requestNumber(r)}/${QA_EVIDENCE_FOLDER}`;
  const pastQa = ["Acceptance sign-off", "Closed"].includes(status);

  if (status !== "In Progress" && !inQa && !pastQa) return null;

  return (
    <section aria-labelledby="qa-h" className="space-y-3 rounded-lg border border-border bg-card p-4">
      <h3 id="qa-h" className="flex items-center gap-2 font-semibold">
        <FlaskConical className="size-4" aria-hidden="true" /> QA Testing
      </h3>

      {status === "In Progress" && (
        <div className="space-y-2 text-sm">
          {tasksQ.isPending ? (
            <p className="text-muted-foreground">Checking for QA tasks…</p>
          ) : tasksQ.isError ? (
            <p role="alert" className="text-destructive">
              QA tasks couldn't be checked.{" "}
              <button type="button" className="underline" onClick={() => void tasksQ.refetch()}>Retry</button>
            </p>
          ) : qaTasks.length > 0 ? (
            <p>
              QA Testing starts automatically when {qaTasks.map((t) => `${taskNumber(t)} (${taskStatusOf(t)})`).join(", ")} moves to
              In progress.
            </p>
          ) : isManager ? (
            <>
              <p>No QA/Testing task exists for this intake. Move it to QA Testing when development is done.</p>
              <Button type="button" disabled={busy} onClick={onMoveToQa}>
                <FlaskConical aria-hidden="true" /> Move to QA Testing
              </Button>
            </>
          ) : (
            <p>A manager moves this intake to QA Testing, or it moves automatically when a QA/Testing task starts.</p>
          )}
        </div>
      )}

      {inQa && isManager && (
        <form
          className="grid gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!result.trim()) return;
            onRecord(result.trim());
            setResult("");
          }}
        >
          <Label htmlFor="qa-result">Testing comments or results</Label>
          <Textarea id="qa-result" rows={3} value={result} onChange={(e) => setResult(e.target.value)} placeholder="What was tested, what passed or failed…" />
          <div className="flex flex-wrap gap-2">
            <Button type="submit" variant="outline" disabled={busy || !result.trim()}>Record result</Button>
            <Button
              type="button"
              disabled={busy}
              onClick={async () => {
                const ok = await confirm({
                  title: "Mark QA Testing complete?",
                  description: "The intake moves to Acceptance sign-off and is locked for managers and team members.",
                  confirmLabel: "Mark complete",
                });
                if (ok) onComplete();
              }}
            >
              <CheckCircle2 aria-hidden="true" /> Mark QA complete
            </Button>
          </div>
        </form>
      )}
      {inQa && !isManager && <p className="text-sm text-muted-foreground">This intake is in QA Testing. A manager records results and marks QA complete.</p>}

      {(inQa || pastQa) && (
        <FolderFiles
          folder={evidenceFolder}
          title="QA evidence"
          compact
          readOnly={!(inQa && isManager)}
          onUploaded={(names) => onRecord(`QA evidence added: ${names.join(", ")}`)}
        />
      )}
    </section>
  );
}
