import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { DML_TEAM, type IntakeRequest } from "@/lib/intake";
import { ownerNames } from "@/lib/people";
import { teamManagerName, useMyManagedTeams, useTeams } from "@/lib/teams";
import { useAppStore } from "@/lib/store";

/** Manager/DML approval for a Data Risk Assessment intake sitting at DML Approval. */
export function DmlPanel({
  r,
  busy,
  onApprove,
  onSendBack,
}: {
  r: IntakeRequest;
  busy: boolean;
  onApprove: (comment: string) => void;
  onSendBack: (reason: string, owner: string | undefined) => void;
}) {
  const role = useAppStore((s) => s.role);
  const mine = useMyManagedTeams();
  const teams = useTeams();
  const dmlName = teamManagerName(teams.data, DML_TEAM);
  const isDml = role === "Manager" && mine.teams.includes(DML_TEAM);
  const owner = ownerNames(r);
  const [comment, setComment] = useState("");
  const [sendingBack, setSendingBack] = useState(false);
  const [reason, setReason] = useState("");
  const [tried, setTried] = useState(false);

  return (
    <section aria-labelledby="dml-h" className="space-y-3 rounded-lg border-2 border-primary/70 bg-card p-4">
      <h2 id="dml-h" className="flex items-center gap-2 font-semibold">
        <ShieldCheck className="size-5 text-primary" aria-hidden="true" /> Manager/DML approval
      </h2>
      {!isDml ? (
        <p className="text-sm text-muted-foreground">
          Waiting for {dmlName ?? "the DMO manager"} (DML) to approve. They can approve it or send it back to the owner with questions.
        </p>
      ) : !sendingBack ? (
        <>
          <p className="text-sm text-muted-foreground">
            Review the assessment. Approve it to move on, or send it back to {owner ?? "the owner"} with questions.
          </p>
          <div className="grid gap-1.5">
            <Label htmlFor="dml-comment">Approval comment <span className="font-normal text-muted-foreground">(optional)</span></Label>
            <Textarea id="dml-comment" rows={2} value={comment} onChange={(e) => setComment(e.target.value)} />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button disabled={busy} onClick={() => onApprove(comment.trim())}>Approve</Button>
            <Button variant="outline" disabled={busy} onClick={() => setSendingBack(true)}>Send back to owner</Button>
          </div>
        </>
      ) : (
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            setTried(true);
            if (reason.trim()) onSendBack(reason.trim(), owner);
          }}
        >
          <div className="grid gap-1.5">
            <Label htmlFor="dml-reason">Questions for {owner ?? "the owner"}</Label>
            <Textarea
              id="dml-reason"
              rows={3}
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              aria-describedby="dml-reason-hint"
              aria-invalid={tried && !reason.trim()}
            />
            <p id="dml-reason-hint" className="text-xs text-muted-foreground">
              The intake goes back to In Progress and your questions are saved to the activity history.
            </p>
            {tried && !reason.trim() && <p role="alert" className="text-sm text-destructive">Add the questions to send back.</p>}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={busy}>Send back</Button>
            <Button type="button" variant="outline" onClick={() => setSendingBack(false)}>Cancel</Button>
          </div>
        </form>
      )}
    </section>
  );
}
