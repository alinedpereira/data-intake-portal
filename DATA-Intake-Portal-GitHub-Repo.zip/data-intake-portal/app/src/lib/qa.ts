import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { IntakeQAConfigService, IntakeRequestsService, IntakeTasksService } from "../../generated";
import { queryClient } from "@/lib/query-client";
import { QA_STAGE, appendLog, isIaap, requestNumber, statusOf, updateRequest, type IntakeRequest } from "@/lib/intake";

/** Task type that marks a task as the request's QA Testing task. */
export const QA_TASK_TYPE = "QA/Testing";

/** Request-folder subfolder holding QA evidence. */
export const QA_EVIDENCE_FOLDER = "QA-Testing";

const QA_CONFIG_KEY = ["qa-config"] as const;

/** Set of "Level 1|Level 2" pairs that require QA Testing, read from the IntakeQAConfig list. */
async function loadQaConfig(): Promise<Set<string>> {
  const result = await IntakeQAConfigService.getAll({ select: ["Level1", "Level2", "RequiresQA"], top: 500 });
  if (!result.success) {
    console.error("QA config load failed", result.error);
    throw new Error("Unable to load QA settings.");
  }
  const pairs = new Set<string>();
  for (const row of result.data ?? []) {
    if (row.RequiresQA && row.Level1 && row.Level2) pairs.add(`${row.Level1.trim()}|${row.Level2.trim()}`);
  }
  return pairs;
}

export function useQaConfig() {
  return useQuery({ queryKey: QA_CONFIG_KEY, queryFn: loadQaConfig, staleTime: 5 * 60 * 1000 });
}

export function requiresQa(config: Set<string> | undefined, r: Pick<IntakeRequest, "RequestTypeL1" | "RequestTypeL2">): boolean {
  const l1 = r.RequestTypeL1?.Value;
  const l2 = r.RequestTypeL2;
  return !!config && !!l1 && !!l2 && config.has(`${l1}|${l2}`);
}

/**
 * Automatic QA entry: a QA/Testing task just moved to "In progress" (any request type except IAAP).
 * If the request is In Progress, move it to QA Testing and log it. Never throws: the task
 * change already succeeded, so a failure here is reported but does not undo it.
 */
export async function startQaFromTask(
  task: { ID?: number; Title?: string; RequestItemId?: number; TaskType?: { Value?: string }; WorkPackageId?: number },
  actor: string,
  role: string,
) {
  // Work package tasks don't move the intake; only intake-level QA tasks do.
  if (task.TaskType?.Value !== QA_TASK_TYPE || !task.RequestItemId || task.WorkPackageId) return;
  try {
    const res = await IntakeRequestsService.getAll({
      select: ["ID", "Status", "RequestTypeL1", "RequestTypeL2", "ActivityLog"],
      filter: `ID eq ${Number(task.RequestItemId)}`,
      top: 1,
    });
    if (!res.success) {
      console.error("QA auto-start: request read failed", res.error);
      toast.error("The QA task started, but the intake couldn't be moved to QA Testing. A manager can move it.");
      return;
    }
    const r = (res.data ?? [])[0];
    // Any request with a QA/Testing task gets the QA stage (IAAP requests keep their short path).
    if (!r || r.Status?.Value !== "In Progress" || isIaap(r)) return;
    await updateRequest(r.ID as number, {
      Status: { Value: QA_STAGE },
      ActivityLog: appendLog(r.ActivityLog, {
        at: new Date().toISOString(),
        by: actor,
        role,
        text: `Moved to QA Testing automatically: QA task TSK-${task.ID} "${task.Title ?? ""}" started`,
      }),
    });
    void queryClient.invalidateQueries({ queryKey: ["requests"] });
    void queryClient.invalidateQueries({ queryKey: ["request"] });
    toast.success("Intake moved to QA Testing");
  } catch (e) {
    console.error("QA auto-start failed", e);
    toast.error("The QA task started, but the intake couldn't be moved to QA Testing. A manager can move it.");
  }
}

/** Stages at or after which a QA task is no longer added automatically. */
const NO_AUTO_QA_TASK = [QA_STAGE, "Acceptance sign-off", "Closed", "Rejected"];

/** Requests currently being checked/created, so a double render can't create two QA tasks. */
const inFlight = new Set<number>();

/**
 * Make sure a QA-enabled, still-open request has one QA/Testing task.
 * Creates it unassigned (Not started, no due date) for the manager to assign.
 * Returns true if a task was created. Throws if the check or create fails.
 */
export async function ensureQaTask(r: IntakeRequest, actor: string, role: string): Promise<boolean> {
  const id = r.ID;
  if (!id || isIaap(r) || NO_AUTO_QA_TASK.includes(statusOf(r)) || inFlight.has(id)) return false;
  inFlight.add(id);
  try {
    const config = await queryClient.fetchQuery({ queryKey: QA_CONFIG_KEY, queryFn: loadQaConfig, staleTime: 5 * 60 * 1000 });
    if (!requiresQa(config, r)) return false;
    const existing = await IntakeTasksService.getAll({
      select: ["ID", "TaskType"],
      filter: `RequestItemId eq ${Number(id)}`,
      top: 500,
    });
    if (!existing.success) {
      console.error("QA task check failed", existing.error);
      throw new Error("Couldn't check for a QA task.");
    }
    if ((existing.data ?? []).some((t) => t.TaskType?.Value === QA_TASK_TYPE)) return false;
    const now = new Date().toISOString();
    const created = await IntakeTasksService.create({
      Title: `QA Testing \u2013 ${r.Title ?? requestNumber(r)}`,
      RequestItemId: id,
      RequestNumber: requestNumber(r),
      RequestTitle: r.Title,
      TaskType: { Value: QA_TASK_TYPE },
      TaskStatus: { Value: "Not started" },
      TaskNotes: "Created automatically because this intake type requires QA Testing. Assign it to the tester; starting it moves the intake to QA Testing.",
      CreatedByName: "Intake Portal",
      TaskActivity: appendLog(undefined, { at: now, by: actor, role, text: "QA task created automatically (unassigned)" }),
    });
    if (!created.success) {
      console.error("QA task create failed", created.error);
      throw new Error("Couldn't create the QA task.");
    }
    void queryClient.invalidateQueries({ queryKey: ["tasks"] });
    return true;
  } finally {
    inFlight.delete(id);
  }
}

/** True when any of these tasks is a QA/Testing task. */
export function hasQaTask(tasks: { TaskType?: { Value?: string } }[] | undefined): boolean {
  return !!tasks?.some((t) => t.TaskType?.Value === QA_TASK_TYPE);
}
