# D.A.T.A. Intake Portal – Canvas Rebuild Kit

This kit rebuilds the D.A.T.A. Intake Portal proof of concept as a **Power Apps canvas app** on **SharePoint lists**, with **Power Automate** doing the trusted work. It is designed to be fed to **GitHub Copilot** (Agent mode with the Power Platform *canvas-apps* plugin, or Copilot Chat if the plugin is not allowed in your tenant).

Read it together with the Word document *D.A.T.A. Intake Portal – Power Platform Rebuild Guide* (same OneDrive folder). The guide explains the why; this kit is the how.

## What is in the kit

| Folder | Contents | Use it for |
|---|---|---|
| `.github/copilot-instructions.md` | Project-wide rules Copilot reads automatically (naming, data, roles, delegation, style) | Put it in the root of the repo or folder Copilot works in |
| `00-context/` | Solution overview and data-model quick reference | Attach to every Copilot conversation, or let Copilot read it from the repo |
| `01-provisioning/` | `Provision-IntakeSite.ps1` (PnP PowerShell) and its README | Create every SharePoint list, column, index, permission group and configuration row in one run |
| `02-prompts/` | One prompt file per screen or feature (S01–S12) | Feed to Copilot in order; each ends with a ready-to-paste prompt |
| `03-flows/` | `FLOW-BUILD-SHEET.md` | Build the Power Automate flows step by step (Copilot in Power Automate can take the natural-language prompts) |
| `04-screenshots/wireframes/` | Annotated wireframes W01–W13 with suggested control names (orange tags) | Attach to the matching prompt so Copilot sees the layout |
| `04-screenshots/original-references/` | Your original design screenshots, the BMO home page, palette and logo | Branding and layout references |

## Order of work

1. **Provision SharePoint** – run `01-provisioning/Provision-IntakeSite.ps1` against a new or test site. Replace the POC manager and sub-team lead names in IntakeTeams / IntakeSubTeams with your people.
2. **Create the solution and a blank canvas app** in Power Apps (inside a solution). Save it, turn on co-authoring if you are using the Copilot canvas plugin, add the data sources listed in S01.
3. **Build the flows that the screens depend on first**: C1 Append activity, F1 Process submission, F2 Change stage (see the flow build sheet). The app calls them by name.
4. **Feed the prompts in order**: S01 → S12. Do one prompt per Copilot session, attach the wireframe(s) named at the top of the prompt, review and test before moving on.
5. **Build the remaining flows** (F3–F8) as their screens need them.
6. **Test each role** with real accounts (Requestor, Team Member, Manager, DMO manager) using the acceptance checks at the end of each prompt.

## How to feed a prompt to GitHub Copilot

**With the canvas-apps plugin (preferred):**
1. Open the canvas app in Power Apps Studio, keep the tab open, confirm co-authoring is on.
2. In VS Code (Agent mode) or Copilot CLI, run the plugin's configure command and connect to the app.
3. Open the prompt file (for example `02-prompts/S03-new-intake.md`). Attach the wireframes it lists.
4. Paste the block under **Prompt to paste** and let Copilot build. Then ask it to run through the **Acceptance checks**.

**Without the plugin (Copilot Chat only):**
Paste the prompt and attach the wireframe; ask Copilot for the control list and the Power Fx for each property. Build the controls in Studio and paste the formulas in. It is slower but still much faster than starting cold.

## Conventions used everywhere
- Control names: `scr` screens, `gal` galleries, `btn` buttons, `drp` dropdowns, `cmb` combo boxes, `txt` text inputs, `dte` date pickers, `lbl` labels, `con` containers, `col` collections, `var` global variables, `loc` context variables.
- Classic control property names are used in formulas (`.Text`, `.Selected`, `.SelectedDate`). With modern controls, use `.Value` for text inputs.
- The app **never writes Status**: every stage change goes through flow F2 (`IntakeChangeStage`).
- Flows are named without spaces so Power Fx can call them: `IntakeProcessSubmission`, `IntakeChangeStage`, `IntakeAnswersChanged`, `IntakeWorkPackageChange`, `IntakeAskRequestor`, `IntakeListFiles`.
