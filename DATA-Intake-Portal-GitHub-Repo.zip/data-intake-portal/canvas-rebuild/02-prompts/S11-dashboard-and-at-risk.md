# S11 – My Team's Work View (dashboard) and Intakes Needing Attention

**Wireframes:** `W11-dashboard.png`, `W13-intakes-needing-attention.png`
**Depends on:** S01; flow F8 for the daily digest (optional for the screens)

## Dashboard (`scrDashboard`)
- KPI tiles: Open intakes, Overdue (NeededBy < Today and not Closed), Awaiting requestor (AwaitingRequestor or a sign-off stage), Closed in the date range.
- "Intakes by stage" column chart; "Open intakes by team" bar list; "Needs attention" list linking to intakes.
- Date-range filter (30 / 90 / 365 days / all) on SubmittedOn.
```
// Load the team's intakes once (manager's teams), then compute in memory
ClearCollect(colTeamIntakes,
  Filter(IntakeRequests, RoutedTeam.Value = drpDashTeam.Selected.Title, SubmittedOn >= varSince || Status.Value <> "Closed"));
// Chart data
ForAll(StandardStages As s, {Stage: s.Value, Count: CountRows(Filter(colTeamIntakes, Status.Value = s.Value))})
// Overdue tile
CountRows(Filter(colTeamIntakes, NeededBy < Today(), Status.Value <> "Closed"))
```
For more than ~2,000 intakes per team, replace the charts with an embedded Power BI tile over the same lists.

## Intakes Needing Attention (`scrAtRisk`)
Tabs: All / Overdue / Stalled / Awaiting DML. Reasons:
- Overdue: NeededBy < Today and not Closed.
- Stalled: no IntakeActivity row in the last 7 days (configurable) while open.
- Awaiting requestor: AwaitingRequestor or a sign-off stage for more than 3 days.
- Awaiting DML: Status = DML Approval.
```
// Last activity per intake (load the team's recent activity once)
ClearCollect(colRecentActivity, Filter(IntakeActivity, Created >= Today() - 30));
AddColumns(colTeamIntakes, LastActivity, Max(Filter(colRecentActivity, RequestItemId = ThisRecord.ID), Created))
```
The same rules run daily in flow F8 to email each manager a digest.

## Acceptance checks
- KPI counts match the team queue for the same filters.
- An intake past its needed-by date appears under Overdue with the date in "Why".
- The DML tab lists only DML Approval intakes.

## Prompt to paste
```
Build scrDashboard and scrAtRisk (S11) matching wireframes W11 and W13 using the formulas in 02-prompts/S11: KPI tiles,
intakes-by-stage chart, open-by-team bars, needs-attention list, and the attention screen with Overdue / Stalled /
Awaiting requestor / Awaiting DML tabs. Load the team's intakes once into a collection and compute in memory.
Then run the acceptance checks.
```
