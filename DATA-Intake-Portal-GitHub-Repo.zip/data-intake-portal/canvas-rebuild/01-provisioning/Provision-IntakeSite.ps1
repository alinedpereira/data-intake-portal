<#
.SYNOPSIS
  Provisions the D.A.T.A. Intake Portal SharePoint site for the Power Apps canvas + Power Automate rebuild.

.DESCRIPTION
  Creates every list, column and index described in the Power Platform Rebuild Guide (section 4),
  then seeds the configuration lists (teams, sub-teams, request types, questions, question rules,
  QA config and stage transitions) with the values from the proof of concept.

  Safe to re-run: lists and columns that already exist are skipped. Configuration rows are only
  added to a list that is empty (use -ReseedConfig to add them anyway).

.REQUIREMENTS
  - PowerShell 7.2+ and PnP.PowerShell 2.x   (Install-Module PnP.PowerShell -Scope CurrentUser)
  - An Entra app registration for PnP interactive login (pass its id as -ClientId)
  - Site Owner (or higher) on the target site

.EXAMPLE
  ./Provision-IntakeSite.ps1 -SiteUrl https://contoso.sharepoint.com/sites/intake-requests -ClientId <app-id> -EmailDomain contoso.com

.NOTES
  Generated from the POC site schema on 5 Nov 2026. Team manager names and emails, and sub-team
  leads, are POC demo values: replace them with your own people before go-live (or edit the lists after).
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory)] [string] $SiteUrl,
  [Parameter(Mandatory)] [string] $ClientId,
  # Your email domain, e.g. contoso.com. Used for the sample people.
  [Parameter(Mandatory)] [string] $EmailDomain,
  [switch] $SkipSeed,
  [switch] $ReseedConfig,
  [switch] $SkipPermissions
)
$ErrorActionPreference = 'Stop'
Connect-PnPOnline -Url $SiteUrl -Interactive -ClientId $ClientId

function Ensure-List([string]$Title, [string]$Description) {
  $l = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
  if (-not $l) {
    Write-Host "Creating list $Title" -ForegroundColor Cyan
    $l = New-PnPList -Title $Title -Template GenericList -OnQuickLaunch:$false
    Set-PnPList -Identity $Title -Description $Description | Out-Null
  } else { Write-Host "List $Title exists" -ForegroundColor DarkGray }
  return $l
}
function Ensure-Field([string]$List, [string]$Xml) {
  $name = ([xml]$Xml).Field.Name
  if (Get-PnPField -List $List -Identity $name -ErrorAction SilentlyContinue) { return }
  Add-PnPFieldFromXml -List $List -FieldXml $Xml | Out-Null
  Write-Host "  + $List.$name"
}
function Ensure-Index([string]$List, [string]$Field) {
  Set-PnPField -List $List -Identity $Field -Values @{ Indexed = $true } | Out-Null
}
function Seed-Rows([string]$List, [object[]]$Rows) {
  if ($SkipSeed) { return }
  $count = (Get-PnPList -Identity $List).ItemCount
  if ($count -gt 0 -and -not $ReseedConfig) { Write-Host "  $List already has $count rows; seed skipped" -ForegroundColor DarkGray; return }
  foreach ($r in $Rows) { Add-PnPListItem -List $List -Values $r | Out-Null }
  Write-Host "  seeded $($Rows.Count) rows into $List" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# 1. Lists and columns
# ---------------------------------------------------------------------------


# ---- IntakeTeams: Routed teams, their managers and business focus area
Ensure-List 'IntakeTeams' 'Routed teams, their managers and business focus area' | Out-Null
Ensure-Field 'IntakeTeams' @'
<Field DisplayName="ManagerName" Type="Text" Required="FALSE" StaticName="ManagerName" Name="ManagerName" />
'@
Ensure-Field 'IntakeTeams' @'
<Field DisplayName="ManagerEmail" Type="Text" Required="FALSE" StaticName="ManagerEmail" Name="ManagerEmail" />
'@
Ensure-Field 'IntakeTeams' @'
<Field Type="Text" Name="FocusArea" StaticName="FocusArea" DisplayName="FocusArea" MaxLength="255" />
'@

# ---- IntakeTeamMembers: Who belongs to each team (decides the Team Member role)
Ensure-List 'IntakeTeamMembers' 'Who belongs to each team (decides the Team Member role)' | Out-Null
Ensure-Field 'IntakeTeamMembers' @'
<Field Type='Text' Name='Team' StaticName='Team' DisplayName='Team' MaxLength='255' />
'@
Ensure-Field 'IntakeTeamMembers' @'
<Field Type='User' Name='Member' StaticName='Member' DisplayName='Member' List='UserInfo' UserSelectionMode='PeopleOnly' />
'@
Ensure-Field 'IntakeTeamMembers' @'
<Field Type='Boolean' Name='IsActive' StaticName='IsActive' DisplayName='IsActive'><Default>1</Default></Field>
'@

# ---- IntakeSubTeams: Sub-teams that own work packages
Ensure-List 'IntakeSubTeams' 'Sub-teams that own work packages' | Out-Null
Ensure-Field 'IntakeSubTeams' @'
<Field Type="Text" Name="LeadName" StaticName="LeadName" DisplayName="LeadName" MaxLength="255" />
'@
Ensure-Field 'IntakeSubTeams' @'
<Field Type="Text" Name="ParentTeam" StaticName="ParentTeam" DisplayName="ParentTeam" MaxLength="255" />
'@
Ensure-Field 'IntakeSubTeams' @'
<Field Type="Text" Name="LeadEmail" StaticName="LeadEmail" DisplayName="LeadEmail" MaxLength="255" />
'@

# ---- IntakeRequestTypes: Level 1 / Level 2 intake types and the team each routes to
Ensure-List 'IntakeRequestTypes' 'Level 1 / Level 2 intake types and the team each routes to' | Out-Null
Ensure-Field 'IntakeRequestTypes' @'
<Field Type="Text" Name="Level1" StaticName="Level1" DisplayName="Level1" MaxLength="255" />
'@
Ensure-Field 'IntakeRequestTypes' @'
<Field Type="Text" Name="DefaultTeam" StaticName="DefaultTeam" DisplayName="DefaultTeam" MaxLength="255" />
'@
Ensure-Field 'IntakeRequestTypes' @'
<Field Type="Boolean" Name="AskFocusArea" StaticName="AskFocusArea" DisplayName="AskFocusArea"><Default>0</Default></Field>
'@
Ensure-Field 'IntakeRequestTypes' @'
<Field Type="Number" Name="SortOrder" StaticName="SortOrder" DisplayName="SortOrder" />
'@
Ensure-Field 'IntakeRequestTypes' @'
<Field Type="Boolean" Name="IsActive" StaticName="IsActive" DisplayName="IsActive"><Default>1</Default></Field>
'@

# ---- IntakeQuestions: Question library: each team question defined once
Ensure-List 'IntakeQuestions' 'Question library: each team question defined once' | Out-Null
Ensure-Field 'IntakeQuestions' @'
<Field Type="Text" Name="QuestionKey" StaticName="QuestionKey" DisplayName="QuestionKey" MaxLength="100" />
'@
Ensure-Field 'IntakeQuestions' @'
<Field Type="Choice" Name="QuestionType" StaticName="QuestionType" DisplayName="QuestionType" Format="Dropdown"><Default>Text</Default><CHOICES><CHOICE>Text</CHOICE><CHOICE>Long text</CHOICE><CHOICE>Number</CHOICE><CHOICE>Date</CHOICE><CHOICE>Choice</CHOICE><CHOICE>Yes/No</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeQuestions' @'
<Field Type="Note" Name="Choices" StaticName="Choices" DisplayName="Choices" NumLines="6" RichText="FALSE" />
'@
Ensure-Field 'IntakeQuestions' @'
<Field Type="Text" Name="HelpText" StaticName="HelpText" DisplayName="HelpText" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestions' @'
<Field Type="Text" Name="OwnerTeam" StaticName="OwnerTeam" DisplayName="OwnerTeam" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestions' @'
<Field Type="Boolean" Name="IsActive" StaticName="IsActive" DisplayName="IsActive"><Default>1</Default></Field>
'@

# ---- IntakeQuestionRules: Where each question is asked (team, Level 1, Level 2, audience)
Ensure-List 'IntakeQuestionRules' 'Where each question is asked (team, Level 1, Level 2, audience)' | Out-Null
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="QuestionKey" StaticName="QuestionKey" DisplayName="QuestionKey" MaxLength="100" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="Team" StaticName="Team" DisplayName="Team" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="RequestTypeL1" StaticName="RequestTypeL1" DisplayName="RequestTypeL1" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="RequestTypeL2" StaticName="RequestTypeL2" DisplayName="RequestTypeL2" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Choice" Name="Audience" StaticName="Audience" DisplayName="Audience" Format="Dropdown"><Default>Requestor</Default><CHOICES><CHOICE>Requestor</CHOICE><CHOICE>Internal</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Boolean" Name="IsRequired" StaticName="IsRequired" DisplayName="IsRequired"><Default>0</Default></Field>
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Boolean" Name="IsScored" StaticName="IsScored" DisplayName="IsScored"><Default>0</Default></Field>
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Number" Name="SortOrder" StaticName="SortOrder" DisplayName="SortOrder" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="ShowIfKey" StaticName="ShowIfKey" DisplayName="ShowIfKey" MaxLength="100" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Text" Name="ShowIfValue" StaticName="ShowIfValue" DisplayName="ShowIfValue" MaxLength="255" />
'@
Ensure-Field 'IntakeQuestionRules' @'
<Field Type="Boolean" Name="IsActive" StaticName="IsActive" DisplayName="IsActive"><Default>1</Default></Field>
'@

# ---- IntakeQAConfig: Intake types that need a QA Testing stage
Ensure-List 'IntakeQAConfig' 'Intake types that need a QA Testing stage' | Out-Null
Ensure-Field 'IntakeQAConfig' @'
<Field DisplayName="Level1" Type="Text" Required="FALSE" StaticName="Level1" Name="Level1" />
'@
Ensure-Field 'IntakeQAConfig' @'
<Field DisplayName="Level2" Type="Text" Required="FALSE" StaticName="Level2" Name="Level2" />
'@
Ensure-Field 'IntakeQAConfig' @'
<Field DisplayName="RequiresQA" Type="Boolean" Required="FALSE" StaticName="RequiresQA" Name="RequiresQA" />
'@

# ---- IntakeTransitions: Allowed stage changes per role (validated by flow F2)
Ensure-List 'IntakeTransitions' 'Allowed stage changes per role (validated by flow F2)' | Out-Null
Ensure-Field 'IntakeTransitions' @'
<Field Type='Text' Name='FromStage' StaticName='FromStage' DisplayName='FromStage' MaxLength='255' />
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Text' Name='ToStage' StaticName='ToStage' DisplayName='ToStage' MaxLength='255' />
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Choice' Name='AllowedRole' StaticName='AllowedRole' DisplayName='AllowedRole' Format='Dropdown'><Default>Owner</Default><CHOICES><CHOICE>Requestor</CHOICE><CHOICE>Owner</CHOICE><CHOICE>Manager</CHOICE><CHOICE>DML</CHOICE><CHOICE>System</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Boolean' Name='ReasonRequired' StaticName='ReasonRequired' DisplayName='ReasonRequired'><Default>0</Default></Field>
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Choice' Name='Lifecycle' StaticName='Lifecycle' DisplayName='Lifecycle' Format='Dropdown'><Default>Standard</Default><CHOICES><CHOICE>Standard</CHOICE><CHOICE>IAAP</CHOICE><CHOICE>Any</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Text' Name='RequestStatus' StaticName='RequestStatus' DisplayName='RequestStatus' MaxLength='255' />
'@
Ensure-Field 'IntakeTransitions' @'
<Field Type='Boolean' Name='IsActive' StaticName='IsActive' DisplayName='IsActive'><Default>1</Default></Field>
'@

# ---- IntakeRequests: One row per intake
Ensure-List 'IntakeRequests' 'One row per intake' | Out-Null
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequestNumber" Type="Text" Required="FALSE" StaticName="RequestNumber" Name="RequestNumber" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="OnBehalfOf" Type="Text" Required="FALSE" StaticName="OnBehalfOf" Name="OnBehalfOf" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="BusinessUnit" Type="Choice" Required="FALSE" StaticName="BusinessUnit" Name="BusinessUnit"><CHOICES><CHOICE>Personal Banking</CHOICE><CHOICE>Business Banking</CHOICE><CHOICE>Customer Lifecycle Management / Data &amp; Analytics</CHOICE><CHOICE>Digital / AI &amp; Transformation</CHOICE><CHOICE>Virtual Connect</CHOICE><CHOICE>Retail Payments</CHOICE><CHOICE>Customer Loyalty</CHOICE><CHOICE>Emerging Business</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequestTypeL1" Type="Choice" Required="FALSE" StaticName="RequestTypeL1" Name="RequestTypeL1" FillInChoice="TRUE"><CHOICES><CHOICE>Reporting / Dashboard / Analytics</CHOICE><CHOICE>Campaign</CHOICE><CHOICE>App / Automation</CHOICE><CHOICE>Offer / Incentive</CHOICE><CHOICE>Data Quality</CHOICE><CHOICE>Data Science / Modeling</CHOICE><CHOICE>Data Risk Assessment</CHOICE><CHOICE>Other / Not Sure</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequestTypeL2" Type="Text" Required="FALSE" StaticName="RequestTypeL2" Name="RequestTypeL2" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RoutedTeam" Type="Choice" Required="FALSE" StaticName="RoutedTeam" Name="RoutedTeam" FillInChoice="TRUE"><CHOICES><CHOICE>Product Analytics</CHOICE><CHOICE>Campaign Strategy</CHOICE><CHOICE>Application and Automation Development</CHOICE><CHOICE>OMP</CHOICE><CHOICE>P&amp;BB DMO</CHOICE><CHOICE>AI / Model Team</CHOICE><CHOICE>Intake Triage</CHOICE><CHOICE>Customer Analytics</CHOICE><CHOICE>Digital Analytics</CHOICE><CHOICE>Distribution and BB Analytics</CHOICE><CHOICE>Channel Analytics &amp; Reporting</CHOICE><CHOICE>Virtual Connect Business Analytics</CHOICE><CHOICE>Gen AI &amp; Model Governance</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequestComments" Type="Note" Required="FALSE" StaticName="RequestComments" Name="RequestComments" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequestDescription" Type="Note" Required="FALSE" StaticName="RequestDescription" Name="RequestDescription" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="NeededBy" Type="DateTime" Required="FALSE" StaticName="NeededBy" Name="NeededBy" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Priority" Type="Choice" Required="FALSE" StaticName="Priority" Name="Priority"><CHOICES><CHOICE>Low</CHOICE><CHOICE>Medium</CHOICE><CHOICE>High</CHOICE><CHOICE>Critical</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="BusinessValue" Type="Note" Required="FALSE" StaticName="BusinessValue" Name="BusinessValue" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Status" Type="Choice" Required="FALSE" StaticName="Status" Name="Status"><CHOICES><CHOICE>Submitted</CHOICE><CHOICE>Queued</CHOICE><CHOICE>Assigned / Under Review</CHOICE><CHOICE>Requirements sign-off</CHOICE><CHOICE>Approved</CHOICE><CHOICE>In Progress</CHOICE><CHOICE>DML Approval</CHOICE><CHOICE>QA Testing</CHOICE><CHOICE>Acceptance sign-off</CHOICE><CHOICE>Closed</CHOICE><CHOICE>Rejected</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="RequirementsSignedOff" Type="Boolean" Required="FALSE" StaticName="RequirementsSignedOff" Name="RequirementsSignedOff" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="AcceptanceSignedOff" Type="Boolean" Required="FALSE" StaticName="AcceptanceSignedOff" Name="AcceptanceSignedOff" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="SubmittedOn" Type="DateTime" Required="FALSE" StaticName="SubmittedOn" Name="SubmittedOn" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Requestor's email" Format="Dropdown" IsModern="TRUE" MaxLength="255" Name="Requestorsemail" Title="Requestor's email" Type="Text" StaticName="Requestorsemail" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Reference" Type="Text" Required="FALSE" StaticName="Reference" Name="Reference" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Requestor" Format="Dropdown" IsModern="TRUE" List="UserInfo" Name="Requestor" Title="Requestor" Type="User" UserSelectionMode="0" UserSelectionScope="0" StaticName="Requestor" />
'@
Ensure-Field 'IntakeRequests' @'
<Field ClientSideComponentId="00000000-0000-0000-0000-000000000000" DisplayName="Owner" Format="Dropdown" List="UserInfo" Name="Owner" Title="Owner" Type="User" UserSelectionMode="1" UserSelectionScope="0" StaticName="Owner" />
'@
Ensure-Field 'IntakeRequests' @'
<Field CustomFormatter="{&quot;elmType&quot;:&quot;div&quot;,&quot;style&quot;:{&quot;flex-wrap&quot;:&quot;wrap&quot;,&quot;display&quot;:&quot;flex&quot;},&quot;children&quot;:[{&quot;elmType&quot;:&quot;div&quot;,&quot;style&quot;:{&quot;box-sizing&quot;:&quot;border-box&quot;,&quot;padding&quot;:&quot;4px 8px 5px 8px&quot;,&quot;overflow&quot;:&quot;hidden&quot;,&quot;text-overflow&quot;:&quot;ellipsis&quot;,&quot;display&quot;:&quot;flex&quot;,&quot;border-radius&quot;:&quot;16px&quot;,&quot;height&quot;:&quot;24px&quot;,&quot;align-items&quot;:&quot;center&quot;,&quot;white-space&quot;:&quot;nowrap&quot;,&quot;margin&quot;:&quot;4px 4px 4px 4px&quot;},&quot;attributes&quot;:{&quot;class&quot;:{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Submitted&quot;]},&quot;sp-css-backgroundColor-BgLightGray sp-css-borderColor-LightGrayFont sp-field-fontSizeSmall sp-css-color-LightGrayFont sp-css-color-LightGrayFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Queued&quot;]},&quot;sp-css-backgroundColor-BgCornflowerBlue sp-css-borderColor-CornflowerBlueFont sp-field-fontSizeSmall sp-css-color-CornflowerBlueFont sp-css-color-CornflowerBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Assigned/Under Review&quot;]},&quot;sp-css-backgroundColor-BgGold sp-field-fontSizeSmall sp-css-color-GoldFont sp-css-color-GoldFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;&quot;]},&quot;&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Approved&quot;]},&quot;sp-css-backgroundColor-BgMintGreen sp-css-borderColor-MintGreenFont sp-field-fontSizeSmall sp-css-color-MintGreenFont sp-css-color-MintGreenFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;In progress&quot;]},&quot;sp-css-backgroundColor-BgLightBlue sp-css-borderColor-LightBlueFont sp-field-fontSizeSmall sp-css-color-LightBlueFont sp-css-color-LightBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;On Hold&quot;]},&quot;sp-css-backgroundColor-BgMauve sp-css-borderColor-MauveFont sp-field-fontSizeSmall sp-css-color-MauveFont sp-css-color-MauveFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Delivered/Pending Business Approval&quot;]},&quot;sp-css-backgroundColor-BgCornflowerBlue sp-css-borderColor-CornflowerBlueFont sp-field-fontSizeSmall sp-css-color-CornflowerBlueFont sp-css-color-CornflowerBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Closed&quot;]},&quot;sp-css-backgroundColor-BgSage sp-field-fontSizeSmall sp-css-color-SageFont sp-css-color-SageFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Cancelled&quot;]},&quot;sp-css-backgroundColor-BgPeach sp-css-borderColor-PeachFont sp-field-fontSizeSmall sp-css-color-PeachFont sp-css-color-PeachFont&quot;,&quot;sp-field-borderAllRegular sp-field-borderAllSolid sp-css-borderColor-neutralSecondary&quot;]}]}]}]}]}]}]}]}]}]}},&quot;children&quot;:[{&quot;elmType&quot;:&quot;span&quot;,&quot;style&quot;:{&quot;overflow&quot;:&quot;hidden&quot;,&quot;text-overflow&quot;:&quot;ellipsis&quot;,&quot;padding&quot;:&quot;0 3px&quot;},&quot;txtContent&quot;:&quot;@currentField&quot;,&quot;attributes&quot;:{&quot;class&quot;:{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Submitted&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-LightGrayFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Queued&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-CornflowerBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Assigned/Under Review&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-GoldFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;&quot;]},&quot;&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Approved&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-MintGreenFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;In progress&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-LightBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;On Hold&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-MauveFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Delivered/Pending Business Approval&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-CornflowerBlueFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Closed&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-SageFont&quot;,{&quot;operator&quot;:&quot;:&quot;,&quot;operands&quot;:[{&quot;operator&quot;:&quot;==&quot;,&quot;operands&quot;:[&quot;@currentField&quot;,&quot;Cancelled&quot;]},&quot;sp-field-fontSizeSmall sp-css-color-PeachFont&quot;,&quot;&quot;]}]}]}]}]}]}]}]}]}]}}}]}],&quot;templateId&quot;:&quot;BgColorChoicePill&quot;}" DisplayName="Request Status" FillInChoice="FALSE" Format="Dropdown" IsModern="TRUE" Name="RequestStatus" Title="Request Status" Type="Choice" StaticName="RequestStatus"><CHOICES><CHOICE>Submitted</CHOICE><CHOICE>Queued</CHOICE><CHOICE>Assigned/Under Review</CHOICE><CHOICE>Approved</CHOICE><CHOICE>In progress</CHOICE><CHOICE>DML Approval</CHOICE><CHOICE>QA Testing</CHOICE><CHOICE>On Hold</CHOICE><CHOICE>Delivered/Pending Business Approval</CHOICE><CHOICE>Closed</CHOICE><CHOICE>Cancelled</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="BacklogScore" Type="Number" Required="FALSE" StaticName="BacklogScore" Name="BacklogScore" />
'@
Ensure-Field 'IntakeRequests' @'
<Field DisplayName="Business Focus Area" Type="Choice" Required="FALSE" StaticName="AnalyticsDomain" Name="AnalyticsDomain" FillInChoice="TRUE"><CHOICES><CHOICE>Customer &amp; Segment Data</CHOICE><CHOICE>Product &amp; Pricing Data</CHOICE><CHOICE>Web &amp; App Data</CHOICE><CHOICE>Channel &amp; Sales Data</CHOICE><CHOICE>Virtual Connect Data</CHOICE><CHOICE>Distribution &amp; Business Banking Data</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="Text" Name="QuestionAskedBy" StaticName="QuestionAskedBy" DisplayName="QuestionAskedBy" MaxLength="255" />
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="DateTime" Format="DateTime" Name="AnsweredOn" StaticName="AnsweredOn" DisplayName="AnsweredOn" />
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="Note" Name="OpenQuestion" StaticName="OpenQuestion" DisplayName="OpenQuestion" RichText="FALSE" NumLines="6" UnlimitedLengthInDocumentLibrary="TRUE" />
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="DateTime" Format="DateTime" Name="QuestionAskedOn" StaticName="QuestionAskedOn" DisplayName="QuestionAskedOn" />
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="Note" Name="RequestorAnswer" StaticName="RequestorAnswer" DisplayName="RequestorAnswer" RichText="FALSE" NumLines="6" />
'@
Ensure-Field 'IntakeRequests' @'
<Field Type="Boolean" Name="AwaitingRequestor" StaticName="AwaitingRequestor" DisplayName="AwaitingRequestor"><Default>0</Default></Field>
'@

# ---- IntakeTasks: One row per task (WorkPackageId 0 = intake-level)
Ensure-List 'IntakeTasks' 'One row per task (WorkPackageId 0 = intake-level)' | Out-Null
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="RequestItemId" Type="Number" Required="FALSE" StaticName="RequestItemId" Name="RequestItemId" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="RequestNumber" Type="Text" Required="FALSE" StaticName="RequestNumber" Name="RequestNumber" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="RequestTitle" Type="Text" Required="FALSE" StaticName="RequestTitle" Name="RequestTitle" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="DueDate" Type="DateTime" Required="FALSE" StaticName="DueDate" Name="DueDate" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="TaskStatus" Type="Choice" Required="FALSE" StaticName="TaskStatus" Name="TaskStatus"><CHOICES><CHOICE>Not started</CHOICE><CHOICE>In progress</CHOICE><CHOICE>Blocked</CHOICE><CHOICE>Done</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="TaskNotes" Type="Note" Required="FALSE" StaticName="TaskNotes" Name="TaskNotes" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="CreatedByName" Type="Text" Required="FALSE" StaticName="CreatedByName" Name="CreatedByName" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="Assigned To" Format="Dropdown" IsModern="TRUE" List="UserInfo" Name="AssignedTo" Title="Assigned To" Type="User" UserSelectionMode="0" UserSelectionScope="0" StaticName="AssignedTo" />
'@
Ensure-Field 'IntakeTasks' @'
<Field DisplayName="TaskType" Type="Choice" Required="FALSE" StaticName="TaskType" Name="TaskType"><CHOICES><CHOICE>Requirement Analysis</CHOICE><CHOICE>Design</CHOICE><CHOICE>Development</CHOICE><CHOICE>QA/Testing</CHOICE><CHOICE>Deployment</CHOICE><CHOICE>Other</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeTasks' @'
<Field Type="Number" Name="WorkPackageId" StaticName="WorkPackageId" DisplayName="WorkPackageId" Decimals="0" />
'@

# ---- IntakeWorkPackages: One row per work package
Ensure-List 'IntakeWorkPackages' 'One row per work package' | Out-Null
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="User" Name="WPOwner" StaticName="WPOwner" DisplayName="WPOwner" UserSelectionMode="PeopleOnly" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="DateTime" Format="DateOnly" Name="WPDueDate" StaticName="WPDueDate" DisplayName="WPDueDate" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Number" Name="RequestItemId" StaticName="RequestItemId" DisplayName="RequestItemId" Decimals="0" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Choice" Name="WPStatus" StaticName="WPStatus" DisplayName="WPStatus" Format="Dropdown"><Default>Not started</Default><CHOICES><CHOICE>Not started</CHOICE><CHOICE>Requirements</CHOICE><CHOICE>In progress</CHOICE><CHOICE>QA/Review</CHOICE><CHOICE>Ready for acceptance</CHOICE><CHOICE>Accepted</CHOICE><CHOICE>Sent back</CHOICE></CHOICES></Field>
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Number" Name="SortOrder" StaticName="SortOrder" DisplayName="SortOrder" Decimals="0" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Note" Name="WPDescription" StaticName="WPDescription" DisplayName="WPDescription" RichText="FALSE" NumLines="6" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Text" Name="SubTeam" StaticName="SubTeam" DisplayName="SubTeam" MaxLength="255" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Text" Name="RequestNumber" StaticName="RequestNumber" DisplayName="RequestNumber" MaxLength="255" />
'@
Ensure-Field 'IntakeWorkPackages' @'
<Field Type="Choice" Name="WPPriority" StaticName="WPPriority" DisplayName="WPPriority" Format="Dropdown"><Default>Medium</Default><CHOICES><CHOICE>Low</CHOICE><CHOICE>Medium</CHOICE><CHOICE>High</CHOICE><CHOICE>Critical</CHOICE></CHOICES></Field>
'@

# ---- IntakeAnswers: Requestor answers, one row per answer
Ensure-List 'IntakeAnswers' 'Requestor answers, one row per answer' | Out-Null
Ensure-Field 'IntakeAnswers' @'
<Field Type='Number' Name='RequestItemId' StaticName='RequestItemId' DisplayName='RequestItemId' />
'@
Ensure-Field 'IntakeAnswers' @'
<Field Type='Text' Name='QuestionKey' StaticName='QuestionKey' DisplayName='QuestionKey' MaxLength='100' />
'@
Ensure-Field 'IntakeAnswers' @'
<Field Type='Note' Name='AnswerValue' StaticName='AnswerValue' DisplayName='AnswerValue' NumLines='6' RichText='FALSE' />
'@
Ensure-Field 'IntakeAnswers' @'
<Field Type='Number' Name='Points' StaticName='Points' DisplayName='Points' />
'@
Ensure-Field 'IntakeAnswers' @'
<Field Type='Text' Name='AnsweredBy' StaticName='AnsweredBy' DisplayName='AnsweredBy' MaxLength='255' />
'@

# ---- IntakeInternalAnswers: Internal team answers, one row per answer (restricted)
Ensure-List 'IntakeInternalAnswers' 'Internal team answers, one row per answer (restricted)' | Out-Null
Ensure-Field 'IntakeInternalAnswers' @'
<Field Type='Number' Name='RequestItemId' StaticName='RequestItemId' DisplayName='RequestItemId' />
'@
Ensure-Field 'IntakeInternalAnswers' @'
<Field Type='Text' Name='QuestionKey' StaticName='QuestionKey' DisplayName='QuestionKey' MaxLength='100' />
'@
Ensure-Field 'IntakeInternalAnswers' @'
<Field Type='Note' Name='AnswerValue' StaticName='AnswerValue' DisplayName='AnswerValue' NumLines='6' RichText='FALSE' />
'@
Ensure-Field 'IntakeInternalAnswers' @'
<Field Type='Number' Name='Points' StaticName='Points' DisplayName='Points' />
'@
Ensure-Field 'IntakeInternalAnswers' @'
<Field Type='Text' Name='AnsweredBy' StaticName='AnsweredBy' DisplayName='AnsweredBy' MaxLength='255' />
'@

# ---- IntakeActivity: Activity history, one row per entry (written by flows only)
Ensure-List 'IntakeActivity' 'Activity history, one row per entry (written by flows only)' | Out-Null
Ensure-Field 'IntakeActivity' @'
<Field Type='Number' Name='RequestItemId' StaticName='RequestItemId' DisplayName='RequestItemId' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Number' Name='WorkPackageId' StaticName='WorkPackageId' DisplayName='WorkPackageId' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Number' Name='TaskId' StaticName='TaskId' DisplayName='TaskId' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Note' Name='EntryText' StaticName='EntryText' DisplayName='EntryText' NumLines='6' RichText='FALSE' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Text' Name='ActorName' StaticName='ActorName' DisplayName='ActorName' MaxLength='255' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Text' Name='ActorRole' StaticName='ActorRole' DisplayName='ActorRole' MaxLength='255' />
'@
Ensure-Field 'IntakeActivity' @'
<Field Type='Boolean' Name='IsInternal' StaticName='IsInternal' DisplayName='IsInternal'><Default>0</Default></Field>
'@

# ---------------------------------------------------------------------------
# 2. Indexes (keep filters delegable and under the 5,000-item threshold)
# ---------------------------------------------------------------------------
Ensure-Index 'IntakeRequests' 'RequestNumber'
Ensure-Index 'IntakeRequests' 'Status'
Ensure-Index 'IntakeRequests' 'RoutedTeam'
Ensure-Index 'IntakeRequests' 'Owner'
Ensure-Index 'IntakeRequests' 'Requestor'
Ensure-Index 'IntakeTasks' 'RequestItemId'
Ensure-Index 'IntakeTasks' 'WorkPackageId'
Ensure-Index 'IntakeTasks' 'AssignedTo'
Ensure-Index 'IntakeWorkPackages' 'RequestItemId'
Ensure-Index 'IntakeAnswers' 'RequestItemId'
Ensure-Index 'IntakeAnswers' 'QuestionKey'
Ensure-Index 'IntakeInternalAnswers' 'RequestItemId'
Ensure-Index 'IntakeInternalAnswers' 'QuestionKey'
Ensure-Index 'IntakeActivity' 'RequestItemId'
Ensure-Index 'IntakeActivity' 'WorkPackageId'
Ensure-Index 'IntakeQuestionRules' 'Team'
Ensure-Index 'IntakeTeamMembers' 'Team'

# ---------------------------------------------------------------------------
# 3. Configuration seed (values from the proof of concept)
# ---------------------------------------------------------------------------
# Replace ManagerName/ManagerEmail with your own managers.
Seed-Rows 'IntakeTeams' @(
  @{ Title = 'Product Analytics'; ManagerName = 'Andre Lawson'; ManagerEmail = "AndreL@$EmailDomain"; FocusArea = 'Product & Pricing Data' },
  @{ Title = 'Campaign Strategy'; ManagerName = 'Carole Poland'; ManagerEmail = "CaroleP@$EmailDomain" },
  @{ Title = 'Application and Automation Development'; ManagerName = 'Elvia Atkins'; ManagerEmail = "ElviaA@$EmailDomain" },
  @{ Title = 'OMP'; ManagerName = 'Aisha West'; ManagerEmail = "AishaW@$EmailDomain" },
  @{ Title = 'P&BB DMO'; ManagerName = 'Kayo Miwa'; ManagerEmail = "KayoM@$EmailDomain" },
  @{ Title = 'AI / Model Team'; ManagerName = 'Babak Shammas'; ManagerEmail = "BabakS@$EmailDomain" },
  @{ Title = 'Intake Triage'; ManagerName = 'Daisy Phillips'; ManagerEmail = "DaisyP@$EmailDomain" },
  @{ Title = 'Customer Analytics'; ManagerName = 'Karin Blair'; ManagerEmail = "KarinB@$EmailDomain"; FocusArea = 'Customer & Segment Data' },
  @{ Title = 'Digital Analytics'; ManagerName = 'Brooke Gray'; ManagerEmail = "BrookeG@$EmailDomain"; FocusArea = 'Web & App Data' },
  @{ Title = 'Distribution and BB Analytics'; ManagerName = 'David Power'; ManagerEmail = "DavidP@$EmailDomain"; FocusArea = 'Distribution & Business Banking Data' },
  @{ Title = 'Channel Analytics & Reporting'; ManagerName = 'Cassandra Dunn'; ManagerEmail = "CassandraD@$EmailDomain"; FocusArea = 'Channel & Sales Data' },
  @{ Title = 'Virtual Connect Business Analytics'; ManagerName = 'Camille Cartier'; ManagerEmail = "CamilleC@$EmailDomain"; FocusArea = 'Virtual Connect Data' },
  @{ Title = 'Gen AI & Model Governance'; ManagerName = 'Ed Banti'; ManagerEmail = "EdB@$EmailDomain" }
)
# Replace LeadName/LeadEmail with your own sub-team leads.
Seed-Rows 'IntakeSubTeams' @(
  @{ Title = 'Customer BI & Reporting'; ParentTeam = 'Customer Analytics'; LeadName = 'Colin Ballinger'; LeadEmail = "ColinB@$EmailDomain" },
  @{ Title = 'Customer Analytics & Visualization'; ParentTeam = 'Customer Analytics'; LeadName = 'Daniela Mandera'; LeadEmail = "DanielaM@$EmailDomain" },
  @{ Title = 'Customer Analytics & Insights'; ParentTeam = 'Customer Analytics'; LeadName = 'Tyler Stein'; LeadEmail = "TylerS@$EmailDomain" },
  @{ Title = 'Analytics Strategy & Reporting'; ParentTeam = 'Customer Analytics'; LeadName = 'Celeste Burton'; LeadEmail = "celesteb@$EmailDomain" },
  @{ Title = 'External Insights'; ParentTeam = 'Customer Analytics'; LeadName = 'Lydia Bauer'; LeadEmail = "LydiaB@$EmailDomain" }
)
Seed-Rows 'IntakeRequestTypes' @(
  @{ Title = 'New Report / Dashboard'; Level1 = 'Reporting / Dashboard / Analytics'; AskFocusArea = $true; SortOrder = 1; IsActive = $true },
  @{ Title = 'Report / Dashboard Change'; Level1 = 'Reporting / Dashboard / Analytics'; AskFocusArea = $true; SortOrder = 2; IsActive = $true },
  @{ Title = 'Data Analysis / Extract'; Level1 = 'Reporting / Dashboard / Analytics'; AskFocusArea = $true; SortOrder = 3; IsActive = $true },
  @{ Title = 'Campaign / Offer'; Level1 = 'Campaign'; DefaultTeam = 'Campaign Strategy'; AskFocusArea = $false; SortOrder = 11; IsActive = $true },
  @{ Title = 'New App / Automation'; Level1 = 'App / Automation'; DefaultTeam = 'Application and Automation Development'; AskFocusArea = $false; SortOrder = 21; IsActive = $true },
  @{ Title = 'App / Automation Change'; Level1 = 'App / Automation'; DefaultTeam = 'Application and Automation Development'; AskFocusArea = $false; SortOrder = 22; IsActive = $true },
  @{ Title = 'Campaign / Offer'; Level1 = 'Offer / Incentive'; DefaultTeam = 'OMP'; AskFocusArea = $false; SortOrder = 31; IsActive = $true },
  @{ Title = 'Data Quality / Rule Change'; Level1 = 'Data Quality'; DefaultTeam = 'P&BB DMO'; AskFocusArea = $false; SortOrder = 41; IsActive = $true },
  @{ Title = 'Data Science / Model'; Level1 = 'Data Science / Modeling'; DefaultTeam = 'AI / Model Team'; AskFocusArea = $false; SortOrder = 51; IsActive = $true },
  @{ Title = 'IAAP Request'; Level1 = 'Data Risk Assessment'; DefaultTeam = 'P&BB DMO'; AskFocusArea = $false; SortOrder = 61; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Other / Not Sure'; DefaultTeam = 'Intake Triage'; AskFocusArea = $false; SortOrder = 71; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Reporting / Dashboard / Analytics'; AskFocusArea = $false; SortOrder = 4; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Campaign'; AskFocusArea = $false; SortOrder = 12; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'App / Automation'; AskFocusArea = $false; SortOrder = 23; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Offer / Incentive'; AskFocusArea = $false; SortOrder = 32; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Data Quality'; AskFocusArea = $false; SortOrder = 42; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Data Science / Modeling'; AskFocusArea = $false; SortOrder = 52; IsActive = $true },
  @{ Title = 'Other / Not Sure'; Level1 = 'Data Risk Assessment'; DefaultTeam = 'P&BB DMO'; AskFocusArea = $false; SortOrder = 62; IsActive = $true }
)
Seed-Rows 'IntakeQuestions' @(
  @{ Title = 'Source systems'; QuestionKey = 'source_systems'; QuestionType = 'Text'; HelpText = 'Where the data comes from, e.g. EDW, Salesforce, Adobe'; OwnerTeam = 'Shared'; IsActive = $true },
  @{ Title = 'Data classification'; QuestionKey = 'data_classification'; QuestionType = 'Choice'; Choices = "Public`nInternal`nConfidential`nRestricted"; OwnerTeam = 'Shared'; IsActive = $true },
  @{ Title = 'Privacy review needed'; QuestionKey = 'privacy_review'; QuestionType = 'Yes/No'; HelpText = 'Customer-level data usually needs a privacy review'; OwnerTeam = 'Shared'; IsActive = $true },
  @{ Title = 'Estimated effort (days)'; QuestionKey = 'effort_days'; QuestionType = 'Number'; OwnerTeam = 'Shared'; IsActive = $true },
  @{ Title = 'Contains PII'; QuestionKey = 'pii_included'; QuestionType = 'Yes/No'; OwnerTeam = 'Shared'; IsActive = $true },
  @{ Title = 'Reporting tool'; QuestionKey = 'reporting_tool'; QuestionType = 'Choice'; Choices = "Power BI`nTableau`nExcel`nOther"; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Refresh cadence'; QuestionKey = 'refresh_cadence'; QuestionType = 'Choice'; Choices = "Daily`nWeekly`nMonthly`nAd hoc"; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Expected audience (people)'; QuestionKey = 'audience_size'; QuestionType = 'Number'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Target go-live'; QuestionKey = 'target_go_live'; QuestionType = 'Date'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Existing report name or link'; QuestionKey = 'existing_report'; QuestionType = 'Text'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Change type'; QuestionKey = 'change_type'; QuestionType = 'Choice'; Choices = "Visual / layout`nBusiness logic`nData source`nAccess / security"; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Regression test needed'; QuestionKey = 'regression_test'; QuestionType = 'Yes/No'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Analysis method'; QuestionKey = 'analysis_method'; QuestionType = 'Choice'; Choices = "Descriptive`nSegmentation`nPredictive model`nCausal / test-and-learn"; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Output format'; QuestionKey = 'output_format'; QuestionType = 'Choice'; Choices = "CSV extract`nExcel workbook`nPresentation deck`nTable in data warehouse"; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Customer population and filters'; QuestionKey = 'customer_population'; QuestionType = 'Long text'; HelpText = 'Which customers are in scope and how they are filtered'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'Estimated rows'; QuestionKey = 'row_estimate'; QuestionType = 'Number'; OwnerTeam = 'Customer Analytics'; IsActive = $true },
  @{ Title = 'New / Incremental Revenue (5-Year)'; QuestionKey = 'omp_revenue'; QuestionType = 'Choice'; Choices = ">`$20MM|2`n`$10MM–`$20MM|1`n<`$10MM|0"; HelpText = 'Estimated new or incremental revenue over five years'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Channel Enablement'; QuestionKey = 'omp_channel'; QuestionType = 'Choice'; Choices = "Existing pattern|2`nSome modification required|1`nMaterial new build required|0"; HelpText = 'How much channel build the offer needs'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Does this change an existing offer?'; QuestionKey = 'omp_existing_offer'; QuestionType = 'Yes/No'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Existing offer code'; QuestionKey = 'omp_offer_code'; QuestionType = 'Text'; HelpText = 'The code of the offer being changed'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Target launch date'; QuestionKey = 'omp_target_launch'; QuestionType = 'Date'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Legal / compliance review needed'; QuestionKey = 'omp_legal_review'; QuestionType = 'Yes/No'; OwnerTeam = 'OMP'; IsActive = $true },
  @{ Title = 'Accountable data owner'; QuestionKey = 'dmo_data_owner'; QuestionType = 'Text'; HelpText = 'The business owner accountable for the data this work uses or changes'; OwnerTeam = 'P&BB DMO'; IsActive = $true }
)
Seed-Rows 'IntakeQuestionRules' @(
  @{ Title = 'Customer Analytics · Any type · source_systems'; QuestionKey = 'source_systems'; Team = 'Customer Analytics'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 1; IsActive = $true },
  @{ Title = 'Customer Analytics · Any type · data_classification'; QuestionKey = 'data_classification'; Team = 'Customer Analytics'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 2; IsActive = $true },
  @{ Title = 'Customer Analytics · Any type · privacy_review'; QuestionKey = 'privacy_review'; Team = 'Customer Analytics'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 3; IsActive = $true },
  @{ Title = 'Customer Analytics · Any type · effort_days'; QuestionKey = 'effort_days'; Team = 'Customer Analytics'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 4; IsActive = $true },
  @{ Title = 'Customer Analytics · New Report / Dashboard · reporting_tool'; QuestionKey = 'reporting_tool'; Team = 'Customer Analytics'; RequestTypeL2 = 'New Report / Dashboard'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 10; IsActive = $true },
  @{ Title = 'Customer Analytics · New Report / Dashboard · refresh_cadence'; QuestionKey = 'refresh_cadence'; Team = 'Customer Analytics'; RequestTypeL2 = 'New Report / Dashboard'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 11; IsActive = $true },
  @{ Title = 'Customer Analytics · New Report / Dashboard · audience_size'; QuestionKey = 'audience_size'; Team = 'Customer Analytics'; RequestTypeL2 = 'New Report / Dashboard'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 12; IsActive = $true },
  @{ Title = 'Customer Analytics · New Report / Dashboard · target_go_live'; QuestionKey = 'target_go_live'; Team = 'Customer Analytics'; RequestTypeL2 = 'New Report / Dashboard'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 13; IsActive = $true },
  @{ Title = 'Customer Analytics · Report / Dashboard Change · existing_report'; QuestionKey = 'existing_report'; Team = 'Customer Analytics'; RequestTypeL2 = 'Report / Dashboard Change'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 10; IsActive = $true },
  @{ Title = 'Customer Analytics · Report / Dashboard Change · change_type'; QuestionKey = 'change_type'; Team = 'Customer Analytics'; RequestTypeL2 = 'Report / Dashboard Change'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 11; IsActive = $true },
  @{ Title = 'Customer Analytics · Report / Dashboard Change · regression_test'; QuestionKey = 'regression_test'; Team = 'Customer Analytics'; RequestTypeL2 = 'Report / Dashboard Change'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 12; IsActive = $true },
  @{ Title = 'Customer Analytics · Data Analysis / Extract · analysis_method'; QuestionKey = 'analysis_method'; Team = 'Customer Analytics'; RequestTypeL2 = 'Data Analysis / Extract'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 10; IsActive = $true },
  @{ Title = 'Customer Analytics · Data Analysis / Extract · output_format'; QuestionKey = 'output_format'; Team = 'Customer Analytics'; RequestTypeL2 = 'Data Analysis / Extract'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 11; IsActive = $true },
  @{ Title = 'Customer Analytics · Data Analysis / Extract · customer_population'; QuestionKey = 'customer_population'; Team = 'Customer Analytics'; RequestTypeL2 = 'Data Analysis / Extract'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 12; IsActive = $true },
  @{ Title = 'Customer Analytics · Data Analysis / Extract · row_estimate'; QuestionKey = 'row_estimate'; Team = 'Customer Analytics'; RequestTypeL2 = 'Data Analysis / Extract'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 13; IsActive = $true },
  @{ Title = 'Customer Analytics · Data Analysis / Extract · pii_included'; QuestionKey = 'pii_included'; Team = 'Customer Analytics'; RequestTypeL2 = 'Data Analysis / Extract'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 14; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_revenue'; QuestionKey = 'omp_revenue'; Team = 'OMP'; Audience = 'Requestor'; IsRequired = $true; IsScored = $true; SortOrder = 1; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_channel'; QuestionKey = 'omp_channel'; Team = 'OMP'; Audience = 'Requestor'; IsRequired = $true; IsScored = $true; SortOrder = 2; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_existing_offer'; QuestionKey = 'omp_existing_offer'; Team = 'OMP'; Audience = 'Requestor'; IsRequired = $false; IsScored = $false; SortOrder = 3; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_offer_code'; QuestionKey = 'omp_offer_code'; Team = 'OMP'; Audience = 'Requestor'; IsRequired = $false; IsScored = $false; SortOrder = 4; ShowIfKey = 'omp_existing_offer'; ShowIfValue = 'Yes'; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_target_launch'; QuestionKey = 'omp_target_launch'; Team = 'OMP'; Audience = 'Requestor'; IsRequired = $false; IsScored = $false; SortOrder = 5; IsActive = $true },
  @{ Title = 'OMP · Any type · data_classification'; QuestionKey = 'data_classification'; Team = 'OMP'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 1; IsActive = $true },
  @{ Title = 'OMP · Any type · effort_days'; QuestionKey = 'effort_days'; Team = 'OMP'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 2; IsActive = $true },
  @{ Title = 'OMP · Any type · omp_legal_review'; QuestionKey = 'omp_legal_review'; Team = 'OMP'; Audience = 'Internal'; IsRequired = $false; IsScored = $false; SortOrder = 3; IsActive = $true },
  @{ Title = 'P&BB DMO · Any type · dmo_data_owner'; QuestionKey = 'dmo_data_owner'; Team = 'P&BB DMO'; Audience = 'Requestor'; IsRequired = $true; IsScored = $false; SortOrder = 1; IsActive = $true },
  @{ Title = 'P&BB DMO · Any type · pii_included'; QuestionKey = 'pii_included'; Team = 'P&BB DMO'; Audience = 'Requestor'; IsRequired = $true; IsScored = $false; SortOrder = 2; IsActive = $true }
)
Seed-Rows 'IntakeQAConfig' @(
  @{ Title = 'New report / dashboard (POC)'; Level1 = 'Reporting / Dashboard / Analytics'; Level2 = 'New Report / Dashboard'; RequiresQA = $true },
  @{ Title = 'New app / automation'; Level1 = 'App / Automation'; Level2 = 'New App / Automation'; RequiresQA = $true }
)
# Allowed stage changes. Flow F2 rejects any change that has no matching row.
Seed-Rows 'IntakeTransitions' @(
  @{ Title = 'Submitted > Queued (Manager)'; FromStage = 'Submitted'; ToStage = 'Queued'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Queued'; IsActive = $true },
  @{ Title = 'Submitted > Assigned / Under Review (Manager)'; FromStage = 'Submitted'; ToStage = 'Assigned / Under Review'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Assigned/Under Review'; IsActive = $true },
  @{ Title = 'Queued > Assigned / Under Review (Manager)'; FromStage = 'Queued'; ToStage = 'Assigned / Under Review'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Assigned/Under Review'; IsActive = $true },
  @{ Title = 'Assigned / Under Review > Requirements sign-off (Owner)'; FromStage = 'Assigned / Under Review'; ToStage = 'Requirements sign-off'; AllowedRole = 'Owner'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Assigned/Under Review'; IsActive = $true },
  @{ Title = 'Requirements sign-off > Approved (Requestor)'; FromStage = 'Requirements sign-off'; ToStage = 'Approved'; AllowedRole = 'Requestor'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Approved'; IsActive = $true },
  @{ Title = 'Requirements sign-off > Assigned / Under Review (Requestor)'; FromStage = 'Requirements sign-off'; ToStage = 'Assigned / Under Review'; AllowedRole = 'Requestor'; ReasonRequired = $true; Lifecycle = 'Standard'; RequestStatus = 'Assigned/Under Review'; IsActive = $true },
  @{ Title = 'Approved > In Progress (Owner)'; FromStage = 'Approved'; ToStage = 'In Progress'; AllowedRole = 'Owner'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'In progress'; IsActive = $true },
  @{ Title = 'In Progress > QA Testing (Manager)'; FromStage = 'In Progress'; ToStage = 'QA Testing'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'QA Testing'; IsActive = $true },
  @{ Title = 'In Progress > QA Testing (System)'; FromStage = 'In Progress'; ToStage = 'QA Testing'; AllowedRole = 'System'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'QA Testing'; IsActive = $true },
  @{ Title = 'In Progress > DML Approval (Owner)'; FromStage = 'In Progress'; ToStage = 'DML Approval'; AllowedRole = 'Owner'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'DML Approval'; IsActive = $true },
  @{ Title = 'In Progress > Acceptance sign-off (Owner)'; FromStage = 'In Progress'; ToStage = 'Acceptance sign-off'; AllowedRole = 'Owner'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Delivered/Pending Business Approval'; IsActive = $true },
  @{ Title = 'QA Testing > Acceptance sign-off (Manager)'; FromStage = 'QA Testing'; ToStage = 'Acceptance sign-off'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Delivered/Pending Business Approval'; IsActive = $true },
  @{ Title = 'DML Approval > Acceptance sign-off (DML)'; FromStage = 'DML Approval'; ToStage = 'Acceptance sign-off'; AllowedRole = 'DML'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Delivered/Pending Business Approval'; IsActive = $true },
  @{ Title = 'DML Approval > In Progress (DML)'; FromStage = 'DML Approval'; ToStage = 'In Progress'; AllowedRole = 'DML'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'In progress'; IsActive = $true },
  @{ Title = 'Acceptance sign-off > Closed (Requestor)'; FromStage = 'Acceptance sign-off'; ToStage = 'Closed'; AllowedRole = 'Requestor'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Closed'; IsActive = $true },
  @{ Title = 'Acceptance sign-off > In Progress (Requestor)'; FromStage = 'Acceptance sign-off'; ToStage = 'In Progress'; AllowedRole = 'Requestor'; ReasonRequired = $true; Lifecycle = 'Standard'; RequestStatus = 'In progress'; IsActive = $true },
  @{ Title = 'In Progress > Closed (Manager)'; FromStage = 'In Progress'; ToStage = 'Closed'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'Standard'; RequestStatus = 'Closed'; IsActive = $true },
  @{ Title = 'Closed > In Progress (Manager)'; FromStage = 'Closed'; ToStage = 'In Progress'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'In progress'; IsActive = $true },
  @{ Title = 'Submitted > Queued (Manager)'; FromStage = 'Submitted'; ToStage = 'Queued'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'IAAP'; RequestStatus = 'Queued'; IsActive = $true },
  @{ Title = 'Queued > In Progress (Manager)'; FromStage = 'Queued'; ToStage = 'In Progress'; AllowedRole = 'Manager'; ReasonRequired = $false; Lifecycle = 'IAAP'; RequestStatus = 'In progress'; IsActive = $true },
  @{ Title = 'In Progress > DML Approval (Owner)'; FromStage = 'In Progress'; ToStage = 'DML Approval'; AllowedRole = 'Owner'; ReasonRequired = $false; Lifecycle = 'IAAP'; RequestStatus = 'DML Approval'; IsActive = $true },
  @{ Title = 'DML Approval > Closed (DML)'; FromStage = 'DML Approval'; ToStage = 'Closed'; AllowedRole = 'DML'; ReasonRequired = $false; Lifecycle = 'IAAP'; RequestStatus = 'Closed'; IsActive = $true },
  @{ Title = 'Submitted > Rejected (Manager)'; FromStage = 'Submitted'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'Queued > Rejected (Manager)'; FromStage = 'Queued'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'Assigned / Under Review > Rejected (Manager)'; FromStage = 'Assigned / Under Review'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'Requirements sign-off > Rejected (Manager)'; FromStage = 'Requirements sign-off'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'Approved > Rejected (Manager)'; FromStage = 'Approved'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'In Progress > Rejected (Manager)'; FromStage = 'In Progress'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'QA Testing > Rejected (Manager)'; FromStage = 'QA Testing'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true },
  @{ Title = 'DML Approval > Rejected (Manager)'; FromStage = 'DML Approval'; ToStage = 'Rejected'; AllowedRole = 'Manager'; ReasonRequired = $true; Lifecycle = 'Any'; RequestStatus = 'Cancelled'; IsActive = $true }
)

# ---------------------------------------------------------------------------
# 4. Permissions (section 4.3 of the guide). Review with your SharePoint admin first.
# ---------------------------------------------------------------------------
if (-not $SkipPermissions) {
  $groups = 'Intake Requestors','Intake Team Members','Intake Managers','Intake Admins'
  foreach ($g in $groups) {
    if (-not (Get-PnPGroup -Identity $g -ErrorAction SilentlyContinue)) { New-PnPGroup -Title $g | Out-Null; Write-Host "Created group $g" }
  }
  # Requestors read/edit only items they created on IntakeRequests and IntakeAnswers.
  foreach ($l in 'IntakeRequests','IntakeAnswers') {
    Set-PnPList -Identity $l -ReadSecurity 2 -WriteSecurity 2 | Out-Null   # 2 = only own items
  }
  # Internal answers: break inheritance, team members and managers only.
  Set-PnPList -Identity 'IntakeInternalAnswers' -BreakRoleInheritance -CopyRoleAssignments:$false | Out-Null
  Set-PnPListPermission -Identity 'IntakeInternalAnswers' -Group 'Intake Team Members' -AddRole 'Contribute'
  Set-PnPListPermission -Identity 'IntakeInternalAnswers' -Group 'Intake Managers' -AddRole 'Contribute'
  Set-PnPListPermission -Identity 'IntakeInternalAnswers' -Group 'Intake Admins' -AddRole 'Full Control'
  # Activity: written by flows only; everyone reads.
  Set-PnPList -Identity 'IntakeActivity' -BreakRoleInheritance -CopyRoleAssignments:$false | Out-Null
  foreach ($g in 'Intake Requestors','Intake Team Members','Intake Managers') { Set-PnPListPermission -Identity 'IntakeActivity' -Group $g -AddRole 'Read' }
  Set-PnPListPermission -Identity 'IntakeActivity' -Group 'Intake Admins' -AddRole 'Full Control'
  Write-Host "Permissions applied. Add your flow service account to 'Intake Admins'." -ForegroundColor Yellow
  Write-Host "Item-level 'own items' settings do not apply to people with Manage Lists rights; give team and manager groups a permission level with Override List Behaviors." -ForegroundColor Yellow
}

# ---------------------------------------------------------------------------
# 5. Documents library: one folder per intake is created by flow F1; nothing to do here.
# ---------------------------------------------------------------------------
Write-Host "Done. Next: add these lists as data sources in the canvas app (see the prompt pack, S01)." -ForegroundColor Green
