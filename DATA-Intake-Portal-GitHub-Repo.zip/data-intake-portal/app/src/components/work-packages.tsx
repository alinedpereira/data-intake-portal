import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Boxes, CheckCircle2, ChevronDown, ChevronRight, Plus, Trash2, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PersonPicker } from "@/components/person-picker";
import { FolderFiles } from "@/components/request-files";
import { Link } from "react-router-dom";
import { useConfirm } from "@/hooks/use-confirm";
import { appendLog, formatDate, isLockedStatus, requestNumber, statusOf, type IntakeRequest } from "@/lib/intake";
import { personWrite, type Person } from "@/lib/people";
import { actorName, useAppStore } from "@/lib/store";
import { taskStatusOf, updateTask, useTaskPage, type IntakeTask } from "@/lib/tasks";
import { cn } from "@/lib/utils";
import {
  createWorkPackage,
  deleteWorkPackage,
  invalidateWorkPackages,
  logToIntake,
  updateWorkPackage,
  useSubTeams,
  useWorkPackages,
  wpFolder,
  WP_STAGES,
  wpStage,
  wpStatusOf,
  type WorkPackage,
  type WorkPackageWrite,
  type WpStatus,
} from "@/lib/workpackages";
import { queryClient } from "@/lib/query-client";

const PERSON_ODATA_TYPE = "#Microsoft.Azure.Connectors.SharePoint.SPListExpandedUser";

const TONE: Record<WpStatus, string> = {
  "Not started": "bg-muted text-foreground",
  Requirements: "bg-accent text-accent-foreground",
  "QA/Review": "bg-accent text-accent-foreground",
  "In progress": "bg-primary text-primary-foreground",
  "Ready for acceptance": "bg-amber-100 text-amber-900 dark:bg-amber-900 dark:text-amber-100",
  Accepted: "bg-emerald-700 text-white",
  "Sent back": "bg-red-100 text-red-900 dark:bg-red-900 dark:text-red-100",
};

/** Compact stage indicator: one bar per stage, filled up to the current one. */
function StageDots({ status }: { status: WpStatus }) {
  const current = (WP_STAGES as readonly string[]).indexOf(wpStage(status));
  return (
    <span className="mt-1 flex items-center gap-1" role="img" aria-label={`Stage ${current + 1} of ${WP_STAGES.length}: ${wpStage(status)}`}>
      {WP_STAGES.map((s, i) => (
        <span
          key={s}
          title={s}
          className={cn("h-1.5 w-6 rounded-full", i < current || status === "Accepted" ? "bg-emerald-700" : i === current ? "bg-primary" : "bg-border")}
        />
      ))}
      <span className="ml-1 text-xs text-muted-foreground">{wpStage(status)}</span>
    </span>
  );
}

export function WpStatusPill({ status }: { status: WpStatus }) {
  return <span className={cn("inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", TONE[status])}>{status}</span>;
}

/** Work packages for one intake: manager plans them, owners deliver, the requestor accepts each one. */
export function WorkPackagesSection({ r }: { r: IntakeRequest }) {
  const role = useAppStore((s) => s.role);
  const me = useAppStore((s) => s.me);
  const actor = useAppStore(actorName);
  const confirm = useConfirm();
  const q = useWorkPackages(r.ID);
  const tasksQ = useTaskPage(role === "Requestor" ? undefined : `RequestItemId eq ${Number(r.ID)}`, undefined, 200);
  const [editing, setEditing] = useState<"new" | null>(null);
  const [sendingBack, setSendingBack] = useState<WorkPackage | null>(null);
  const [open, setOpen] = useState<Record<number, boolean>>({});
  const isManager = role === "Manager";
  const locked = isLockedStatus(statusOf(r));
  const rows = q.data ?? [];
  const accepted = rows.filter((w) => wpStatusOf(w) === "Accepted").length;
  const allAccepted = rows.length > 0 && accepted === rows.length;
  const tasksByWp = new Map<number, IntakeTask[]>();
  for (const t of tasksQ.data?.rows ?? []) {
    if (!t.WorkPackageId) continue;
    tasksByWp.set(t.WorkPackageId, [...(tasksByWp.get(t.WorkPackageId) ?? []), t]);
  }
  const isOwner = (w: WorkPackage) => !!me?.Email && w.WPOwner?.Email?.toLowerCase() === me.Email.toLowerCase();

  const act = useMutation({
    mutationFn: async ({ w, to, note, extra }: { w: WorkPackage; to?: WpStatus; note: string; extra?: WorkPackageWrite }) => {
      await updateWorkPackage(w.ID as number, {
        ...(to ? { WPStatus: { Value: to } } : {}),
        ...extra,
        WPActivity: appendLog(w.WPActivity, { at: new Date().toISOString(), by: actor, role, text: note }),
      });
      await logToIntake(r.ID as number, { by: actor, role, text: `WP ${rows.indexOf(w) + 1} "${w.Title}": ${note}` });
    },
    onSuccess: (_d, { to }) => {
      invalidateWorkPackages();
      toast.success(to ? `Work package ${to === "Accepted" ? "accepted" : `moved to ${to}`}` : "Saved");
    },
    onError: () => toast.error("The change could not be saved. Please try again."),
  });

  const remove = useMutation({
    mutationFn: async (w: WorkPackage) => {
      for (const t of tasksByWp.get(w.ID as number) ?? []) {
        await updateTask(t.ID as number, { WorkPackageId: null as unknown as undefined });
      }
      await deleteWorkPackage(w.ID as number);
      await logToIntake(r.ID as number, { by: actor, role, text: `Work package "${w.Title}" removed` });
    },
    onSuccess: () => {
      invalidateWorkPackages();
      void queryClient.invalidateQueries({ queryKey: ["tasks"] });
      toast.success("Work package removed");
    },
    onError: () => toast.error("The work package could not be removed. Please try again."),
  });

  if (q.isPending) return null;
  if (q.isError) {
    return (
      <p role="alert" className="text-sm text-destructive">
        Work packages could not be loaded. <button type="button" className="underline" onClick={() => void q.refetch()}>Retry</button>
      </p>
    );
  }
  if (rows.length === 0 && !isManager) return null;

  return (
    <section aria-labelledby="wp-h" className="overflow-hidden rounded-lg border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-l-4 border-primary bg-accent px-4 py-2.5 text-accent-foreground">
        <h2 id="wp-h" className="flex items-center gap-2 font-semibold">
          <Boxes className="size-5" aria-hidden="true" /> Work packages
          {rows.length > 0 && <span className="text-sm font-normal">· {accepted} of {rows.length} accepted</span>}
        </h2>
        {isManager && !locked && (
          <Button size="sm" onClick={() => setEditing("new")}>
            <Plus aria-hidden="true" /> Add work package
          </Button>
        )}
      </div>

      {rows.length > 0 && (
        <div className="px-4 pt-3">
          <div className="flex h-2 overflow-hidden rounded-full bg-muted" role="img" aria-label={`${accepted} of ${rows.length} work packages accepted`}>
            <div className="bg-emerald-700" style={{ width: `${(accepted / rows.length) * 100}%` }} />
          </div>
          {allAccepted && (
            <p className="mt-2 flex items-center gap-2 text-sm font-semibold text-emerald-800 dark:text-emerald-300">
              <CheckCircle2 className="size-4" aria-hidden="true" />
              All work packages accepted.{isManager ? " Close the intake when you're ready." : role === "Requestor" ? " The manager will close the intake." : ""}
            </p>
          )}
        </div>
      )}

      {rows.length === 0 ? (
        <p className="p-4 text-sm text-muted-foreground">
          No work packages yet. Break this intake into work packages, each owned by a Customer Analytics sub-team.
        </p>
      ) : (
        <ol className="divide-y divide-border">
          {rows.map((w, i) => {
            const st = wpStatusOf(w);
            const tasks = tasksByWp.get(w.ID as number) ?? [];
            const done = tasks.filter((t) => taskStatusOf(t) === "Done").length;
            const canWork = !locked && (isManager || (role === "Assignee" && isOwner(w)));
            const expanded = open[w.ID as number] ?? false;
            return (
              <li key={w.ID} className="space-y-2 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <p className="font-semibold">
                      <span className="mr-2 text-sm text-primary">WP {i + 1}</span>
                      {role === "Requestor" ? (
                        w.Title
                      ) : (
                        <Link to={`/workpackages/${w.ID}`} className="text-primary underline-offset-2 hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                          {w.Title}
                        </Link>
                      )}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {w.SubTeam ?? "No sub-team"} · {w.WPOwner?.DisplayName ?? "No owner"}
                      {w.WPDueDate ? ` · due ${formatDate(w.WPDueDate)}` : ""}
                      {role !== "Requestor" ? ` · ${tasks.length ? `${done} of ${tasks.length} tasks done` : "no tasks yet"}` : ""}
                    </p>
                    <StageDots status={st} />
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <WpStatusPill status={st} />
                    {isManager && !locked && (
                      <>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-7 px-2 text-destructive hover:text-destructive"
                          title="Remove this work package"
                          aria-label={`Remove WP ${i + 1}`}
                          disabled={remove.isPending}
                          onClick={async () => {
                            const ok = await confirm({
                              title: `Remove "${w.Title}"?`,
                              description: tasks.length ? `Its ${tasks.length} task(s) stay on the intake but are no longer in a work package.` : "This can't be undone.",
                              confirmLabel: "Remove",
                              destructive: true,
                            });
                            if (ok) remove.mutate(w);
                          }}
                        >
                          <Trash2 aria-hidden="true" /> Remove
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                {w.WPDescription && <p className="whitespace-pre-wrap text-sm">{w.WPDescription}</p>}

                <div className="flex flex-wrap gap-2">
                  {role === "Requestor" && st === "Ready for acceptance" && (
                    <>
                      <Button size="sm" disabled={act.isPending} onClick={() => act.mutate({ w, to: "Accepted", note: "Accepted by requestor (complete)" })}>
                        <CheckCircle2 aria-hidden="true" /> Accept
                      </Button>
                      <Button size="sm" variant="outline" disabled={act.isPending} onClick={() => setSendingBack(w)}>
                        <Undo2 aria-hidden="true" /> Send back
                      </Button>
                    </>
                  )}
                  {role === "Requestor" ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      aria-expanded={expanded}
                      onClick={() => setOpen((o) => ({ ...o, [w.ID as number]: !expanded }))}
                    >
                      {expanded ? <ChevronDown aria-hidden="true" /> : <ChevronRight aria-hidden="true" />}
                      Files
                    </Button>
                  ) : (
                    <Button asChild size="sm" variant={canWork ? "default" : "outline"}>
                      <Link to={`/workpackages/${w.ID}`}>
                        {canWork ? "Open and manage" : "Open"} <ChevronRight aria-hidden="true" />
                      </Link>
                    </Button>
                  )}
                </div>
                {st === "Ready for acceptance" && role !== "Requestor" && (
                  <p className="text-xs text-muted-foreground">Waiting for the requestor to accept this work package.</p>
                )}

                {expanded && role === "Requestor" && (
                  <div className="space-y-3 rounded-md border border-border bg-muted/30 p-3">
                    {role !== "Requestor" && (
                      tasks.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No tasks in this work package yet.</p>
                      ) : (
                        <ul className="space-y-1 text-sm">
                          {tasks.map((t) => (
                            <li key={t.ID} className="flex flex-wrap items-center justify-between gap-2">
                              <span>{t.Title}</span>
                              <span className="text-xs text-muted-foreground">
                                {t.AssignedTo?.DisplayName ?? "Unassigned"} · {taskStatusOf(t)}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )
                    )}
                    {r.RequestNumber && w.ID && (
                      <FolderFiles folder={wpFolder(r.RequestNumber, w.ID)} title={`Files for WP ${i + 1}`} readOnly={!canWork} compact />
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ol>
      )}

      {editing && (
        <WorkPackageDialog
          r={r}
          nextOrder={rows.length + 1}
          onClose={() => setEditing(null)}
        />
      )}
      {sendingBack && (
        <SendBackDialog
          wp={sendingBack}
          busy={act.isPending}
          onClose={() => setSendingBack(null)}
          onSend={(reason) => {
            act.mutate({ w: sendingBack, to: "Sent back", note: `Sent back by requestor: ${reason}` });
            setSendingBack(null);
          }}
        />
      )}
    </section>
  );
}

function SendBackDialog({ wp, busy, onClose, onSend }: { wp: WorkPackage; busy: boolean; onClose: () => void; onSend: (reason: string) => void }) {
  const [reason, setReason] = useState("");
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send back "{wp.Title}"</DialogTitle>
          <DialogDescription>Say what needs to change. The owner sees your reason in the activity history.</DialogDescription>
        </DialogHeader>
        <Label htmlFor="wp-sendback">Reason</Label>
        <Textarea id="wp-sendback" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} />
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button disabled={busy || !reason.trim()} onClick={() => onSend(reason.trim())}>Send back</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Manager: create or edit a work package. The owner defaults to the sub-team lead. */
function WorkPackageDialog({ r, wp, nextOrder, onClose }: { r: IntakeRequest; wp?: WorkPackage; nextOrder: number; onClose: () => void }) {
  const actor = useAppStore(actorName);
  const role = useAppStore((s) => s.role);
  const subTeams = useSubTeams();
  const [title, setTitle] = useState(wp?.Title ?? "");
  const [description, setDescription] = useState(wp?.WPDescription ?? "");
  const [subTeam, setSubTeam] = useState(wp?.SubTeam ?? "");
  const [owner, setOwner] = useState<Person | null>(wp?.WPOwner?.Claims ? wp.WPOwner : null);
  const [due, setDue] = useState(wp?.WPDueDate ? wp.WPDueDate.slice(0, 10) : "");

  const pickSubTeam = (name: string) => {
    setSubTeam(name);
    const lead = subTeams.data?.find((s) => s.name === name);
    if (lead?.leadEmail && (!owner || !wp)) {
      setOwner({
        "@odata.type": PERSON_ODATA_TYPE,
        Claims: `i:0#.f|membership|${lead.leadEmail.toLowerCase()}`,
        DisplayName: lead.leadName,
        Email: lead.leadEmail,
        Picture: "",
        Department: "",
        JobTitle: "",
      });
    }
  };

  const save = useMutation({
    mutationFn: async () => {
      const dueIso = due ? `${due}T12:00:00Z` : undefined;
      if (wp) {
        const changes: WorkPackageWrite = {};
        const notes: string[] = [];
        if (title.trim() !== wp.Title) { changes.Title = title.trim(); notes.push(`title "${title.trim()}"`); }
        if (description.trim() !== (wp.WPDescription ?? "")) changes.WPDescription = description.trim();
        if (subTeam !== (wp.SubTeam ?? "")) { changes.SubTeam = subTeam; notes.push(`sub-team ${subTeam}`); }
        if (owner && owner.Claims !== wp.WPOwner?.Claims) { changes.WPOwner = personWrite(owner); notes.push(`owner ${owner.DisplayName}`); }
        if ((wp.WPDueDate?.slice(0, 10) ?? "") !== due) { changes.WPDueDate = dueIso; notes.push(`due ${due || "cleared"}`); }
        if (Object.keys(changes).length === 0) return;
        const note = notes.length ? `Updated: ${notes.join(", ")}` : "Description updated";
        await updateWorkPackage(wp.ID as number, { ...changes, WPActivity: appendLog(wp.WPActivity, { at: new Date().toISOString(), by: actor, role, text: note }) });
      } else {
        await createWorkPackage({
          Title: title.trim(),
          RequestItemId: r.ID,
          RequestNumber: requestNumber(r),
          WPDescription: description.trim() || undefined,
          SubTeam: subTeam || undefined,
          WPOwner: owner ? personWrite(owner) : undefined,
          WPDueDate: dueIso,
          SortOrder: nextOrder,
          WPStatus: { Value: "Not started" },
          WPActivity: appendLog(undefined, { at: new Date().toISOString(), by: actor, role, text: "Work package created" }),
        });
        await logToIntake(r.ID as number, {
          by: actor,
          role,
          text: `Work package "${title.trim()}" created for ${subTeam || "no sub-team"}${owner ? `, owner ${owner.DisplayName}` : ""}`,
        });
      }
    },
    onSuccess: () => {
      invalidateWorkPackages();
      toast.success(wp ? "Work package saved" : "Work package added");
      onClose();
    },
    onError: () => toast.error("The work package could not be saved. Please try again."),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && !save.isPending && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{wp ? "Edit work package" : "New work package"}</DialogTitle>
          <DialogDescription>{requestNumber(r)} · {r.Title}</DialogDescription>
        </DialogHeader>
        <form
          id="wp-form"
          className="grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (title.trim()) save.mutate();
          }}
        >
          <div className="grid gap-1.5">
            <Label htmlFor="wp-title">Work package</Label>
            <Input id="wp-title" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Segmentation model" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="wp-desc">Description</Label>
            <Textarea id="wp-desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Scope and definition of done" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="wp-subteam">Sub-team</Label>
              <div className="[&>[data-slot=native-select-wrapper]]:w-full">
                <NativeSelect id="wp-subteam" value={subTeam} onChange={(e) => pickSubTeam(e.target.value)} disabled={subTeams.isPending} className="bg-card">
                  <NativeSelectOption value="">{subTeams.isPending ? "Loading…" : "Choose a sub-team"}</NativeSelectOption>
                  {(subTeams.data ?? []).map((s) => (
                    <NativeSelectOption key={s.name} value={s.name}>{s.name}</NativeSelectOption>
                  ))}
                </NativeSelect>
              </div>
              {subTeams.isError && <p role="alert" className="text-xs text-destructive">Sub-teams could not be loaded.</p>}
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="wp-due">Due date</Label>
              <Input id="wp-due" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="wp-owner">Owner</Label>
            <PersonPicker id="wp-owner" field="TaskAssignedTo" value={owner} onChange={setOwner} />
            <p className="text-xs text-muted-foreground">Defaults to the sub-team lead. Change it to anyone in the sub-team.</p>
          </div>
        </form>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" form="wp-form" disabled={save.isPending || !title.trim()}>
            {save.isPending ? "Saving…" : wp ? "Save" : "Add work package"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
