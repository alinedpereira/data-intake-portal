import { useQuery } from "@tanstack/react-query";
import { IntakeRequestsService, IntakeTasksService } from "../../generated";
import type { IntakeTasksRead, IntakeTasksWrite } from "../../generated/models/IntakeTasksModel";
import { appendLog, parseChoices, updateRequest } from "@/lib/intake";
import { startQaFromTask } from "@/lib/qa";
import { actorName, useAppStore } from "@/lib/store";

export type IntakeTask = IntakeTasksRead;
export type TaskWrite = Partial<Omit<IntakeTasksWrite, "ID">>;

export const TASK_SELECT = [
  "ID",
  "Title",
  "RequestItemId",
  "RequestNumber",
  "RequestTitle",
  "AssignedTo",
  "DueDate",
  "TaskStatus",
  "TaskType",
  "TaskNotes",
  "TaskActivity",
  "CreatedByName",
  "WorkPackageId",
  "Modified",
];

export const TASK_PAGE = 100;

export function taskStatusOf(t: IntakeTask): string {
  return t.TaskStatus?.Value ?? "Not started";
}

export function isTaskOverdue(t: IntakeTask): boolean {
  if (!t.DueDate || taskStatusOf(t) === "Done") return false;
  return new Date(t.DueDate).getTime() < Date.now();
}

export function useTaskStatuses() {
  return useTaskChoices("TaskStatus");
}

export function useTaskTypes() {
  return useTaskChoices("TaskType");
}

function useTaskChoices(field: "TaskStatus" | "TaskType") {
  return useQuery({
    queryKey: ["task-choices", field],
    staleTime: 10 * 60 * 1000,
    queryFn: async () => {
      const result = await IntakeTasksService.getReferencedEntity("", field);
      if (!result.success) {
        console.error("task choice options failed", field, result.error);
        throw new Error("Unable to load task options.");
      }
      return parseChoices(result.data);
    },
  });
}

export function useTaskPage(filter: string | undefined, skipToken: string | undefined, top = TASK_PAGE) {
  return useQuery({
    queryKey: ["tasks", { filter, skipToken, top }],
    queryFn: async () => {
      const result = await IntakeTasksService.getAll({
        select: TASK_SELECT,
        filter,
        orderBy: ["ID desc"],
        top,
        skipToken,
      });
      if (!result.success) {
        console.error("task list load failed", result.error);
        throw new Error("Unable to load tasks.");
      }
      return { rows: result.data ?? [], nextToken: result.skipToken?.trim() || undefined };
    },
  });
}

export async function createTask(record: Omit<IntakeTasksWrite, "ID">): Promise<IntakeTask> {
  const result = await IntakeTasksService.create(record);
  if (!result.success) {
    console.error("task create failed", result.error);
    throw new Error("The task could not be created.");
  }
  if (record.TaskStatus?.Value === TASK_STARTED) {
    await startQaFromTask({ ...record, ID: result.data?.ID }, ...currentActor());
  }
  return result.data;
}

/** Task status that counts as "work has begun". */
const TASK_STARTED = "In progress";

function currentActor(): [string, string] {
  const state = useAppStore.getState();
  return [actorName(state), state.role];
}

export async function updateTask(id: number, changes: TaskWrite): Promise<IntakeTask> {
  const result = await IntakeTasksService.update(String(id), changes);
  if (!result.success) {
    console.error("task update failed", result.error);
    throw new Error("The task could not be saved.");
  }
  if (changes.TaskStatus?.Value === TASK_STARTED) {
    let t: IntakeTask | undefined = result.data;
    if (!t?.RequestItemId || !t.TaskType) {
      const re = await IntakeTasksService.getAll({ select: ["ID", "Title", "RequestItemId", "TaskType", "WorkPackageId"], filter: `ID eq ${id}`, top: 1 });
      t = re.success ? (re.data ?? [])[0] : undefined;
    }
    if (t) await startQaFromTask(t, ...currentActor());
  }
  return result.data;
}

export async function deleteTask(id: number): Promise<void> {
  try {
    await IntakeTasksService.delete(String(id));
  } catch (e) {
    console.error("task delete failed", e);
    throw new Error("The task could not be deleted.");
  }
}

/** Display name of the task's Assigned To person. */
export function taskAssigneeName(t: IntakeTask): string | undefined {
  return t.AssignedTo?.DisplayName || undefined;
}


/** Short task reference shown to people, e.g. "TSK-12". Matches the task's file folder (Task-12). */
export function taskNumber(t: IntakeTask): string {
  return t.ID ? `TSK-${t.ID}` : "TSK-new";
}

/**
 * Delete a task with a required reason. The task (and its own comments) is removed, so the
 * reason is recorded in the parent request's activity history. Returns false if the task was
 * deleted but the reason couldn't be written to the request.
 */
export async function deleteTaskWithReason(task: IntakeTask, reason: string): Promise<boolean> {
  const id = task.ID as number;
  await deleteTask(id);
  if (!task.RequestItemId) return true;
  try {
    const res = await IntakeRequestsService.getAll({ select: ["ID", "ActivityLog"], filter: `ID eq ${Number(task.RequestItemId)}`, top: 1 });
    const r = res.success ? (res.data ?? [])[0] : undefined;
    if (!r) {
      console.error("task delete: request read failed", res.success ? "not found" : res.error);
      return false;
    }
    const [by, role] = currentActor();
    await updateRequest(r.ID as number, {
      ActivityLog: appendLog(r.ActivityLog, {
        at: new Date().toISOString(),
        by,
        role,
        text: `Task ${taskNumber(task)} "${task.Title ?? ""}" deleted: ${reason}`,
      }),
    });
    return true;
  } catch (e) {
    console.error("task delete: history write failed", e);
    return false;
  }
}
