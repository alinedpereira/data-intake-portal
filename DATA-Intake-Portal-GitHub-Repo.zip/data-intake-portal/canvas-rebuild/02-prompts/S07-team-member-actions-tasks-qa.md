# S07 – Team member actions, Ask the requestor, tasks and QA

**Wireframes:** `W05-intake-detail-requestor.png` (right-column layout), `W08-work-package.png` (task table style), `W12-tasks.png`
**Depends on:** S05; flows F2, F5, F6 (`IntakeAskRequestor`)

## Goal
The intake owner moves the intake forward with one clear "next step" button, asks the requestor questions, and manages intake-level tasks. A QA/Testing task that starts moves the intake into QA Testing (via flow F5).

## Team actions (`conTeamActions`, visible when `varIsOwner || varIsTeamManager`, and not `varLocked`)
```
// Next stage for the owner = the single Owner transition from the current stage for this lifecycle
Set(varNext, First(Filter(colTransitions, FromStage = varIntake.Status.Value, AllowedRole.Value = "Owner",
    Lifecycle.Value = "Any" || Lifecycle.Value = If(varIsIaap, "IAAP", "Standard"),
    // skip QA if not needed, skip DML unless Data Risk, skip Acceptance when QA is needed or the intake uses work packages
    ToStage <> "DML Approval" || varIntake.RequestTypeL1.Value = "Data Risk Assessment",
    ToStage <> "Acceptance sign-off" || (!varNeedsQa && varIntake.RequestTypeL1.Value <> "Data Risk Assessment" && IsEmpty(colIntakeWPs)))));
// btnNextStage.Text
"Move to " & varNext.ToStage & "  →"
// btnNextStage.Visible
!IsBlank(varNext)
// btnNextStage.OnSelect
Set(varResult, IntakeChangeStage.Run(varIntake.ID, "Move", varNext.ToStage, "", CurrentUserEmail));
If(varResult.ok = "true", Set(varIntake, LookUp(IntakeRequests, ID = varIntake.ID)), Notify(varResult.message, NotificationType.Error))
// lblNextHint (when the intake uses work packages and is In Progress)
"Work is delivered through the work packages above. The requestor accepts each one and the manager closes the intake."
```

## Ask the requestor
```
// btnAsk (owner or manager) – opens a text box; OnSelect:
IntakeAskRequestor.Run(varIntake.ID, "Ask", txtQuestion.Text, CurrentUserEmail)
// F6 sets AwaitingRequestor = true, OpenQuestion, QuestionAskedBy/On, logs and notifies the requestor.
// When the requestor answers (S05), F6 clears the flag, stores RequestorAnswer/AnsweredOn, logs and notifies the owner.
// Banner for the team while waiting: "Waiting for the requestor since " & Text(varIntake.QuestionAskedOn, "d mmm")
```

## Intake-level tasks (`conTasks`, scrIntakeDetail with tasks, and scrTasks)
| Control | Behaviour |
|---|---|
| galIntakeTasks | `Filter(IntakeTasks, RequestItemId = varIntake.ID, WorkPackageId = 0)` – columns Task, Type, Assigned to, Due, Status |
| lblWpTaskNote | Visible when packages exist: `CountRows(Filter(IntakeTasks, RequestItemId = varIntake.ID, WorkPackageId > 0)) & " tasks are managed inside the work packages above."` |
| btnAddTask | Opens `conTaskDialog`: Title, Type (`Choices(IntakeTasks.TaskType)`), Assigned to (people picker), Due date, Notes |
| btnSaveTask | `Patch(IntakeTasks, Defaults(IntakeTasks), {Title: …, RequestItemId: varIntake.ID, RequestNumber: varIntake.RequestNumber, RequestTitle: varIntake.Title, WorkPackageId: 0, TaskType: drpTaskType.Selected, TaskStatus: {Value: "Not started"}, AssignedTo: …, DueDate: …})` |
| drpTaskStatus (inline) | `Patch(IntakeTasks, ThisItem, {TaskStatus: Self.Selected})` – F5 reacts to the change |

Tasks are disabled when `varLocked`. Team members can edit tasks assigned to them; the owner and manager can edit all.

## My tasks screen (`scrTasks`, W12)
```
// galMyTasks.Items
SortByColumns(Filter(IntakeTasks, AssignedTo.Email = User().Email, TaskStatus.Value <> "Done"), "DueDate", SortOrder.Ascending)
// Intake / work package column
ThisItem.RequestNumber & If(ThisItem.WorkPackageId > 0, " · WP " & ThisItem.WorkPackageId, "")
```
Managers get a toggle "My tasks | Team tasks"; team tasks filter by the intakes of `MyManagedTeams` (collect the team's intake IDs first, then filter tasks per ID batch to stay delegable).

## QA
- If the intake's type is in IntakeQAConfig, F1 already created an unassigned QA/Testing task.
- When any intake-level QA/Testing task moves to "In progress", F5 moves the intake from In Progress to QA Testing.
- In QA Testing, the manager records the result (comment) and moves to Acceptance sign-off with btnNextStage (manager transition QA Testing → Acceptance sign-off).

## Acceptance checks
- Owner at Assigned / Under Review sees "Move to Requirements sign-off"; at Approved sees "Move to In Progress".
- For a QA-configured type at In Progress there is no "Move to Acceptance" button; starting the QA task moves the intake to QA Testing within a minute.
- Asking a question flags the intake for the requestor and appears in their "Waiting on me" filter.
- Intake-level task list never shows work-package tasks.

## Prompt to paste
```
Build S07 from 02-prompts/S07 on scrIntakeDetail and scrTasks: the owner's next-stage button driven by colTransitions,
Ask the requestor (IntakeAskRequestor.Run), the intake-level task panel (WorkPackageId = 0) with an add/edit task dialog,
and the My tasks screen matching wireframe W12. Do not patch Status from the app. Then run the acceptance checks as a Team Member.
```
