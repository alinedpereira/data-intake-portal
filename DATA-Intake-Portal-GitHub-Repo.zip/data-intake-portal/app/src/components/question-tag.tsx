import { MessageCircleQuestionMark, MessageCircleReply } from "lucide-react";
import type { IntakeRequest } from "@/lib/intake";
import { daysWaiting, isAwaitingRequestor, recentlyAnswered } from "@/lib/questions";

/** Small tag for list rows: open question for the requestor, or a recent answer. */
export function QuestionTag({ r, forRequestor = false }: { r: IntakeRequest; forRequestor?: boolean }) {
  if (isAwaitingRequestor(r)) {
    const d = daysWaiting(r);
    return (
      <span className="mt-1 inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-900 dark:bg-amber-900 dark:text-amber-100">
        <MessageCircleQuestionMark className="size-3.5" aria-hidden="true" />
        {forRequestor ? "Needs your answer" : `Waiting on requestor${d !== undefined ? ` · ${d}d` : ""}`}
      </span>
    );
  }
  if (!forRequestor && recentlyAnswered(r)) {
    return (
      <span className="mt-1 inline-flex items-center gap-1 whitespace-nowrap rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-900 dark:bg-emerald-900 dark:text-emerald-100">
        <MessageCircleReply className="size-3.5" aria-hidden="true" /> Answered
      </span>
    );
  }
  return null;
}
