import { useEffect, useRef } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import { House, ClipboardList, ClipboardCheck, FilePlus2, FileSearch, LayoutDashboard, LifeBuoy, ListOrdered, TriangleAlert } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { roleLabel, useAppStore, type Role } from "@/lib/store";
import { PersonPicker } from "@/components/person-picker";
import { DEFAULT_MANAGER_EMAIL, managersOf, useMyManagedTeams, useTeams } from "@/lib/teams";
import { scoringTeams, useQuestionConfig } from "@/lib/team-questions";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: House },
  { to: "/intakes", label: "My Intakes", icon: ClipboardList },
  { to: "/work", label: "Intakes & tasks", icon: ClipboardCheck },
  { to: "/prioritization", label: "Intake Prioritization Queue", icon: ListOrdered },
  { to: "/at-risk", label: "Intakes Needing Attention", icon: TriangleAlert },
  { to: "/requests", label: "Intake details", icon: FileSearch },
  { to: "/new", label: "New intake", icon: FilePlus2 },
  { to: "/dashboard", label: "My Team's Work View", icon: LayoutDashboard },
  { to: "/help", label: "Help", icon: LifeBuoy },
] as const;

/** Menu items, in order, for each role. */
const NAV_BY_ROLE: Record<Role, readonly string[]> = {
  Manager: ["/work", "/requests", "/dashboard", "/prioritization", "/at-risk", "/help"],
  Assignee: ["/work", "/help"],
  Requestor: ["/", "/new", "/intakes", "/help"],
};

const ROLES: Role[] = ["Requestor", "Manager", "Assignee"];

export function AppShell() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  /** Landing page for each view; switching view or person always returns there. */
  const homeFor = (r: Role) => (r === "Requestor" ? "/" : "/work");
  const role = useAppStore((s) => s.role);
  const setRole = useAppStore((s) => s.setRole);
  const manager = useAppStore((s) => s.manager);
  const me = useAppStore((s) => s.me);
  const setMe = useAppStore((s) => s.setMe);
  // The app always opens in the Requestor view on its home page (a direct link to one intake is kept).
  const landed = useRef(false);
  useEffect(() => {
    if (landed.current) return;
    landed.current = true;
    if (pathname !== "/" && !pathname.startsWith("/requests/")) navigate("/", { replace: true });
  }, [navigate, pathname]);
  const setManager = useAppStore((s) => s.setManager);
  const teams = useTeams();
  const managers = managersOf(teams.data);
  // Manager view acts as a manager from the IntakeTeams list; default to Andre Lawson.
  useEffect(() => {
    if (role !== "Manager" || managers.length === 0) return;
    if (manager && managers.some((m) => m.email.toLowerCase() === manager.email.toLowerCase())) return;
    const pick = managers.find((m) => m.email.toLowerCase() === DEFAULT_MANAGER_EMAIL.toLowerCase()) ?? managers[0];
    setManager({ name: pick.name, email: pick.email });
  }, [role, managers, manager, setManager]);
  // Role-specific accents (see index.css): Navy for Requestor, node blue for Team Member, Midnight for Manager. Top bar stays BMO blue.
  useEffect(() => {
    document.documentElement.dataset.role = role.toLowerCase();
  }, [role]);
  const managed = useMyManagedTeams();
  const questionCfg = useQuestionConfig();
  const scoring = scoringTeams(questionCfg.data);
  const items = NAV_BY_ROLE[role]
    .filter((to) => to !== "/prioritization" || managed.teams.some((t) => scoring.includes(t)))
    .flatMap((to) => NAV.filter((n) => n.to === to));

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-card focus:px-3 focus:py-2 focus:text-foreground focus:ring-2 focus:ring-ring"
      >
        Skip to content
      </a>
      <header className="flex flex-wrap items-center justify-between gap-3 border-b-4 border-[#003758] bg-[#0075BE] px-5 py-3 text-white">
        <div className="flex items-center gap-4">
          <p className="text-lg tracking-tight">
            <span className="font-semibold">D.A.T.A.</span> - Intake Portal
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {role === "Assignee" && (
            <>
              <label htmlFor="owner-switch" className="text-sm text-white/90">
                Owner
              </label>
              <PersonPicker
                id="owner-switch"
                field="Owner"
                value={me}
                onChange={(p) => {
                  setMe(p);
                  if (p) navigate(homeFor("Assignee"));
                }}
                className="w-64 text-foreground [&_input]:h-9 [&_input]:rounded-full"
              />
            </>
          )}
          {role === "Manager" && (
            <>
              <label htmlFor="manager-switch" className="text-sm text-white/90">
                Manager
              </label>
              {teams.isError ? (
                <button type="button" className="text-sm underline" onClick={() => void teams.refetch()}>
                  Managers couldn't load. Retry
                </button>
              ) : (
                <select
                  id="manager-switch"
                  value={manager?.email ?? ""}
                  disabled={teams.isPending}
                  onChange={(e) => {
                    const m = managers.find((x) => x.email === e.target.value);
                    if (m) {
                      setManager({ name: m.name, email: m.email });
                      navigate(homeFor("Manager"));
                    }
                  }}
                  className="h-9 max-w-[16rem] rounded-full border border-white/50 bg-[#005789] px-3 text-sm text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  {teams.isPending && <option value="" className="bg-[#005789] text-white">Loading…</option>}
                  {managers.map((m) => (
                    <option key={m.email} value={m.email} className="bg-[#005789] text-white">
                      {m.name} ({m.teams.join(", ")})
                    </option>
                  ))}
                </select>
              )}
            </>
          )}
          <label htmlFor="role-switch" className="text-sm text-white/90">
            View as
          </label>
          <select
            id="role-switch"
            value={role}
            onChange={(e) => {
              const next = e.target.value as Role;
              setRole(next);
              navigate(homeFor(next));
            }}
            className="h-9 rounded-full border border-white/50 bg-[#005789] px-4 text-sm font-semibold text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            {ROLES.map((r) => (
              <option key={r} value={r} className="bg-[#005789] text-white">
                {roleLabel(r)}
              </option>
            ))}
          </select>
        </div>
      </header>
      <div className="flex flex-1 flex-col md:flex-row">
        <nav aria-label="Primary" className="border-b border-[#C3CFD9] bg-[var(--nav-bg)] text-[#1F2A33] md:w-64 md:shrink-0 md:border-b-0 md:border-r">
          <ul className="flex gap-1 overflow-x-auto p-2 md:flex-col md:py-4">
            {items.map(({ to, label, icon: Icon }) => {
              const active =
                to === "/"
                  ? pathname === "/"
                  : to === "/work"
                    ? pathname.startsWith("/work") || pathname.startsWith("/tasks")
                    : pathname.startsWith(to);
              const text = to === "/work" ? (role === "Manager" ? "My Team's Queue" : "My Work Queue") : label;
              return (
                <li key={to}>
                  <NavLink
                    to={to}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "flex items-center gap-3 whitespace-nowrap rounded-md border-l-4 border-transparent px-3 py-2.5 text-sm font-medium leading-snug md:whitespace-normal text-[#1F2A33] hover:bg-white/70 focus-visible:outline-2 focus-visible:outline-[var(--brand-strong)]",
                      active && "border-white/70 bg-[var(--brand-strong)] font-semibold text-white hover:bg-[var(--brand-strong)]",
                    )}
                  >
                    <Icon className="size-4 shrink-0" aria-hidden="true" />
                    <span className="min-w-0">{text}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>
        <main id="main-content" tabIndex={-1} className="flex min-w-0 flex-1 flex-col bg-background">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="flex-1"
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
      <Toaster />
    </div>
  );
}

export default AppShell;
