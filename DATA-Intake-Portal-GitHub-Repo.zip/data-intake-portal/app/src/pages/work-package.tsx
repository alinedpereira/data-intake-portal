import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Boxes, Lock } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { RequestProgress } from "@/components/lifecycle";
import { RequestTaskPanel } from "@/components/request-tasks";
import { FolderFiles } from "@/components/request-files";
import { PersonPicker } from "@/components/person-picker";
import { StatusPill } from "@/components/request-bits";
import { WpStatusPill } from "@/components/work-packages";
import { appendLog, displayStatus, formatDate, isLockedStatus, parseLog, requestNumber, statusOf, useRequest } from "@/lib/intake";
import { ownerNames, personWrite, requestorOf, type Person } from "@/lib/people";
import { actorName, roleLabel, useAppStore } from "@/lib/store";
import {
  WP_NEXT,
  WP_STAGES,
  WP_STATUSES,
  invalidateWorkPackages,
  logToIntake,
  updateWorkPackage,
  useSubTeams,
  useWorkPackage,
  useWorkPackages,
  wpFolder,
  wpStage,
  wpStatusOf,
  type WorkPackage,
  type WorkPackageWrite,
  type WpStatus,
} from "@/lib/workpackages";

const PRIORITIES = ["Low", "Medium", "High", "Critical"];
const PERSON_ODATA_TYPE = "#Microsoft.Azure.Connectors.SharePoint.SPListExpandedUser";

/** A work package managed like its own intake, linked to its parent intake. */
export function WorkPackagePage() {
  const { wpId } = useParams();
  const role = useAppStore((s) => s.role);
  const id = Number(wpId);
  const wpQ = useWorkPackage(Number.isInteger(id) && id > 0 ? id : undefined);
  const parentQ = useRequest(wpQ.data?.RequestItemId ? String(wpQ.data.RequestItemId) : undefined);
  const siblings = useWorkPackages(wpQ.data?.RequestItemId);

  if (role === "Requestor") {
    return (
      <div className="p-8">
        <EmptyState icon={Lock} title="Work packages are managed by the team" description="You can follow and accept them on your intake's page." />
      </div>
    );
  }
  if (wpQ.isPending || (wpQ.isSuccess && parentQ.isPending)) return <div className="p-5 md:p-8"><LoadingState /></div>;
  if (wpQ.isError || !wpQ.data) {
    return (
      <div className="p-5 md:p-8">
        <ErrorState title="This work package could not be loaded" action={<Button onClick={() => void wpQ.refetch()}>Retry</Button>} />
      </div>
    );
  }
  if (parentQ.isError || !parentQ.data) {
    return (
      <div className="p-5 md:p-8">
        <ErrorState title="Its intake could not be loaded" action={<Button onClick={() => void parentQ.refetch()}>Retry</Button>} />
      </div>
    );
  }
  const index = (siblings.data ?? []).findIndex((w) => w.ID === wpQ.data.ID);
  return <WorkPackageDetail key={`${wpQ.data.ID}-${wpQ.data.Modified ?? ""}`} wp={wpQ.data} index={index} total={siblings.data?.length ?? 0} />;
}

function WorkPackageDetail({ wp, index, total }: { wp: WorkPackage; index: number; total: number }) {
  const role = useAppStore((s) => s.role);
  const me = useAppStore((s) => s.me);
  const actor = useAppStore(actorName);
  const parentQ = useRequest(String(wp.RequestItemId));
  const r = parentQ.data;
  const st = wpStatusOf(wp);
  const isManager = role === "Manager";
  const isOwner = !!me?.Email && wp.WPOwner?.Email?.toLowerCase() === me.Email.toLowerCase();
  const parentLocked = r ? isLockedStatus(statusOf(r)) : false;
  const canWork = !parentLocked && st !== "Accepted" && (isManager || isOwner);
  const label = index >= 0 ? `WP ${index + 1}` : "Work package";
  const log = parseLog(wp.WPActivity);
  const next = WP_NEXT[st];

  const save = useMutation({
    mutationFn: async ({ changes, note }: { changes: WorkPackageWrite; note: string }) => {
      await updateWorkPackage(wp.ID as number, {
        ...changes,
        WPActivity: appendLog(wp.WPActivity, { at: new Date().toISOString(), by: actor, role, text: note }),
      });
      // Milestones also go on the intake's activity: sent for acceptance, and accepted/complete.
      const to = changes.WPStatus?.Value;
      if (to === "Ready for acceptance" || to === "Accepted") {
        await logToIntake(wp.RequestItemId as number, {
          by: actor,
          role,
          text: `${label} "${changes.Title ?? wp.Title}": ${to === "Accepted" ? "Accepted (complete)" : "Sent for the requestor's acceptance"}`,
        });
      }
    },
    onSuccess: (_d, { changes }) => {
      invalidateWorkPackages();
      toast.success(changes.WPStatus ? `Moved to ${changes.WPStatus.Value}` : "Saved");
    },
    onError: () => toast.error("The change could not be saved. Please try again."),
  });
  const setStatus = (to: WpStatus, note?: string) => save.mutate({ changes: { WPStatus: { Value: to } }, note: note ?? `Status changed to ${to}` });

  if (!r) return null;
  return (
    <div className="mx-auto max-w-7xl space-y-6 p-5 md:p-8">
      <Link to={`/work/${wp.RequestItemId}`} className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring">
        <ArrowLeft className="size-4" aria-hidden="true" /> Back to {requestNumber(r)} · {r.Title}
      </Link>

      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-sm font-semibold text-primary">
            <Boxes className="size-4" aria-hidden="true" /> {label}{total ? ` of ${total}` : ""} · {requestNumber(r)}
          </p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight">{wp.Title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{wp.SubTeam ?? "No sub-team"} · {wp.WPOwner?.DisplayName ?? "No owner"}</p>
        </div>
        <WpStatusPill status={st} />
      </div>

      <RequestProgress status={wpStage(st)} stages={WP_STAGES} heading="Where this work package is" />
      {st === "Sent back" && <p className="rounded-md bg-red-50 px-3 py-2 text-sm font-semibold text-red-900 dark:bg-red-950 dark:text-red-100">Sent back by the requestor. See the activity for their reason.</p>}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <Section title="Parent intake">
            <Row k="Intake" v={`${requestNumber(r)} · ${r.Title}`} />
            <Row k="Requestor" v={requestorOf(r)} />
            <Row k="Submitted" v={formatDate(r.SubmittedOn ?? r.Created)} />
            <Row k="Type" v={[r.RequestTypeL1?.Value, r.RequestTypeL2].filter(Boolean).join(" / ")} />
            <Row k="Business focus" v={r.AnalyticsDomain?.Value} />
            <Row k="Team" v={r.RoutedTeam?.Value} />
            <Row k="Intake owner" v={ownerNames(r) ?? "Unassigned"} />
            <Row k="Needed by" v={formatDate(r.NeededBy)} />
            <Row k="Intake status" v={displayStatus(r)} />
            <Row k="Description" v={r.RequestDescription} />
          </Section>
          <Section title="Work package">
            <Row k="Sub-team" v={wp.SubTeam} />
            <Row k="Owner" v={wp.WPOwner?.DisplayName} />
            <Row k="Priority" v={wp.WPPriority?.Value} />
            <Row k="Due" v={wp.WPDueDate ? formatDate(wp.WPDueDate) : undefined} />
            <Row k="Description" v={wp.WPDescription} />
          </Section>
          {r.RequestNumber && wp.ID && (
            <FolderFiles folder={wpFolder(r.RequestNumber, wp.ID)} title="Files" readOnly={!canWork} />
          )}
        </div>

        <div className="space-y-6">
          <section aria-labelledby="wp-actions-h" className="space-y-4 border-t border-border pt-5">
            <h2 id="wp-actions-h" className="text-lg font-semibold">{isManager ? "Manager actions" : "Your actions"}</h2>
            <p className="text-sm text-muted-foreground">
              Parent intake: <StatusPill status={statusOf(r)} label={displayStatus(r)} />
            </p>
            {parentLocked ? (
              <p className="text-sm text-muted-foreground">The intake is closed, so this work package can't be changed.</p>
            ) : st === "Accepted" ? (
              <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-300">Accepted by the requestor.</p>
            ) : st === "Ready for acceptance" ? (
              <p className="text-sm text-muted-foreground">Waiting for the requestor to accept this work package on the intake page.</p>
            ) : canWork && next ? (
              <Button size="lg" disabled={save.isPending} onClick={() => setStatus(next, next === "Ready for acceptance" ? "Ready for the requestor's acceptance" : undefined)}>
                Move to “{next}”
              </Button>
            ) : !canWork ? (
              <p className="text-sm text-muted-foreground">Only the work package owner or the manager can move it forward.</p>
            ) : null}

            {canWork && <CommentBox disabled={save.isPending} onAdd={(t) => save.mutate({ changes: {}, note: t })} />}
            {isManager && !parentLocked && <ManagerPanel wp={wp} busy={save.isPending} onSave={(changes, note) => save.mutate({ changes, note })} />}
          </section>

          <section aria-labelledby="wp-log-h" className="space-y-2">
            <h2 id="wp-log-h" className="text-lg font-semibold">Activity</h2>
            {log.length === 0 ? (
              <p className="text-sm text-muted-foreground">No activity yet.</p>
            ) : (
              <ol className="space-y-2">
                {[...log].reverse().map((e, i) => (
                  <li key={`${e.at}-${i}`} className="rounded-md border border-border bg-card px-3 py-2 text-sm">
                    <p className="whitespace-pre-wrap">{e.text}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {e.by} · {roleLabel(e.role)} · {new Date(e.at).toLocaleString()}
                    </p>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </div>
      </div>

      <RequestTaskPanel request={r} workPackageId={wp.ID} locked={parentLocked || st === "Accepted"} heading={`Tasks for ${label}`} fullAccess={isOwner} />
    </div>
  );
}

function ManagerPanel({ wp, busy, onSave }: { wp: WorkPackage; busy: boolean; onSave: (changes: WorkPackageWrite, note: string) => void }) {
  const subTeams = useSubTeams();
  const [subTeam, setSubTeam] = useState(wp.SubTeam ?? "");
  const [owner, setOwner] = useState<Person | null>(wp.WPOwner?.Claims ? wp.WPOwner : null);
  const [due, setDue] = useState(wp.WPDueDate ? wp.WPDueDate.slice(0, 10) : "");
  const [priority, setPriority] = useState(wp.WPPriority?.Value ?? "");
  const [status, setStatus] = useState<string>(wpStatusOf(wp));
  const [title, setTitle] = useState(wp.Title);
  const [description, setDescription] = useState(wp.WPDescription ?? "");

  const pickSubTeam = (name: string) => {
    setSubTeam(name);
    const lead = subTeams.data?.find((s) => s.name === name);
    if (lead?.leadEmail) {
      setOwner({
        "@odata.type": PERSON_ODATA_TYPE,
        Claims: `i:0#.f|membership|${lead.leadEmail.toLowerCase()}`,
        DisplayName: lead.leadName,
        Email: lead.leadEmail,
        Picture: "",
        Department: "",
        JobTitle: "",
      });
    }
  };

  const submit = () => {
    const changes: WorkPackageWrite = {};
    const notes: string[] = [];
    if (title.trim() && title.trim() !== wp.Title) { changes.Title = title.trim(); notes.push(`title "${title.trim()}"`); }
    if (description.trim() !== (wp.WPDescription ?? "")) { changes.WPDescription = description.trim(); notes.push("description"); }
    if (subTeam !== (wp.SubTeam ?? "")) { changes.SubTeam = subTeam; notes.push(`sub-team ${subTeam}`); }
    if (owner && owner.Claims !== wp.WPOwner?.Claims) { changes.WPOwner = personWrite(owner); notes.push(`owner ${owner.DisplayName}`); }
    if ((wp.WPDueDate?.slice(0, 10) ?? "") !== due) { changes.WPDueDate = due ? `${due}T12:00:00Z` : (null as unknown as undefined); notes.push(`due ${due || "cleared"}`); }
    if (priority && priority !== (wp.WPPriority?.Value ?? "")) { changes.WPPriority = { Value: priority }; notes.push(`priority ${priority}`); }
    if (status !== wpStatusOf(wp)) { changes.WPStatus = { Value: status }; notes.push(`status ${status}`); }
    if (!notes.length) return;
    onSave(changes, `Updated: ${notes.join(", ")}`);
  };

  return (
    <form
      className="grid gap-3 rounded-lg border border-border bg-card p-4"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <p className="text-sm font-semibold">Manage this work package</p>
      <div className="grid gap-1.5">
        <Label htmlFor="wpm-title">Title</Label>
        <Input id="wpm-title" value={title} onChange={(e) => setTitle(e.target.value)} />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="wpm-desc">Description</Label>
        <Textarea id="wpm-desc" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="grid gap-1.5">
          <Label htmlFor="wpm-sub">Sub-team</Label>
          <div className="[&>[data-slot=native-select-wrapper]]:w-full">
            <NativeSelect id="wpm-sub" value={subTeam} onChange={(e) => pickSubTeam(e.target.value)} className="bg-card">
              <NativeSelectOption value="">Choose…</NativeSelectOption>
              {(subTeams.data ?? []).map((s) => (
                <NativeSelectOption key={s.name} value={s.name}>{s.name}</NativeSelectOption>
              ))}
            </NativeSelect>
          </div>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="wpm-pri">Priority</Label>
          <div className="[&>[data-slot=native-select-wrapper]]:w-full">
            <NativeSelect id="wpm-pri" value={priority} onChange={(e) => setPriority(e.target.value)} className="bg-card">
              <NativeSelectOption value="">Choose…</NativeSelectOption>
              {PRIORITIES.map((p) => <NativeSelectOption key={p} value={p}>{p}</NativeSelectOption>)}
            </NativeSelect>
          </div>
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="wpm-due">Due date</Label>
          <Input id="wpm-due" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="wpm-status">Status</Label>
          <div className="[&>[data-slot=native-select-wrapper]]:w-full">
            <NativeSelect id="wpm-status" value={status} onChange={(e) => setStatus(e.target.value)} className="bg-card">
              {WP_STATUSES.map((s) => <NativeSelectOption key={s} value={s}>{s}</NativeSelectOption>)}
            </NativeSelect>
          </div>
        </div>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="wpm-owner">Owner</Label>
        <PersonPicker id="wpm-owner" field="TaskAssignedTo" value={owner} onChange={setOwner} />
      </div>
      <Button type="submit" className="justify-self-start" disabled={busy}>Save changes</Button>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card">
      <h2 className="border-l-4 border-primary bg-accent px-4 py-2 font-semibold text-accent-foreground">{title}</h2>
      <dl className="grid grid-cols-[9rem_minmax(0,1fr)] gap-x-4 gap-y-3 p-4 text-sm">{children}</dl>
    </section>
  );
}

function Row({ k, v }: { k: string; v?: string }) {
  return (
    <>
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="whitespace-pre-wrap break-words font-semibold">{v || "—"}</dd>
    </>
  );
}

function CommentBox({ onAdd, disabled }: { onAdd: (t: string) => void; disabled: boolean }) {
  const [text, setText] = useState("");
  return (
    <form
      className="flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!text.trim()) return;
        onAdd(text.trim());
        setText("");
      }}
    >
      <Label htmlFor="wp-comment" className="sr-only">Comment</Label>
      <Input id="wp-comment" value={text} onChange={(e) => setText(e.target.value)} placeholder="Add a comment…" className="bg-card" />
      <Button type="submit" disabled={disabled || !text.trim()}>Add comment</Button>
    </form>
  );
}
