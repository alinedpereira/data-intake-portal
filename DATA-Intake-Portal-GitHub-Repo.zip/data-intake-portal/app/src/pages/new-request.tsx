import { useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, ArrowRight, Check, CircleCheck, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ChoiceSelect } from "@/components/choice-select";
import { DEFAULT_REQUESTOR, actorName, useAppStore } from "@/lib/store";
import { ensureQaTask } from "@/lib/qa";
import { appendLog, createRequest, requestNumber } from "@/lib/intake";
import { useRouting } from "@/lib/routing";
import { applicable, invalidNumbers, mergeAnswers, missingRequired, scoreOf, useQuestionConfig, type Draft as AnswerDraft } from "@/lib/team-questions";
import { ListSelect, QuestionFields } from "@/components/team-questions";
import { ensureRequestFolder } from "@/lib/files";
import { personWrite, type Person } from "@/lib/people";
import { PersonPicker } from "@/components/person-picker";
import { cn } from "@/lib/utils";

const STEPS = ["Routing", "Intake", "Priorities"] as const;

interface Draft {
  requestor: Person | null;
  businessUnit: string;
  onBehalfOf: string;
  level1: string;
  team: string;
  level2: string;
  domain: string;
  comments: string;
  title: string;
  description: string;
  neededBy: string;
  priority: string;
  value: string;
}

export function NewRequestPage() {
  const role = useAppStore((s) => s.role);
  const actor = useAppStore(actorName);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const routing = useRouting();
  const cfg = useQuestionConfig();
  const [answers, setAnswers] = useState<AnswerDraft>({});
  const [questionErrors, setQuestionErrors] = useState(false);
  const [step, setStep] = useState(0);
  const [requestorError, setRequestorError] = useState(false);
  const [done, setDone] = useState<{ id?: number; no: string; title: string; folderReady: boolean } | null>(null);
  const [d, setD] = useState<Draft>({
    requestor: role === "Requestor" ? DEFAULT_REQUESTOR : null,
    businessUnit: "",
    onBehalfOf: "",
    level1: "",
    team: "",
    level2: "",
    domain: "",
    comments: "",
    title: "",
    description: "",
    neededBy: "",
    priority: "",
    value: "",
  });
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((p) => ({ ...p, [k]: v }));
  const teamFor = (level1: string, level2: string, domain = "") => {
    const mapped = routing.suggestTeam(level1, level2, domain);
    return mapped && routing.teamOptions.includes(mapped) ? mapped : "";
  };
  const showDomain = routing.needsFocusArea(d.level1, d.level2);
  const suggested = teamFor(d.level1, d.level2, d.domain);
  const [domainError, setDomainError] = useState(false);
  const routedTeam = d.team;
  // The team's upfront questions for this team + intake type, from the IntakeQuestionRules list.
  const questions = applicable(cfg.data, { team: routedTeam, level1: d.level1, level2: d.level2 }, "Requestor");
  const answered = mergeAnswers(questions, answers, {});

  const submit = useMutation({
    mutationFn: () =>
      createRequest({
        Title: d.title.trim(),
        Requestor: d.requestor ? personWrite(d.requestor) : undefined,
        Requestorsemail: d.requestor?.Email || undefined,
        OnBehalfOf: d.onBehalfOf.trim() || undefined,
        BusinessUnit: d.businessUnit ? { Value: d.businessUnit } : undefined,
        RequestTypeL1: d.level1 ? { Value: d.level1 } : undefined,
        RequestTypeL2: d.level2 || undefined,
        AnalyticsDomain: showDomain && d.domain ? { Value: d.domain } : undefined,
        RoutedTeam: routedTeam ? { Value: routedTeam } : undefined,
        RequestComments: d.comments.trim() || undefined,
        RequestDescription: d.description.trim(),
        NeededBy: d.neededBy ? `${d.neededBy}T12:00:00Z` : undefined,
        Priority: d.priority ? { Value: d.priority } : undefined,
        BusinessValue: d.value.trim() || undefined,
        RequestorAnswers: Object.keys(answered).length ? JSON.stringify(answered) : undefined,
        BacklogScore: scoreOf(questions, answered),
        Status: { Value: "Submitted" },
        RequirementsSignedOff: false,
        AcceptanceSignedOff: false,
        SubmittedOn: new Date().toISOString(),
        ActivityLog: appendLog(undefined, {
          at: new Date().toISOString(),
          by: d.requestor?.DisplayName ?? "",
          role: "Requestor",
          text: "Intake submitted",
        }),
      }),
    onSuccess: async (created) => {
      void qc.invalidateQueries({ queryKey: ["requests"] });
      toast.success("Intake submitted");
      const no = created ? requestNumber(created) : "";
      let folderReady = false;
      if (created?.RequestNumber) {
        try {
          await ensureRequestFolder(created.RequestNumber);
          folderReady = true;
        } catch {
          folderReady = false;
        }
      }
      if (created?.ID) {
        try {
          await ensureQaTask(created, actor, role);
        } catch {
          toast.error("The intake was submitted, but its QA task couldn't be created. It will be added when a manager opens the intake.");
        }
      }
      setDone({ id: created?.ID, no, title: created?.Title ?? d.title, folderReady });
    },
    onError: () => toast.error("The intake could not be submitted. Please try again."),
  });

  function next(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (step === 0 && !d.requestor) {
      setRequestorError(true);
      document.getElementById("requestor")?.focus();
      return;
    }
    if (step === 0 && showDomain && !d.domain) {
      setDomainError(true);
      document.getElementById("domain")?.focus();
      return;
    }
    if (step === 2) {
      const missing = [...missingRequired(questions, answers), ...invalidNumbers(questions, answers)];
      if (missing.length) {
        setQuestionErrors(true);
        document.getElementById(`tq-${missing[0].key}`)?.focus();
        return;
      }
    }
    if (step < 2) setStep(step + 1);
    else submit.mutate();
  }

  if (done) {
    return (
      <div className="mx-auto max-w-3xl p-5 md:p-8">
        <section aria-labelledby="done-h" className="space-y-5 rounded-lg border border-border bg-card p-6">
          <div className="flex items-start gap-3">
            <CircleCheck className="mt-1 size-7 shrink-0 text-emerald-700 dark:text-emerald-400" aria-hidden="true" />
            <div>
              <h1 id="done-h" className="text-2xl font-semibold tracking-tight">Intake submitted</h1>
              <p className="mt-1 text-sm"><span className="font-semibold">{done.no}</span> · {done.title}</p>
            </div>
          </div>
          <p className="border-t border-border pt-4 text-sm">Add supporting files from the Files section on the intake page.</p>
          <div className="flex flex-wrap gap-3">
            <Button size="lg" disabled={!done.id} onClick={() => navigate(`/requests/${done.id}`)}>
              <Upload aria-hidden="true" /> View intake and add files
            </Button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl p-5 md:p-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-semibold tracking-tight">
          New intake · page {step + 1} of 3
        </h1>
        <ol className="flex items-center gap-2" aria-label="Form steps">
          {STEPS.map((s, i) => (
            <li key={s} className="flex items-center gap-2" aria-current={i === step ? "step" : undefined}>
              {i > 0 && <span aria-hidden="true" className="h-0.5 w-6 bg-border" />}
              <span
                className={cn(
                  "flex size-8 items-center justify-center rounded-full border-2 text-sm font-semibold",
                  i < step && "border-primary bg-primary text-primary-foreground",
                  i === step && "border-primary bg-primary text-primary-foreground",
                  i > step && "border-border bg-card text-muted-foreground",
                )}
              >
                {i < step ? <Check className="size-4" aria-hidden="true" /> : i + 1}
              </span>
              <span className={cn("text-sm", i === step ? "font-semibold" : "text-muted-foreground")}>
                {s}
                {i < step && <span className="sr-only"> (complete)</span>}
              </span>
            </li>
          ))}
        </ol>
      </div>

      <form onSubmit={next} className="mt-6 space-y-6">
        {step === 0 && (
          <>
            <Section title="Requestor">
              <Field id="requestor" label="Requestor" required>
                {role === "Requestor" ? (
                  <Input id="requestor" readOnly value={DEFAULT_REQUESTOR.DisplayName} className="bg-muted" />
                ) : (
                  <PersonPicker id="requestor" value={d.requestor} onChange={(p) => { set("requestor", p); setRequestorError(false); }} />
                )}
                {requestorError && <p role="alert" className="text-sm text-destructive">Pick the requestor from the list.</p>}
              </Field>
              <Field id="bu" label="Business unit (on whose behalf)">
                <ChoiceSelect id="bu" field="BusinessUnit" value={d.businessUnit} onChange={(v) => set("businessUnit", v)} />
              </Field>
              <Field id="obo" label="Requested on behalf of">
                <Input id="obo" value={d.onBehalfOf} onChange={(e) => set("onBehalfOf", e.target.value)} placeholder="Leave blank if it's for you" className="bg-card" />
              </Field>
            </Section>
            <Section title="Intake routing">
              <Field id="l1" label="Level 1 intake type" required>
                <ListSelect
                  id="l1"
                  required
                  value={d.level1}
                  loading={routing.isPending}
                  options={routing.level1Options}
                  onChange={(v) =>
                    setD((p) => {
                      const level2 = routing.level2Options(v).includes(p.level2) ? p.level2 : "";
                      return { ...p, level1: v, level2, team: teamFor(v, level2, p.domain) };
                    })
                  }
                />
                {routing.isError && (
                  <p role="alert" className="text-sm text-destructive">
                    Intake types couldn't be loaded. <button type="button" className="underline" onClick={routing.refetch}>Retry</button>
                  </p>
                )}
              </Field>
              <Field id="l2" label="Level 2 intake type">
                <ListSelect
                  id="l2"
                  value={d.level2}
                  loading={routing.isPending}
                  disabled={!d.level1}
                  placeholder={d.level1 ? "Choose…" : "Choose the Level 1 type first"}
                  options={routing.level2Options(d.level1)}
                  onChange={(v) => setD((p) => ({ ...p, level2: v, team: teamFor(p.level1, v, p.domain) }))}
                />
              </Field>
              {showDomain && (
                <Field id="domain" label="Business focus area" required hint="What the data is about. This picks the team; you can still change it.">
                  <ListSelect
                    id="domain"
                    required
                    options={routing.focusAreaOptions}
                    value={d.domain}
                    onChange={(v) => {
                      setDomainError(false);
                      setD((p) => ({ ...p, domain: v, team: teamFor(p.level1, p.level2, v) }));
                    }}
                  />
                  {domainError && <p role="alert" className="text-sm text-destructive">Choose the business focus area.</p>}
                </Field>
              )}
              <Field id="team" label="Routed to team">
                <ListSelect
                  id="team"
                  options={routing.teamOptions}
                  loading={routing.isPending}
                  value={d.team}
                  onChange={(v) => set("team", v)}
                  placeholder={d.level1 && d.level2 ? "Choose a team" : "Set by the intake types (and business focus area)"}
                />
                {d.level1 && d.level2 && !suggested && !showDomain && (
                  <p className="text-xs text-muted-foreground">No team is mapped to this combination. Choose one, or leave it for a manager to route.</p>
                )}
                {suggested && d.team !== suggested && (
                  <p className="text-xs text-muted-foreground">Changed from the suggested team ({suggested}).</p>
                )}
              </Field>
              <Field id="comments" label="Intake comments">
                <Input id="comments" value={d.comments} onChange={(e) => set("comments", e.target.value)} placeholder="Extra detail to direct the intake" className="bg-card" />
              </Field>
            </Section>
          </>
        )}

        {step === 1 && (
          <Section title="Intake title and description" single>
            <Field id="title" label="Intake title" required>
              <Input id="title" required maxLength={255} value={d.title} onChange={(e) => set("title", e.target.value)} placeholder="One-line phrase to identify the project" className="bg-card" />
            </Field>
            <Field id="desc" label="Intake description" required hint="Goal, background, scope, and definition of done.">
              <Textarea id="desc" required rows={9} value={d.description} onChange={(e) => set("description", e.target.value)} aria-describedby="desc-hint" className="bg-card" />
            </Field>
          </Section>
        )}

        {step === 2 && (
          <Section title="Dates, priority and value">
            <Field id="needed" label="Needed by" required>
              <Input id="needed" type="date" required value={d.neededBy} onChange={(e) => set("neededBy", e.target.value)} className="bg-card" />
            </Field>
            <Field id="priority" label="Priority" required>
              <ChoiceSelect id="priority" field="Priority" required value={d.priority} onChange={(v) => set("priority", v)} />
            </Field>
            <div className="md:col-span-2">
              <Field id="value" label="Business value" hint="Who benefits and what changes when this is done.">
                <Textarea id="value" rows={5} value={d.value} onChange={(e) => set("value", e.target.value)} aria-describedby="value-hint" className="bg-card" />
              </Field>
            </div>
          </Section>
        )}

        {step === 2 && questions.length > 0 && (
          <section className="space-y-4" aria-labelledby="team-q-h">
            <h2 id="team-q-h" className="border-l-4 border-primary bg-accent px-4 py-2.5 text-base font-semibold text-accent-foreground">
              Questions from {routedTeam}
            </h2>
            <p className="text-sm text-muted-foreground">{routedTeam} asks these for {d.level2 || "this type of intake"}.</p>
            <QuestionFields
              questions={questions}
              draft={answers}
              idPrefix="tq"
              showErrors={questionErrors}
              onChange={(k, v) => setAnswers((p) => ({ ...p, [k]: v }))}
              className="gap-x-8"
            />
            {questionErrors && missingRequired(questions, answers).length > 0 && (
              <p role="alert" className="text-sm text-destructive">Answer the required {routedTeam} questions before submitting.</p>
            )}
          </section>
        )}
        {step === 2 && cfg.isError && (
          <p role="alert" className="text-sm text-destructive">
            {routedTeam || "The team"}'s questions couldn't be loaded.{" "}
            <button type="button" className="underline" onClick={() => void cfg.refetch()}>Retry</button>
          </p>
        )}

        {step === 2 && (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Upload className="size-4" aria-hidden="true" /> You can add supporting files on the intake page right after you submit.
          </p>
        )}
        <div className="flex flex-wrap gap-3">
          {step > 0 && (
            <Button type="button" variant="outline" size="lg" onClick={() => setStep(step - 1)}>
              <ArrowLeft aria-hidden="true" /> Previous page
            </Button>
          )}
          <Button type="submit" size="lg" disabled={submit.isPending}>
            {step < 2 ? (
              <>
                Next <ArrowRight aria-hidden="true" />
              </>
            ) : submit.isPending ? (
              "Submitting…"
            ) : (
              "Submit intake"
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}

function Section({ title, children, single }: { title: string; children: ReactNode; single?: boolean }) {
  return (
    <section className="space-y-4">
      <h2 className="border-l-4 border-primary bg-accent px-4 py-2.5 text-base font-semibold text-accent-foreground">{title}</h2>
      <div className={cn("grid gap-x-8 gap-y-4", !single && "md:grid-cols-2")}>{children}</div>
    </section>
  );
}

function Field({ id, label, required, hint, children }: { id: string; label: string; required?: boolean; hint?: string; children: ReactNode }) {
  return (
    <div className="grid content-start gap-1.5">
      <Label htmlFor={id} className="font-semibold">
        {label}
        {required && <span className="text-primary" aria-hidden="true">*</span>}
        {required && <span className="sr-only"> (required)</span>}
      </Label>
      {hint && (
        <p id={`${id}-hint`} className="text-xs italic text-muted-foreground">
          {hint}
        </p>
      )}
      {children}
    </div>
  );
}
