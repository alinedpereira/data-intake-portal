/**
 * Tenant-specific settings. Set them in app/.env (copy .env.example) or your build pipeline.
 * Nothing tenant-specific is hard-coded in the source.
 */
const env = import.meta.env;

/** Email domain of your users, e.g. "contoso.com" (also accepts "contoso.onmicrosoft.com"). */
export const EMAIL_DOMAIN: string = env.VITE_EMAIL_DOMAIN ?? "contoso.com";

/** SharePoint host, e.g. "contoso.sharepoint.com". */
export const SHAREPOINT_HOST: string = env.VITE_SHAREPOINT_HOST ?? "contoso.sharepoint.com";

/** Server-relative site path, e.g. "/sites/intake-requests". */
export const SITE_PATH: string = env.VITE_SITE_PATH ?? "/sites/intake-requests";

/** ID of the site's "Documents" library (Library settings > URL, or Graph). */
export const DOCUMENT_LIBRARY_ID: string = env.VITE_DOCUMENT_LIBRARY_ID ?? "00000000-0000-0000-0000-000000000000";

/** Demo requestor used by the POC "Requestor" view. Alias only; the domain comes from EMAIL_DOMAIN. */
export const DEMO_REQUESTOR_ALIAS: string = env.VITE_DEMO_REQUESTOR_ALIAS ?? "mauricioa";

export const SITE_URL = `https://${SHAREPOINT_HOST}${SITE_PATH}`;

/** Build a full email from an alias, e.g. emailFor("katria") -> "katria@contoso.com". */
export function emailFor(alias: string): string {
  return `${alias}@${EMAIL_DOMAIN}`;
}
