# Copilot instructions – D.A.T.A. Intake Portal (canvas rebuild)

You are helping build a **Power Apps canvas app** (responsive, inside a Power Platform solution) on **SharePoint Online lists**, with **Power Automate** cloud flows for all trusted logic. Follow these rules in every change.

## Product
A single front door where staff submit analytics and data-governance requests ("intakes"). Roles: **Requestor**, **Team Member** (stored internally as "Assignee"), **Manager**, and the **DML** (the P&BB DMO manager). Read `00-context/solution-overview.md` before building any screen.

## Data
- Data lives in the SharePoint lists defined in `00-context/data-model.md`. Never invent columns; if one is missing, say so.
- **Configuration is data.** Level 1/Level 2 types, routing, teams, focus areas, questions, question rules, QA config and stage transitions come from lists (IntakeRequestTypes, IntakeTeams, IntakeQuestions, IntakeQuestionRules, IntakeQAConfig, IntakeTransitions). **Do not hard-code team names, request types, question labels, choices or stage rules in formulas.**
- Cache configuration lists in collections in `App.OnStart` (`colTypes`, `colTeams`, `colQuestions`, `colRules`, `colQAConfig`, `colSubTeams`, `colTransitions`).
- Requestor answers go to **IntakeAnswers**, internal answers to **IntakeInternalAnswers**, one row per answer (`RequestItemId`, `QuestionKey`, `Title` = label snapshot, `AnswerValue`, `Points`).
- Activity history is in **IntakeActivity** and is written **only by flows**. The app reads it.

## Logic boundaries
- The app **never patches Status, RequestStatus, RequirementsSignedOff, AcceptanceSignedOff, BacklogScore or RequestNumber**. Call the flows:
  - `IntakeProcessSubmission.Run(IntakeId)` after submit (returns `requestnumber`).
  - `IntakeChangeStage.Run(IntakeId, Action, Target, Reason, ActorEmail)` for every stage change (Action "Move", Target = stage), assignment (Action "Assign", Target = owner email) and re-route (Action "Reroute", Target = team). Returns `ok`, `message`.
  - `IntakeAnswersChanged.Run(IntakeId, Audience, ChangeText, ActorEmail, ScoreOverride)` after answers are edited (ScoreOverride −1 = recalculate from points).
  - `IntakeWorkPackageChange.Run(WorkPackageId, Action, TargetStatus, Reason, ActorEmail)` for work packages.
  - `IntakeAskRequestor.Run(IntakeId, Mode, Text, ActorEmail)` for questions and answers.
- After a flow returns, refresh the record: `Set(varIntake, LookUp(IntakeRequests, ID = varIntake.ID))`.
- Show `Notify(varResult.message, NotificationType.Error)` when a flow returns `ok = "false"`.

## Roles in the app
- `IsManager` = the user is ManagerEmail on any IntakeTeams row. `IsTeamMember` = active row in IntakeTeamMembers. Otherwise Requestor.
- Hide/disable controls by role and stage for usability, but remember **security is SharePoint permissions**, not visibility.
- Requestors must never see internal answers or IsInternal activity rows.

## Delegation and performance
- Filter large lists only with delegable expressions: `=` on text/number, `.Value` on choice, `.Email` on person, `StartsWith`, `&&`. Avoid `in`, `Search`, `IsBlank` on large lists. Use `WorkPackageId = 0` for intake-level tasks.
- Use `Concurrent` for independent loads, `With` for repeated lookups, and galleries with `Items` bound to filtered sources (not ForAll over the whole list).
- Keep each screen under ~300 controls; split big screens into containers or components.

## UI style (BMO)
- Header bar dark grey (#20262E) with the BMO logo (red roundel) and "D.A.T.A. - Intake Portal". Left navigation 230 px, role-filtered.
- Colours: BMO Blue #0075BE (primary buttons, links), Navy #005789, Midnight #003758, Sky #00A9FB, Ice #E1F3FE (section bands, selected nav), BMO Red #ED1C24 (requestor call-to-action buttons), success green #16803D.
- Section headers are Ice bands with a 5 px BMO Blue left bar. Status pills: Ice/Navy (open), amber (waiting on someone), green (closed/accepted).
- Accessible: every input has a label, AccessibleLabel on icons, tab order follows layout, contrast ≥ 4.5:1.

## Naming
`scr` screens, `gal` galleries, `btn` buttons, `drp` dropdowns, `cmb` combo boxes, `txt` text inputs, `dte` date pickers, `lbl` labels, `con` containers, `col` collections, `var` globals, `loc` context variables. Use the names shown in orange on the wireframes.

## Definition of done for every screen
Each prompt in `02-prompts/` ends with **Acceptance checks**. Do not mark a screen done until every check passes for every role listed.
