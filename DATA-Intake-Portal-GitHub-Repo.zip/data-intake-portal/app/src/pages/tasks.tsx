import { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { ListChecks, Lock, Maximize2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { TaskDialog } from "@/components/task-bits";
import { TaskDetailsDialog } from "@/components/task-details";
import { useAppStore } from "@/lib/store";
import { LOCK_SCAN, TEAM_REQUEST_CAP, formatDate, odataString, useLockedRequestIds, useRequestIds } from "@/lib/intake";
import { useMyRequestScope } from "@/lib/people";
import { isTaskOverdue, taskAssigneeName, taskNumber, taskStatusOf, useTaskPage, type IntakeTask } from "@/lib/tasks";
import { cn } from "@/lib/utils";
import { segmentButtonClass, segmentGroupClass } from "@/lib/segment";

/**
 * Tasks for assignees and managers. On its own route it now redirects to the
 * "Requests & tasks" page's task tab; that page renders it with `embedded`.
 */
export function TasksPage({ embedded = false, extraFilter }: { embedded?: boolean; extraFilter?: string }) {
  const role = useAppStore((s) => s.role);
  if (role === "Requestor")
    return (
      <div className="p-8">
        <EmptyState icon={Lock} title="Tasks are only available to team members and managers" />
      </div>
    );
  if (!embedded) return <Navigate to="/work?tab=tasks" replace />;
  if (role === "Assignee") return <AssigneeTasks />;
  return <TasksBoard extraFilter={extraFilter} />;
}

/** Assignee view: only tasks whose Assigned To is the picked person. */
function AssigneeTasks() {
  const me = useAppStore((s) => s.me);
  const [adding, setAdding] = useState(false);
  const filter = me?.Email ? `AssignedTo/EMail eq ${odataString(me.Email)}` : undefined;
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-xl font-semibold tracking-tight">My tasks</h2>
        {me?.Email && (
          <Button onClick={() => setAdding(true)}>
            <Plus aria-hidden="true" /> New task
          </Button>
        )}
      </div>
      {!filter ? (
        <EmptyState
          icon={ListChecks}
          title="Pick yourself in the Owner box at the top of the page to see your tasks"
        />
      ) : (
        <Board key={filter} filter={filter} />
      )}
      {adding && <TaskDialog open onOpenChange={setAdding} />}
    </div>
  );
}

function TasksBoard({ extraFilter }: { extraFilter?: string }) {
  const manager = useAppStore((s) => s.manager);
  const [scope, setScope] = useState<"mine" | "all">("all");
  const [adding, setAdding] = useState(false);
  // Managers only see tasks on requests routed to their team(s).
  const teamScope = useMyRequestScope();
  const teamIds = useRequestIds(teamScope.filter && extraFilter ? `${teamScope.filter} and ${extraFilter}` : teamScope.filter);
  const ids = teamIds.data?.ids;
  const teamFilter = ids ? (ids.length ? `(${ids.map((id) => `RequestItemId eq ${id}`).join(" or ")})` : "ID eq 0") : undefined;
  // "My tasks" = tasks assigned to the manager picked at the top (e.g. DML approvals), on any intake.
  const mineFilter = manager?.email ? `AssignedTo/EMail eq ${odataString(manager.email)}` : undefined;
  const showMine = scope === "mine" && !!mineFilter;
  const filter = showMine ? mineFilter : teamFilter;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-xl font-semibold tracking-tight">{manager ? (showMine ? `${manager.name}'s tasks` : `${manager.name}'s team tasks`) : "Team tasks"}</h2>
        <div className="flex flex-wrap items-center gap-2">
          <div role="group" aria-label="Show" className={segmentGroupClass}>
            {(["mine", "all"] as const).map((s) => (
              <button
                key={s}
                type="button"
                aria-pressed={scope === s}
                disabled={s === "mine" && !mineFilter}
                onClick={() => setScope(s)}
                className={segmentButtonClass(scope === s)}
              >
                {s === "mine" ? "My tasks" : "All team tasks"}
              </button>
            ))}
          </div>
          <Button onClick={() => setAdding(true)}>
            <Plus aria-hidden="true" /> New task
          </Button>
        </div>
      </div>
      {showMine && <p className="text-sm text-muted-foreground">Tasks assigned to {manager?.name}, on any intake.</p>}
      {!showMine && teamIds.data?.partial && (
        <p className="text-sm text-muted-foreground">Showing tasks for the team's {TEAM_REQUEST_CAP} most recent intakes.</p>
      )}
      {showMine ? (
        <Board key={filter} filter={filter} />
      ) : teamScope.needsIdentity ? (
        <EmptyState icon={ListChecks} title="Choose a manager at the top to see their team's tasks" />
      ) : teamIds.isPending ? (
        <LoadingState rows={4} />
      ) : teamIds.isError ? (
        <ErrorState title="Team tasks could not be loaded" action={<Button onClick={() => void teamIds.refetch()}>Retry</Button>} />
      ) : (
        <Board key={filter} filter={filter} />
      )}
      {adding && <TaskDialog open onOpenChange={setAdding} />}
    </div>
  );
}

function Board({ filter }: { filter: string | undefined }) {
  const [skipToken, setSkipToken] = useState<string | undefined>();
  const [prev, setPrev] = useState<(string | undefined)[]>([]);
  const [openId, setOpenId] = useState<number | null>(null);
  const q = useTaskPage(filter, skipToken);
  const lockedQ = useLockedRequestIds();
  const rows = q.data?.rows ?? [];
  const nextToken = q.data?.nextToken;

  const isLocked = (t: IntakeTask) =>
    !lockedQ.data ||
    (!!t.RequestItemId &&
      (lockedQ.data.ids.has(t.RequestItemId) || (lockedQ.data.partial && !lockedQ.data.seen.has(t.RequestItemId))));

  if (q.isPending) return <LoadingState rows={4} />;
  if (q.isError) return <ErrorState title="Tasks could not be loaded" action={<Button onClick={() => void q.refetch()}>Retry</Button>} />;
  if (rows.length === 0 && prev.length === 0 && !nextToken)
    return <EmptyState icon={ListChecks} title="No tasks yet" description="Add a task to break an intake into internal work." />;

  // Group by parent request, most recent request first; tasks by due date (no date last).
  const groups = new Map<string, { key: string; requestId?: number; number?: string; title?: string; tasks: IntakeTask[] }>();
  for (const t of rows) {
    const key = t.RequestItemId ? String(t.RequestItemId) : "none";
    const g = groups.get(key) ?? { key, requestId: t.RequestItemId, number: t.RequestNumber, title: t.RequestTitle, tasks: [] };
    g.tasks.push(t);
    groups.set(key, g);
  }
  const due = (t: IntakeTask) => (t.DueDate ? new Date(t.DueDate).getTime() : Number.POSITIVE_INFINITY);
  const ordered = [...groups.values()].sort((a, b) => (b.requestId ?? 0) - (a.requestId ?? 0));
  ordered.forEach((g) => g.tasks.sort((a, b) => due(a) - due(b)));
  const openTask = openId != null ? rows.find((t) => t.ID === openId) : undefined;

  return (
    <>
      {lockedQ.isError && (
        <p role="alert" className="text-sm text-destructive">
          Task editing is paused because intake stages couldn't be checked.{" "}
          <button type="button" className="underline" onClick={() => void lockedQ.refetch()}>Retry</button>
        </p>
      )}
      {lockedQ.data?.partial && (
        <p className="text-sm text-muted-foreground">
          Locks are checked on the {LOCK_SCAN} most recent intakes; tasks on older intakes are treated as locked.
        </p>
      )}
      <div className="space-y-5">
        {ordered.map((g) => {
          const done = g.tasks.filter((t) => taskStatusOf(t) === "Done").length;
          return (
            <section key={g.key} aria-labelledby={`grp-${g.key}`} className="overflow-hidden rounded-lg border border-border bg-card">
              <div className="flex flex-wrap items-center justify-between gap-2 border-l-4 border-primary bg-accent px-4 py-2.5 text-accent-foreground">
                <h2 id={`grp-${g.key}`} className="min-w-0 font-semibold">
                  {g.requestId ? (
                    <Link to={`/requests/${g.requestId}`} className="hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                      {g.number ?? "Intake"} · {g.title}
                    </Link>
                  ) : (
                    "Not linked to an intake"
                  )}
                </h2>
                <span className="text-sm">{done} of {g.tasks.length} done</span>
              </div>
              <div aria-hidden="true" className="hidden grid-cols-[6rem_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_8rem_8rem_5rem] gap-x-4 border-b border-border px-4 py-1.5 text-xs font-medium text-muted-foreground sm:grid">
                <span>Task #</span><span>Task</span><span>Type</span><span>Assigned to</span><span>Due</span><span>Status</span><span />
              </div>
              <ul className="divide-y divide-border">
                {g.tasks.map((t) => {
                  const st = taskStatusOf(t);
                  const overdue = isTaskOverdue(t);
                  return (
                    <li key={t.ID}>
                      <button
                        type="button"
                        onClick={() => setOpenId(t.ID ?? null)}
                        aria-haspopup="dialog"
                        className="group grid w-full cursor-pointer grid-cols-1 gap-x-4 gap-y-1 px-4 py-3 text-left text-sm transition-colors hover:bg-accent/60 focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring sm:grid-cols-[6rem_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_8rem_8rem_5rem] sm:items-center"
                      >
                        <span className="font-mono text-xs font-semibold text-primary">{taskNumber(t)}</span>
                        <span className={cn("min-w-0 truncate font-semibold text-primary underline-offset-2 group-hover:underline", st === "Done" && "line-through")}>
                          {t.Title}
                          {isLocked(t) && <Lock className="ml-1.5 inline size-3.5 text-muted-foreground" aria-label="Locked" />}
                        </span>
                        <span className="truncate text-muted-foreground">{t.TaskType?.Value ?? "—"}</span>
                        <span className="truncate">{taskAssigneeName(t) ?? "Unassigned"}</span>
                        <span className={cn(overdue && "font-semibold text-red-700 dark:text-red-400")}>
                          {t.DueDate ? formatDate(t.DueDate) : "No due date"}
                          {overdue && <span className="sr-only"> (overdue)</span>}
                        </span>
                        <span><TaskStatusBadge status={st} /></span>
                        <span className="inline-flex items-center justify-end gap-1 text-xs font-medium text-primary">
                          Open <Maximize2 className="size-3.5" aria-hidden="true" />
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })}
      </div>
      {(prev.length > 0 || nextToken) && (
        <div className="flex items-center justify-end gap-2">
          <p className="mr-auto text-sm text-muted-foreground">Showing {rows.length} tasks on this page.</p>
          {prev.length > 0 && (
            <Button variant="outline" disabled={q.isFetching} onClick={() => { setSkipToken(prev[prev.length - 1]); setPrev((p) => p.slice(0, -1)); }}>Previous page</Button>
          )}
          {nextToken && (
            <Button disabled={q.isFetching} onClick={() => { setPrev((p) => [...p, skipToken]); setSkipToken(nextToken); }}>
              {q.isFetching ? "Loading…" : "Next page"}
            </Button>
          )}
        </div>
      )}
      {openTask && <TaskDetailsDialog key={openTask.ID} task={openTask} locked={isLocked(openTask)} onClose={() => setOpenId(null)} />}
    </>
  );
}

function TaskStatusBadge({ status }: { status: string }) {
  const tone =
    status === "Done"
      ? "bg-emerald-700 text-white"
      : status === "Blocked"
        ? "bg-red-700 text-white"
        : status === "In progress"
          ? "bg-primary text-primary-foreground"
          : "bg-muted text-foreground";
  return <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold", tone)}>{status}</span>;
}
