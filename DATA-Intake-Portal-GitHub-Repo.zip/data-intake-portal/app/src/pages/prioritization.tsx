import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ListOrdered } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { ChoiceSelect } from "@/components/choice-select";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { QuestionFields } from "@/components/team-questions";
import {
  applicable,
  changedLabels,
  draftFrom,
  formatAnswer,
  mergeAnswers,
  parseAnswers,
  scopeOf,
  scoreOf,
  scoringTeams,
  useQuestionConfig,
  type Draft,
} from "@/lib/team-questions";
import { PersonPicker } from "@/components/person-picker";
import { PriorityText, StatusPill } from "@/components/request-bits";
import {
  appendLog,
  displayStatus,
  formatDate,
  isOverdue,
  stageAfterAssign,
  odataString,
  requestNumber,
  statusOf,
  updateRequest,
  useChoices,
  useRequestPage,
  type IntakeRequest,
  type IntakeWrite,
} from "@/lib/intake";
import { ownerOf, personWrite, requestorOf, type Person } from "@/lib/people";
import { useMyManagedTeams } from "@/lib/teams";
import { actorName, useAppStore } from "@/lib/store";

/** Most queued intakes read at once; beyond this a note says the list is partial. */
const QUEUE_SCAN = 500;

function ageDays(r: IntakeRequest): number | undefined {
  const t = new Date(r.SubmittedOn ?? r.Created ?? "").getTime();
  return Number.isNaN(t) ? undefined : Math.max(0, Math.floor((Date.now() - t) / 86_400_000));
}

/** Intakes waiting to be assigned, for a team with scored questions, ranked by score. */
export function PrioritizationPage() {
  const role = useAppStore((s) => s.role);
  const mine = useMyManagedTeams();
  const cfg = useQuestionConfig();
  const myScoringTeams = mine.teams.filter((t) => scoringTeams(cfg.data).includes(t));
  const [picked, setPicked] = useState("");
  const team = myScoringTeams.includes(picked) ? picked : (myScoringTeams[0] ?? "");
  const allowed = role === "Manager" && !!team;
  const filter = `RoutedTeam eq ${odataString(team)} and (Status eq 'Submitted' or Status eq 'Queued')`;
  // Columns: the team's scored questions (same for any intake type of the team, by key).
  const scoredColumns = useMemo(() => {
    const seen = new Map<string, string>();
    for (const r of cfg.data?.rules ?? []) {
      if (r.scored && r.team === team && !seen.has(r.key)) seen.set(r.key, cfg.data?.questions.get(r.key)?.label ?? r.key);
    }
    return [...seen.entries()].map(([key, label]) => ({ key, label }));
  }, [cfg.data, team]);
  const q = useRequestPage(allowed ? filter : undefined, undefined, QUEUE_SCAN);
  const priorities = useChoices("Priority");
  const [open, setOpen] = useState<IntakeRequest | null>(null);

  const rows = useMemo(() => {
    const prioRank = (p?: string) => {
      const i = p ? (priorities.data ?? []).indexOf(p) : -1;
      return i < 0 ? 99 : i;
    };
    const time = (iso?: string) => (iso ? new Date(iso).getTime() : Number.POSITIVE_INFINITY);
    return [...(allowed && q.data ? q.data.rows : [])].sort((a, b) => {
      const sa = typeof a.BacklogScore === "number" ? a.BacklogScore : -1;
      const sb = typeof b.BacklogScore === "number" ? b.BacklogScore : -1;
      if (sa !== sb) return sb - sa;
      const pa = prioRank(a.Priority?.Value);
      const pb = prioRank(b.Priority?.Value);
      if (pa !== pb) return pa - pb;
      const na = time(a.NeededBy);
      const nb = time(b.NeededBy);
      if (na !== nb) return na - nb;
      return (a.ID ?? 0) - (b.ID ?? 0);
    });
  }, [allowed, q.data, priorities.data]);

  if (role !== "Manager" || mine.isPending || cfg.isPending) {
    return <div className="p-5 md:p-8"><LoadingState /></div>;
  }
  if (!allowed) {
    return (
      <div className="p-5 md:p-8">
        <EmptyState
          icon={ListOrdered}
          title="No prioritization queue for your teams"
          description="The queue is for teams that score their intakes (scored questions in the IntakeQuestionRules list). Choose that team's manager at the top."
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-5 p-5 md:p-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">{team} - Intake Prioritization Queue</h1>
        <p className="text-sm text-muted-foreground">
          Submitted and queued {team} intakes, highest Backlog Score first (then priority and needed-by date). Review each one, then assign it.
        </p>
        {myScoringTeams.length > 1 && (
          <div className="flex items-center gap-2 pt-2">
            <label htmlFor="pq-team" className="text-sm font-medium">Team</label>
            <NativeSelect id="pq-team" value={team} onChange={(e) => setPicked(e.target.value)} className="bg-card">
              {myScoringTeams.map((t) => <NativeSelectOption key={t} value={t}>{t}</NativeSelectOption>)}
            </NativeSelect>
          </div>
        )}
      </div>

      {q.isPending ? (
        <LoadingState />
      ) : q.isError ? (
        <ErrorState title="The queue could not be loaded" action={<Button onClick={() => void q.refetch()}>Retry</Button>} />
      ) : rows.length === 0 ? (
        <EmptyState icon={ListOrdered} title="Nothing waiting" description={`Every ${team} intake has been assigned.`} />
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg border border-border bg-card">
            <table className="w-full text-sm">
              <caption className="sr-only">{team} intakes waiting to be assigned, ranked by Backlog Score</caption>
              <thead className="bg-accent text-left text-accent-foreground">
                <tr>
                  {["Rank", "Intake #", "Intake title", "Backlog Score", ...scoredColumns.map((c) => c.label), "Priority", "Needed by", "Age", "Status", ""].map((h, i) => (
                    <th key={h || i} scope="col" className="whitespace-nowrap px-3 py-3 font-semibold">
                      {h || <span className="sr-only">Action</span>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((r, i) => {
                  const age = ageDays(r);
                  return (
                    <tr key={r.ID} className="hover:bg-muted/60">
                      <td className="px-3 py-3 font-semibold">{i + 1}</td>
                      <td className="whitespace-nowrap px-3 py-3">
                        <Link to={`/work/${r.ID}`} className="font-semibold text-primary underline-offset-2 hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                          {requestNumber(r)}
                        </Link>
                      </td>
                      <td className="min-w-48 px-3 py-3">
                        <span className="font-medium">{r.Title}</span>
                        <span className="block text-xs text-muted-foreground">{requestorOf(r) ?? "—"}</span>
                      </td>
                      <td className="px-3 py-3">
                        {typeof r.BacklogScore === "number" ? (
                          <span className="inline-flex min-w-8 justify-center rounded-md bg-primary px-2 py-0.5 font-semibold text-primary-foreground">{r.BacklogScore}</span>
                        ) : (
                          <span className="text-muted-foreground">Not scored</span>
                        )}
                      </td>
                      {scoredColumns.map((c) => {
                        const a = parseAnswers(r.RequestorAnswers)[c.key];
                        return (
                          <td key={c.key} className="px-3 py-3">
                            {formatAnswer(undefined, a?.v) ?? <span className="text-muted-foreground">—</span>}
                          </td>
                        );
                      })}
                      <td className="px-3 py-3"><PriorityText priority={r.Priority?.Value} /></td>
                      <td className="whitespace-nowrap px-3 py-3">
                        {formatDate(r.NeededBy)}
                        {isOverdue(r) && <span className="ml-2 text-xs font-semibold text-red-700 dark:text-red-400">Overdue</span>}
                      </td>
                      <td className="whitespace-nowrap px-3 py-3">{age === undefined ? "—" : `${age} d`}</td>
                      <td className="px-3 py-3"><StatusPill status={statusOf(r)} label={displayStatus(r)} /></td>
                      <td className="px-3 py-3">
                        <Button size="sm" onClick={() => setOpen(r)} aria-label={`Review ${requestNumber(r)}`}>Review</Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="text-sm italic text-muted-foreground">
            {rows.length} waiting. Intakes without a Backlog Score sit at the bottom until scored.
            {q.data?.nextToken ? ` Showing the latest ${QUEUE_SCAN}.` : ""}
          </p>
        </>
      )}

      {open && <ReviewDialog key={open.ID} r={open} onClose={() => setOpen(null)} />}
    </div>
  );
}

/** Review one intake: update scored answers, score and priority, then assign with a required comment. */
function ReviewDialog({ r, onClose }: { r: IntakeRequest; onClose: () => void }) {
  const qc = useQueryClient();
  const actor = useAppStore(actorName);
  const cfg = useQuestionConfig();
  // The scored questions for this intake's team and type; the score is the sum of their points.
  const questions = applicable(cfg.data, scopeOf(r), "Requestor").filter((q) => q.scored);
  const previous = parseAnswers(r.RequestorAnswers);
  const [edits, setEdits] = useState<Draft>({});
  const draft: Draft = { ...draftFrom(questions, previous), ...edits };
  const nextAnswers = mergeAnswers(questions, draft, previous);
  const answerChanges = changedLabels(questions, previous, nextAnswers);
  const auto = scoreOf(questions, nextAnswers);
  const [scoreText, setScoreText] = useState(typeof r.BacklogScore === "number" ? String(r.BacklogScore) : "");
  const [scoreTouched, setScoreTouched] = useState(false);
  const shownScore = scoreTouched ? scoreText : auto !== undefined ? String(auto) : scoreText;
  const scoreNum = shownScore.trim() === "" ? undefined : Number(shownScore);
  const scoreValid = scoreNum === undefined || (Number.isInteger(scoreNum) && scoreNum >= 0);
  const [priority, setPriority] = useState(r.Priority?.Value ?? "");
  const [owner, setOwner] = useState<Person | null>(ownerOf(r));
  const [comment, setComment] = useState("");
  const [tried, setTried] = useState(false);

  const changes = (): { write: Partial<Omit<IntakeWrite, "ID">>; notes: string[] } => {
    const write: Partial<Omit<IntakeWrite, "ID">> = {};
    const notes: string[] = [];
    if (answerChanges.length) {
      write.RequestorAnswers = JSON.stringify(nextAnswers);
      for (const q of questions) {
        if (previous[q.key]?.v !== nextAnswers[q.key]?.v) notes.push(`${q.label} set to ${formatAnswer(q.type, nextAnswers[q.key]?.v) ?? "not set"}`);
      }
    }
    if (scoreNum !== undefined && scoreNum !== r.BacklogScore) {
      write.BacklogScore = scoreNum;
      notes.push(`Backlog Score ${typeof r.BacklogScore === "number" ? `${r.BacklogScore} → ` : "set to "}${scoreNum}`);
    }
    if (priority && priority !== r.Priority?.Value) {
      write.Priority = { Value: priority };
      notes.push(`Priority ${r.Priority?.Value ? `${r.Priority.Value} → ` : "set to "}${priority}`);
    }
    return { write, notes };
  };

  const save = useMutation({
    mutationFn: async (assign: boolean) => {
      const { write, notes } = changes();
      if (assign && owner) {
        const to = stageAfterAssign(r);
        write.Owner = personWrite(owner);
        if (to) write.Status = { Value: to };
        notes.push(`Assigned to ${owner.DisplayName}${to ? ` and moved to ${to}` : ""}`);
      }
      const text = `Prioritization review: ${notes.length ? notes.join("; ") : "no field changes"}${comment.trim() ? `. Comment: ${comment.trim()}` : ""}`;
      await updateRequest(r.ID as number, {
        ...write,
        ActivityLog: appendLog(r.ActivityLog, { at: new Date().toISOString(), by: actor, role: "Manager", text }),
      });
      return assign;
    },
    onSuccess: (assign) => {
      void qc.invalidateQueries({ queryKey: ["requests"] });
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      toast.success(assign ? `${requestNumber(r)} assigned to ${owner?.DisplayName}.` : `${requestNumber(r)} updated.`);
      onClose();
    },
    onError: () => toast.error("The change could not be saved. Please try again."),
  });

  const assignBlocked = !owner || !comment.trim() || !scoreValid;
  const hasEdits = changes().notes.length > 0 || !!comment.trim();

  return (
    <Dialog open onOpenChange={(o) => !o && !save.isPending && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            Review {requestNumber(r)} · {r.Title}
          </DialogTitle>
          <DialogDescription>
            {requestorOf(r) ?? "Unknown requestor"} · needed by {formatDate(r.NeededBy)} · {displayStatus(r)}
          </DialogDescription>
        </DialogHeader>

        {r.RequestDescription && (
          <p className="max-h-32 overflow-y-auto whitespace-pre-wrap rounded-md bg-muted p-3 text-sm">{r.RequestDescription}</p>
        )}
        {r.BusinessValue && (
          <p className="text-sm"><span className="font-semibold">Business value: </span>{r.BusinessValue}</p>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          {questions.length > 0 && (
            <QuestionFields
              questions={questions}
              draft={draft}
              idPrefix="pq"
              onChange={(k, v) => setEdits((p) => ({ ...p, [k]: v }))}
              className="sm:col-span-2 md:grid-cols-2"
            />
          )}
          <div className="grid gap-1.5">
            <Label htmlFor="pq-score">Backlog Score</Label>
            <Input
              id="pq-score"
              inputMode="numeric"
              value={shownScore}
              onChange={(e) => {
                setScoreTouched(true);
                setScoreText(e.target.value);
              }}
              aria-describedby="pq-score-hint"
              aria-invalid={!scoreValid}
            />
            <p id="pq-score-hint" className={scoreValid ? "text-xs text-muted-foreground" : "text-xs text-destructive"}>
              {scoreValid
                ? auto !== undefined
                  ? `Calculated from the answers: ${auto}. You can override it.`
                  : "Answer the scored questions to calculate it, or enter a score."
                : "Enter a whole number, 0 or more."}
            </p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="pq-priority">Priority</Label>
            <ChoiceSelect id="pq-priority" field="Priority" value={priority} onChange={setPriority} />
          </div>
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor="pq-owner">Assign to</Label>
            <PersonPicker id="pq-owner" field="Owner" value={owner} onChange={setOwner} />
          </div>
          <div className="grid gap-1.5 sm:col-span-2">
            <Label htmlFor="pq-comment">
              Comment <span className="font-normal text-muted-foreground">(required to assign)</span>
            </Label>
            <Textarea
              id="pq-comment"
              rows={3}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Why this priority and owner"
              aria-invalid={tried && !comment.trim()}
            />
          </div>
        </div>
        {tried && assignBlocked && (
          <p role="alert" className="text-sm text-destructive">
            {!owner ? "Choose who to assign it to. " : ""}
            {!comment.trim() ? "Add a comment. " : ""}
            {!scoreValid ? "Fix the Backlog Score." : ""}
          </p>
        )}

        <DialogFooter className="gap-2 sm:justify-between">
          <Button variant="outline" disabled={save.isPending || !scoreValid || !hasEdits} onClick={() => save.mutate(false)}>
            Save, keep in queue
          </Button>
          <Button
            disabled={save.isPending}
            onClick={() => {
              setTried(true);
              if (!assignBlocked) save.mutate(true);
            }}
          >
            {save.isPending ? "Saving…" : stageAfterAssign(r) ? `Assign & move to ${stageAfterAssign(r)}` : "Assign"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
