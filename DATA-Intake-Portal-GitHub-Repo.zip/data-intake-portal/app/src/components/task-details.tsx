import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CalendarClock, ExternalLink, Lock, Pencil, Tag, Trash2, User } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FolderFiles } from "@/components/request-files";
import { TaskDialog, TaskStatusSelect } from "@/components/task-bits";
import { actorName, roleLabel, useAppStore } from "@/lib/store";
import { appendLog, formatDate, parseLog } from "@/lib/intake";
import { taskFolder } from "@/lib/files";
import { deleteTaskWithReason, isTaskOverdue, taskAssigneeName, taskNumber, taskStatusOf, updateTask, type IntakeTask, type TaskWrite } from "@/lib/tasks";
import { cn } from "@/lib/utils";

/** Full details of one task: status, link to its request, comments and files. */
export function TaskDetailsDialog({
  task,
  locked,
  lockedReason,
  onClose,
}: {
  task: IntakeTask;
  locked: boolean;
  /** Why the task is read-only; defaults to the request being at acceptance or closed. */
  lockedReason?: string;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const role = useAppStore((s) => s.role);
  const actor = useAppStore(actorName);
  const status = taskStatusOf(task);
  const [comment, setComment] = useState("");
  const [editing, setEditing] = useState(false);
  const log = parseLog(task.TaskActivity);
  const id = task.ID as number;

  const save = useMutation({
    mutationFn: ({ changes, note }: { changes: TaskWrite; note: string }) =>
      updateTask(id, {
        ...changes,
        TaskActivity: appendLog(task.TaskActivity, { at: new Date().toISOString(), by: actor, role, text: note }),
      }),
    onSuccess: (_d, { changes }) => {
      void qc.invalidateQueries({ queryKey: ["tasks"] });
      toast.success(changes.TaskStatus ? `Task moved to ${changes.TaskStatus.Value}` : "Saved");
    },
    onError: () => toast.error("The change could not be saved. Please try again."),
  });

  const [deleting, setDeleting] = useState(false);

  const overdue = isTaskOverdue(task);

  return (
    <>
      <Dialog open onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto sm:max-w-3xl">
          <DialogHeader>
            <p className="font-mono text-xs font-semibold text-primary">{taskNumber(task)}</p>
            <DialogTitle className={cn("pr-6 text-xl", status === "Done" && "line-through")}>{task.Title}</DialogTitle>
            <DialogDescription asChild>
              <div>
                {task.RequestItemId ? (
                  <Link
                    to={`/requests/${task.RequestItemId}`}
                    onClick={onClose}
                    className="inline-flex items-center gap-1 font-medium text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring"
                  >
                    {task.RequestNumber ?? "Intake"} · {task.RequestTitle}
                    <ExternalLink className="size-3.5" aria-hidden="true" />
                  </Link>
                ) : (
                  <span>Not linked to an intake</span>
                )}
              </div>
            </DialogDescription>
          </DialogHeader>

          {locked && (
            <p className="flex items-center gap-2 rounded-md bg-muted px-3 py-2 text-sm">
              <Lock className="size-4" aria-hidden="true" />
              {lockedReason ?? "The intake is at acceptance or closed, so this task can't be changed. Comments can still be added."}
            </p>
          )}

          <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <section aria-labelledby="td-details" className="space-y-4">
              <h3 id="td-details" className="sr-only">Details</h3>
              <dl className="grid grid-cols-[7.5rem_minmax(0,1fr)] gap-x-3 gap-y-2 text-sm">
                <dt className="text-muted-foreground"><User className="mr-1 inline size-3.5" aria-hidden="true" />Assigned to</dt>
                <dd className="font-semibold">{taskAssigneeName(task) ?? "Unassigned"}</dd>
                <dt className="text-muted-foreground"><Tag className="mr-1 inline size-3.5" aria-hidden="true" />Type</dt>
                <dd className="font-semibold">{task.TaskType?.Value ?? "—"}</dd>
                <dt className="text-muted-foreground"><CalendarClock className="mr-1 inline size-3.5" aria-hidden="true" />Due</dt>
                <dd className={cn("font-semibold", overdue && "text-red-700 dark:text-red-400")}>
                  {task.DueDate ? formatDate(task.DueDate) : "No due date"}
                  {overdue && " · overdue"}
                </dd>
              </dl>
              <div className="space-y-1">
                <h4 className="text-sm font-semibold">Description</h4>
                <p className="whitespace-pre-wrap rounded-md bg-muted/60 p-3 text-sm">{task.TaskNotes || "No description."}</p>
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor={`td-status-${id}`}>Status</Label>
                {locked ? (
                  <p id={`td-status-${id}`} className="text-sm font-semibold">{status}</p>
                ) : (
                  <TaskStatusSelect
                    id={`td-status-${id}`}
                    value={status}
                    onChange={(v) => v !== status && save.mutate({ changes: { TaskStatus: { Value: v } }, note: `Status changed to ${v}` })}
                  />
                )}
              </div>
              {!locked && (
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
                    <Pencil aria-hidden="true" /> Edit task
                  </Button>
                  {role === "Manager" && (
                  <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDeleting(true)}
                    >
                      <Trash2 aria-hidden="true" /> Delete
                    </Button>
                  )}
                </div>
              )}
            </section>

            <section aria-labelledby={`td-comments-${id}`} className="space-y-3">
              <h3 id={`td-comments-${id}`} className="font-semibold">Comments and activity</h3>
              <form
                className="grid gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!comment.trim()) return;
                  save.mutate({ changes: {}, note: comment.trim() });
                  setComment("");
                }}
              >
                <Label htmlFor={`td-comment-${id}`} className="sr-only">Comment</Label>
                <Textarea id={`td-comment-${id}`} rows={2} value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Add a comment…" />
                <Button type="submit" size="sm" className="justify-self-start" disabled={save.isPending || !comment.trim()}>
                  Add comment
                </Button>
              </form>
              {log.length === 0 ? (
                <p className="text-sm text-muted-foreground">No comments yet.</p>
              ) : (
                <ol className="max-h-64 space-y-2 overflow-y-auto pr-1">
                  {[...log].reverse().map((e, i) => (
                    <li key={`${e.at}-${i}`} className="rounded-md border border-border bg-card px-3 py-2 text-sm">
                      <p className="whitespace-pre-wrap">{e.text}</p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {e.by} · {roleLabel(e.role)} · {new Date(e.at).toLocaleString()}
                      </p>
                    </li>
                  ))}
                </ol>
              )}
            </section>
          </div>

          {task.RequestNumber ? (
            <FolderFiles
              folder={taskFolder(task.RequestNumber, id)}
              title="Task files"
              compact
              readOnly={locked}
              onUploaded={(names) => save.mutate({ changes: {}, note: `File${names.length > 1 ? "s" : ""} added: ${names.join(", ")}` })}
            />
          ) : (
            <p className="text-sm text-muted-foreground">Files can be added once the task is linked to a numbered intake.</p>
          )}
        </DialogContent>
      </Dialog>
      {editing && <TaskDialog open onOpenChange={setEditing} task={task} />}
      {deleting && role === "Manager" && <DeleteTaskDialog task={task} onClose={() => setDeleting(false)} onDeleted={onClose} />}
    </>
  );
}

/** Delete a task after recording why; the reason goes into the request's activity history. */
export function DeleteTaskDialog({ task, onClose, onDeleted }: { task: IntakeTask; onClose: () => void; onDeleted?: () => void }) {
  const qc = useQueryClient();
  const [reason, setReason] = useState("");
  const del = useMutation({
    mutationFn: () => deleteTaskWithReason(task, reason.trim()),
    onSuccess: (logged) => {
      void qc.invalidateQueries({ queryKey: ["tasks"] });
      void qc.invalidateQueries({ queryKey: ["requests"] });
      void qc.invalidateQueries({ queryKey: ["request"] });
      if (logged) toast.success(`Task ${taskNumber(task)} deleted`);
      else toast.error(`Task ${taskNumber(task)} was deleted, but the reason couldn't be saved to the intake history.`);
      onClose();
      onDeleted?.();
    },
    onError: () => toast.error("The task could not be deleted. Please try again."),
  });
  return (
    <Dialog open onOpenChange={(o) => !o && !del.isPending && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete {taskNumber(task)}?</DialogTitle>
          <DialogDescription>
            "{task.Title}" and its comments will be removed. Your reason is saved to the intake's activity history.
          </DialogDescription>
        </DialogHeader>
        <form
          className="grid gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (reason.trim()) del.mutate();
          }}
        >
          <Label htmlFor={`del-reason-${task.ID}`}>Reason for deleting</Label>
          <Textarea id={`del-reason-${task.ID}`} rows={3} required value={reason} onChange={(e) => setReason(e.target.value)} />
          <div className="mt-2 flex justify-end gap-2">
            <Button type="button" variant="outline" disabled={del.isPending} onClick={onClose}>Cancel</Button>
            <Button type="submit" variant="destructive" disabled={del.isPending || !reason.trim()}>
              {del.isPending ? "Deleting…" : "Delete task"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
