import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ErrorState } from "@/components/states";
import { TaskDialog, TaskStatusSelect } from "@/components/task-bits";
import { DeleteTaskDialog, TaskDetailsDialog } from "@/components/task-details";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { formatDate, odataString, type IntakeRequest } from "@/lib/intake";
import { useAppStore } from "@/lib/store";
import { isTaskOverdue, taskAssigneeName, taskStatusOf, updateTask, useTaskPage, type IntakeTask } from "@/lib/tasks";
import { cn } from "@/lib/utils";

/** Full-width section listing every task linked to one request (assignees and managers only). */
export function RequestTaskPanel({
  request,
  locked = false,
  workPackageId,
  heading,
  fullAccess = false,
}: {
  request: IntakeRequest;
  locked?: boolean;
  /** Only tasks in this work package; new tasks are added to it. */
  workPackageId?: number;
  heading?: string;
  /** Show every task (e.g. to the work package owner), not only the viewer's own. */
  fullAccess?: boolean;
}) {
  const [skipToken, setSkipToken] = useState<string | undefined>();
  const [prev, setPrev] = useState<(string | undefined)[]>([]);
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<IntakeTask | null>(null);
  const qc = useQueryClient();
  const role = useAppStore((s) => s.role);
  const me = useAppStore((s) => s.me);
  const myEmail = me?.Email?.toLowerCase();
  // Assignees see every task on requests they own; on other requests, only tasks assigned to them.
  const ownsRequest = !!myEmail && request.Owner?.Email?.toLowerCase() === myEmail;
  const assigneeLimited = role === "Assignee" && !ownsRequest && !fullAccess;
  // Assignees can only change their own tasks; others' tasks are view-only (comments allowed).
  const canEdit = (t: IntakeTask) => role !== "Assignee" || fullAccess || (!!myEmail && t.AssignedTo?.Email?.toLowerCase() === myEmail);
  const [viewing, setViewing] = useState<number | null>(null);
  const [deletingTask, setDeletingTask] = useState<IntakeTask | null>(null);
  const base = `RequestItemId eq ${Number(request.ID)}${workPackageId ? ` and WorkPackageId eq ${Number(workPackageId)}` : ""}`;
  const filter = assigneeLimited
    ? me?.Email
      ? `${base} and AssignedTo/EMail eq ${odataString(me.Email)}`
      : `${base} and ID eq 0`
    : base;
  const q = useTaskPage(filter, skipToken, 100);
  const all = q.data?.rows ?? [];
  // On the intake itself, show only intake-level tasks; work package tasks live on each work package's page.
  const rows = workPackageId ? all : all.filter((t) => !t.WorkPackageId);
  const wpTaskCount = workPackageId ? 0 : all.length - rows.length;
  const nextToken = q.data?.nextToken;
  const paged = prev.length > 0 || !!nextToken;
  const doneCount = rows.filter((t) => taskStatusOf(t) === "Done").length;

  const setStatus = useMutation({
    mutationFn: ({ id, v }: { id: number; v: string }) => updateTask(id, { TaskStatus: { Value: v } }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["tasks"] }),
    onError: () => toast.error("The task could not be saved. Please try again."),
  });

  return (
    <section aria-labelledby="req-tasks-h" className="overflow-hidden rounded-lg border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-l-4 border-primary bg-accent px-4 py-2.5 text-accent-foreground">
        <h2 id="req-tasks-h" className="font-semibold">
          {heading ?? (assigneeLimited ? "Your tasks on this intake" : "Tasks for this intake")}
          {q.isSuccess && rows.length > 0 && (
            <span className="ml-2 text-sm font-normal">
              {doneCount} of {rows.length} done{paged ? " on this page" : ""}
            </span>
          )}
        </h2>
        {!locked && (
          <Button size="sm" onClick={() => setAdding(true)}>
            <Plus aria-hidden="true" /> Add task
          </Button>
        )}
      </div>
      {q.isSuccess && rows.length > 0 && (
        <div className="h-2 bg-muted" aria-hidden="true">
          <div className="h-full bg-emerald-700" style={{ width: `${(doneCount / rows.length) * 100}%` }} />
        </div>
      )}
      <div className="p-4">
        {q.isPending ? (
          <p className="text-sm text-muted-foreground">Loading tasks…</p>
        ) : q.isError ? (
          <ErrorState className="py-6" title="Tasks could not be loaded" action={<Button size="sm" onClick={() => void q.refetch()}>Retry</Button>} />
        ) : rows.length === 0 && prev.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {workPackageId ? "No tasks in this work package yet." : "No intake-level tasks yet."}
            {wpTaskCount > 0 && ` ${wpTaskCount} task${wpTaskCount === 1 ? " is" : "s are"} managed inside the work packages above.`}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <caption className="sr-only">Tasks for {request.Title}</caption>
              <thead className="text-left text-muted-foreground">
                <tr>
                  <th scope="col" className="py-2 pr-4 font-medium">Task</th>
                  <th scope="col" className="py-2 pr-4 font-medium">Type</th>
                  <th scope="col" className="py-2 pr-4 font-medium">Assigned to</th>
                  <th scope="col" className="py-2 pr-4 font-medium">Due</th>
                  <th scope="col" className="w-48 py-2 pr-4 font-medium">Status</th>
                  <th scope="col" className="py-2 pr-4 font-medium">Notes</th>
                  <th scope="col" className="py-2 font-medium"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((t) => {
                  const st = taskStatusOf(t);
                  const overdue = isTaskOverdue(t);
                  return (
                    <tr key={t.ID} className="align-top">
                      <td className="py-2.5 pr-4">
                        <button
                          type="button"
                          aria-haspopup="dialog"
                          onClick={() => setViewing(t.ID ?? null)}
                          className={cn(
                            "text-left font-semibold text-primary underline-offset-2 hover:underline focus-visible:outline-2 focus-visible:outline-ring",
                            st === "Done" && "line-through",
                          )}
                        >
                          {t.Title}
                        </button>
                        {!canEdit(t) && <span className="ml-2 text-xs text-muted-foreground">View only</span>}
                      </td>
                      <td className="py-2.5 pr-4">{t.TaskType?.Value ?? "—"}</td>
                      <td className="py-2.5 pr-4">{taskAssigneeName(t) ?? "Unassigned"}</td>
                      <td className={cn("whitespace-nowrap py-2.5 pr-4", overdue && "font-semibold text-red-700 dark:text-red-400")}>
                        {t.DueDate ? formatDate(t.DueDate) : "—"}
                        {overdue && " · overdue"}
                      </td>
                      <td className="py-2 pr-4">
                        {locked || !canEdit(t) ? (
                          <span>{st}</span>
                        ) : (
                        <TaskStatusSelect
                          id={`rt-status-${t.ID}`}
                          label={`Status of ${t.Title}`}
                          value={st}
                          onChange={(v) => v !== st && setStatus.mutate({ id: t.ID as number, v })}
                        />
                        )}
                      </td>
                      <td className="max-w-xs py-2.5 pr-4 text-muted-foreground"><p className="line-clamp-2 whitespace-pre-wrap">{t.TaskNotes || "—"}</p></td>
                      <td className="py-1.5">
                        {!locked && canEdit(t) && (
                          <span className="flex">
                            <Button variant="ghost" size="icon" aria-label={`Edit task ${t.Title}`} onClick={() => setEditing(t)}>
                              <Pencil aria-hidden="true" />
                            </Button>
                            {role === "Manager" && (
                              <Button variant="ghost" size="icon" aria-label={`Delete task ${t.Title}`} onClick={() => setDeletingTask(t)}>
                                <Trash2 aria-hidden="true" />
                              </Button>
                            )}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {paged && (
              <div className="mt-3 flex justify-end gap-2">
                {prev.length > 0 && <Button size="sm" variant="outline" disabled={q.isFetching} onClick={() => { setSkipToken(prev[prev.length - 1]); setPrev((p) => p.slice(0, -1)); }}>Previous page</Button>}
                {nextToken && <Button size="sm" disabled={q.isFetching} onClick={() => { setPrev((p) => [...p, skipToken]); setSkipToken(nextToken); }}>Next page</Button>}
              </div>
            )}
          </div>
        )}
      </div>
      {!locked && adding && <TaskDialog open onOpenChange={setAdding} request={request} workPackageId={workPackageId} />}
      {!locked && role === "Manager" && deletingTask && <DeleteTaskDialog task={deletingTask} onClose={() => setDeletingTask(null)} />}
      {!locked && editing && <TaskDialog open onOpenChange={(o) => !o && setEditing(null)} task={editing} />}
      {(() => {
        const t = viewing != null ? rows.find((x) => x.ID === viewing) : undefined;
        if (!t) return null;
        const readOnly = locked || !canEdit(t);
        return (
          <TaskDetailsDialog
            key={t.ID}
            task={t}
            locked={readOnly}
            lockedReason={locked ? undefined : "This task is assigned to someone else, so you can view it and add comments but not change it."}
            onClose={() => setViewing(null)}
          />
        );
      })()}
    </section>
  );
}
