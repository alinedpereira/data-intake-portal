import { create } from "zustand";
import type { Person } from "@/lib/people";
import { DEMO_REQUESTOR_ALIAS, emailFor } from "@/config";

export type Role = "Requestor" | "Assignee" | "Manager";

/** POC: Requestor view always acts as this person, so no name picking is needed. */
export const DEFAULT_REQUESTOR: Person = {
  "@odata.type": "#Microsoft.Azure.Connectors.SharePoint.SPListExpandedUser",
  Claims: `i:0#.f|membership|${emailFor(DEMO_REQUESTOR_ALIAS)}`,
  DisplayName: "Mauricio August",
  Email: emailFor(DEMO_REQUESTOR_ALIAS),
  Picture: "",
  Department: "Commercial Marketing",
  JobTitle: "Director, Market Development & Insights",
};

interface AppState {
  role: Role;
  setRole: (role: Role) => void;
  /** Name used to find "my" assignments (assignee) and to sign activity entries. Session memory only. */
  myName: string;
  setMyName: (name: string) => void;
  /** Assignee picked in Assignee view (requests they own, tasks assigned to them). Session memory only. */
  me: Person | null;
  setMe: (me: Person | null) => void;
  /** Manager being acted as in Manager view (from the IntakeTeams list). Session memory only. */
  manager: { name: string; email: string } | null;
  setManager: (manager: { name: string; email: string } | null) => void;
}

/** How a role is shown to people. "Assignee" is displayed as "Team Member" (stored value unchanged). */
export function roleLabel(role: string): string {
  return role === "Assignee" ? "Team Member" : role;
}

/** Name recorded in activity history for the current view. */
export function actorName(s: Pick<AppState, "role" | "myName" | "manager">): string {
  if (s.role === "Manager") return s.manager?.name || "Manager";
  if (s.role === "Requestor") return DEFAULT_REQUESTOR.DisplayName;
  return s.myName || s.role;
}

export const useAppStore = create<AppState>((set) => ({
  role: "Requestor",
  setRole: (role) => set({ role }),
  myName: "",
  setMyName: (myName) => set({ myName }),
  me: null,
  setMe: (me) => set(me ? { me, myName: me.DisplayName } : { me }),
  manager: null,
  setManager: (manager) => set({ manager }),
}));
