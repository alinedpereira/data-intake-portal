==========================================================================
  D.A.T.A. INTAKE PORTAL - SHAREPOINT LISTS
  VERSION 3: USERS NEVER OPEN SHAREPOINT. FLOWS DO THE WORK.
  For: Power Apps canvas app + SharePoint lists + Power Automate
==========================================================================

  Read this first (about 15 minutes).
  Steps marked [DO] are things you do. Everything else is explanation.


--------------------------------------------------------------------------
 1. WHAT CHANGED FROM VERSION 2
--------------------------------------------------------------------------

  1. Users get NO access to the lists. Only a service account (and your
     admins) can open them.
  2. The app has NO SharePoint connection. It calls Power Automate flows.
     The flows read and write the lists and send back only what that
     person may see.
  3. IntakeInternalDetails is GONE. Team-only fields now sit on the
     request row in IntakeRequests. That is safe because no user can
     read the list, and the flows never send internal columns to a
     requestor.
  4. Two small technical columns on IntakeRequests:
       PromotePending  tells the Promote flow to refresh report columns
                       (replaces PromotedJson)
       RowVersion      stops two people overwriting each other's changes
  5. New file 06-Flow-Catalogue.csv lists every flow, who may call it,
     what it receives and what it returns.

  Still true from version 2: one row per request, answers in JSON, report
  columns filled by a flow, and new questions need NO app change.


--------------------------------------------------------------------------
 2. THE DESIGN IN ONE PICTURE
--------------------------------------------------------------------------

     PEOPLE                     APP                FLOWS               SHAREPOINT
   ------------------      --------------     -----------------     ----------------
   Requestor        --->    Canvas app  --->   IF_ flows        --->  Lists + library
   Team member              (no SharePoint     run as the             (only the service
   Manager                   connection)       SERVICE ACCOUNT;       account and admins
   Approver                                    check the caller's     have access)
                                               role every time

   CONFIGURATION LISTS (admins edit)        TRANSACTION LISTS (flows write)
   ---------------------------------        --------------------------------
   IntakeTeams                              IntakeRequests  ONE row per request
   IntakeRoleAssignments                      |-- IntakeTasks      many per request
   IntakeRequestTypes                         |-- IntakeApprovals  many per request
   IntakeQuestions                            |-- IntakeActivity   many per request
   IntakeQuestionRules                        |-- IntakeEvidence   library, a folder
                                                                   per request

   9 lists + 1 document library.


--------------------------------------------------------------------------
 3. WHO CAN SEE WHAT
--------------------------------------------------------------------------

   WHO                  SHAREPOINT ACCESS             SEES IN THE APP (via flows)
   -------------------  ----------------------------  ---------------------------------
   Requestor            None on lists. Read on the    Own requests (and ones "on behalf
                        /Shared folder of their own   of" them), their answers, shared
                        requests only                 timeline and files, task status,
                                                      their approvals. NEVER internal
                                                      fields.
   Team member          None on lists. Edit on the    Their team's queue, internal
                        folders of requests/tasks     fields, tasks, all files
                        assigned to them
   Manager              None on lists. Edit on the    Same as team + dashboard,
                        folders of their team's       assign, reroute, close
                        requests
   Approver (DML)       None                          Approvals waiting for them
   Admin                Site Owner                    Everything; edits config lists
   Service account      Contribute on lists, Full     (runs every flow)
                        Control on IntakeEvidence

   Files are the one exception to "no SharePoint access": people get
   access to ONE request's folder, never to a list. If you want zero
   access, use the optional preview flow IF_GetEvidenceFile instead
   (works for images and small PDFs). Decide this before go-live.

   SECURITY RULE: the flows check the caller's role on EVERY call.
   Hiding a button in the app is for convenience only.


--------------------------------------------------------------------------
 4. HOW ANSWERS ARE STORED (ALL ON THE REQUEST ROW)
--------------------------------------------------------------------------

   TIER 1  CORE COLUMNS        Title, RequestTypeCode, TeamCode, Priority,
                               Stage, RequestorEmail, AssignedToEmail ...
   TIER 2  REPORT COLUMNS      Filled by the Promote flow from answers:
                               requestor: BusinessObjective, BusinessImpact,
                                 RegulatoryDriver, RegulatoryReference,
                                 OmpRevenueBand, OmpChannelEnablement,
                                 TargetLaunchDate, DataOwner, ContainsPII
                               internal:  EffortDays, DataClassification,
                                 PrivacyReview, LegalReviewNeeded
   TIER 3  ALL ANSWERS         AnswersJson  + AnswersSummary   (requestor)
                               InternalJson + InternalSummary  (team only)

   AnswersJson example:
     [{"k":"business_impact","q":"Expected business impact","t":"Choice","v":"High"},
      {"k":"omp_offer_code","q":"Existing offer code","t":"Text","v":"MC-CASHBACK-2025"}]
     k = question key, q = question text, t = type, v = answer

   JSON columns are plain "Multiple lines of text" (rich text OFF).
   SharePoint has no JSON column type; the app and flows read the text.

   Which question goes where?  IntakeQuestionRules.Audience:
     Requestor -> AnswersJson    Internal -> InternalJson
   Which answers get a real column?  IntakeQuestions.ReportColumn.
   ContainsPII is asked of requestors (DMO) and internally (CA); if both
   answer, the team's answer wins.


--------------------------------------------------------------------------
 5. [DO] SET UP - IN THIS ORDER
--------------------------------------------------------------------------

  STEP 1  SERVICE ACCOUNT  (ask IT)
     A work account such as svc-intake@yourcompany.com with a mailbox
     and Power Automate (Microsoft 365 licence). Agree MFA/sign-in rules.

  STEP 2  SITE
     Create a SharePoint team site, e.g. .../sites/DATA-Intake.
     Owners = your admins only. Do NOT add requestors or teams as members.

  STEP 3  CREATE THE LISTS - pick ONE option

     OPTION A - SCRIPT (recommended, about 10 minutes)
       1. Install PowerShell 7:     winget install Microsoft.PowerShell
       2. In PowerShell 7:          Install-Module PnP.PowerShell -Scope CurrentUser
       3. Get a PnP Client ID from IT, or (if allowed) run:
            Register-PnPEntraIDAppForInteractiveLogin -ApplicationName "PnP Intake" -Tenant yourtenant.onmicrosoft.com
       4. Unzip this pack, then:
            cd "C:\path\to\DATA-Intake-SharePoint-Lists-v3"
            ./04-Create-And-Import-Lists.ps1 -SiteUrl https://yourtenant.sharepoint.com/sites/DATA-Intake -ClientId <id> -EmailDomain yourcompany.com
          Production: add  -SkipSampleData
       The script creates every column with the right type, index and
       choices, imports the configuration (and sample data), and re-links
       tasks/approvals/activity to the real request IDs.

     OPTION B - BY HAND (about 1-2 hours)
       FIRST: Replace All  {EmailDomain}  in each CSV with your domain
       (for example contoso.com), then continue.
       For each CSV in 1-Configuration-Lists, then 2-Transaction-Lists
       (IntakeRequests FIRST, into a brand-new list, so IDs are 1-14):
         1. Site > New > List > From CSV > upload the file. Keep the name.
         2. In the preview, set each column type as in
            01-Column-Definitions.csv (Type column):
              Yes/No, Choice, Date, Number columns - fix them here.
              AnswersJson, AnswersSummary, InternalJson, InternalSummary,
              Description, Notes, Details, ChoiceOptions, HelpText
                -> Multiple lines of text
         3. Create. Then for every multi-line column: List settings >
            the column > "Plain text" (NOT enhanced rich text) and
            "Append changes to existing text" = No.
         4. List settings > Indexed columns: add every column with
            Indexed = Yes in 01-Column-Definitions.csv.
       IntakeEvidence is a DOCUMENT LIBRARY: New > Document library,
       then add the columns in 3-Document-Library by hand.

  STEP 4  LOCK THE LISTS DOWN
     Script: run it again with only this added (safe to re-run):
       ./04-Create-And-Import-Lists.ps1 -SiteUrl <url> -ClientId <id> -SkipSampleData -SkipConfigData -ServiceAccount svc-intake@yourcompany.com
     By hand: for each list > Settings > Permissions for this list >
       Stop inheriting > remove Members and Visitors > Grant the service
       account Contribute (Full Control on IntakeEvidence).

  STEP 5  BUILD THE FLOWS  (03-Flow-Recipes.txt)
     Sign in to Power Automate as the service account (add yourself as
     co-owner). Build in this order and test each one:
       1. IF_GetBootstrap         (proves identity + role check work)
       2. IF_SubmitRequest
       3. IF_Auto_PromoteAnswers
       4. IF_GetMyRequests, IF_GetRequest
       5. IF_UpdateMyRequest
       6. IF_GetTeamQueue, IF_GetMyWork
       7. IF_SaveRequestInternal, IF_SaveTask
       8. IF_ChangeStage, IF_RecordDecision
       9. IF_UploadEvidence (+ optional IF_GetEvidenceFile)
      10. Optional: IF_Sched_DailyReminders
     Every app flow: one Text input "payload"; responds ok / message / data.

  STEP 6  BUILD THE APP  (02-PowerFx-Snippets.txt)
     Add the flows only - no SharePoint data source. Screens:
       Loading > New Request > My Requests > Request detail >
       My Work > Manager Dashboard > Help

  STEP 7  TEST  (with the sample data, three test users)
     [ ] Requestor opens a list URL directly in the browser -> "access denied"
     [ ] Requestor sees only their own requests; no Internal tab, no
         internal fields in any response (check a flow run's outputs)
     [ ] Requestor cannot open another request by changing the ID
     [ ] Team member sees the team queue and internal fields
     [ ] Manager can assign, reroute, close; team member cannot reroute
     [ ] Two people edit the same request -> second save says "conflict"
     [ ] After submit, report columns and AnswersSummary fill within ~1 min
     [ ] Requestor can open their shared folder, not the Internal folder
     [ ] Then delete all rows in the transaction lists before go-live


--------------------------------------------------------------------------
 6. WHAT IS IN THIS PACK
--------------------------------------------------------------------------

  00-README.txt .................. this file
  01-Column-Definitions.csv ...... every column: type, required, indexed,
                                   unique, default, choices, who writes it,
                                   purpose, and WHO GETS IT BACK (ReturnedTo)
  02-PowerFx-Snippets.txt ........ app formulas: call flows, build the
                                   dynamic form, submit, detail, dashboard
  03-Flow-Recipes.txt ............ every flow step by step, with the
                                   identity and role checks
  04-Create-And-Import-Lists.ps1 . creates lists, imports CSVs, locks down
  05-PowerBI-and-Excel.txt ....... reporting without giving users list access
  06-Flow-Catalogue.csv .......... one line per flow: who, input, output,
                                   lists read and written

  1-Configuration-Lists/  real configuration from the app we built
     IntakeTeams.csv ............ 13 teams
     IntakeRoleAssignments.csv .. 25 role rows
     IntakeRequestTypes.csv ..... 18 request types
     IntakeQuestions.csv ........ 27 questions (13 with a ReportColumn)
     IntakeQuestionRules.csv .... 30 rules

  2-Transaction-Lists/    SAMPLE data from the requests in the app
     IntakeRequests.csv ......... 14 requests in every stage (2 with
                                  internal answers filled in)
     IntakeTasks.csv ............ 17 tasks
     IntakeApprovals.csv ........ 10 approvals
     IntakeActivity.csv ......... 84 timeline entries

  3-Document-Library/IntakeEvidence-ColumnsOnly.csv  library columns

  About the sample data: requests, tasks, owners and timelines come from
  the proof-of-concept app. Filled in for the demo: business impact
  (from priority), business objective (from the POC business value) and
  the regulatory reference on the risk review.


--------------------------------------------------------------------------
 7. EVERY LIST - WHAT IT IS FOR
--------------------------------------------------------------------------

  IntakeTeams ............ teams, managers, focus areas (routing, Help).
  IntakeRoleAssignments .. who is Manager / Team Member / Approver / Admin
                           for which team. The flows use it for every
                           security check. Everyone is a Requestor.
  IntakeRequestTypes ..... Level 1 > Level 2 menu, default team, approval
                           path, QA and sign-off flags.
  IntakeQuestions ........ question catalogue: text, type, choices with
                           points, help, ReportColumn.
  IntakeQuestionRules .... which question shows for which team/type,
                           Requestor or Internal, order, required,
                           show-if, dates, scoring.
  IntakeRequests ......... the queue. One row per request with core,
                           report, and ALL answers (requestor + internal).
  IntakeTasks ............ work items. Manager creates and assigns;
                           assignee updates status and notes.
  IntakeApprovals ........ every sign-off: requirements, DML, acceptance.
  IntakeActivity ......... timeline and audit. Visibility decides whether
                           the requestor sees an entry.
  IntakeEvidence ......... files. /INT-000123/Shared and /Internal.


--------------------------------------------------------------------------
 8. [DO] HOW TO ENHANCE - NO APP CHANGE, NO FLOW CHANGE
--------------------------------------------------------------------------

  A. ADD A QUESTION (e.g. CA wants "Target customer segment")
     1. IntakeQuestions > New: Title, QuestionKey = target_segment,
        QuestionType = Choice, ChoiceOptions = Retail;Small Business;Enterprise,
        OwnerTeamCode = CA, IsActive = Yes
     2. IntakeQuestionRules > New: QuestionKey = target_segment,
        TeamCode = CA, Audience = Requestor (or Internal), Section,
        SortOrder, IsRequired, IsActive = Yes
     3. Done. Users see it next time they open the app.

  B. MAKE AN ANSWER REPORTABLE (its own column)
     1. IntakeRequests > Add column, e.g. TargetSegment (no spaces).
        Text for choices, Number, Date or Yes/No as fits.
     2. IntakeQuestions > target_segment > ReportColumn = TargetSegment
     3. Done. The Promote flow fills it on the next save. To fill old
        requests, set PromotePending = Yes on them (backfill, see
        03-Flow-Recipes.txt D1).
     The column is for reports. To also show it in the app, add it to
     the TEAM VIEW in the flows (recipe B4). Requestors never receive it
     unless you add it to the REQUESTOR VIEW - keep internal ones out.

  C. ONE REQUEST TYPE ONLY      rule: RequestTypeCode = e.g. RPT-NEW
  D. EVERY REQUEST              rule: TeamCode, Level1, RequestTypeCode blank
  E. SHOW ONLY IF               rule: ShowIfKey = regulatory_driver, ShowIfValue = Yes
  F. TEAM-ONLY QUESTION         rule: Audience = Internal
  G. CHANGE WORDING             edit Title in IntakeQuestions
  H. RETIRE A QUESTION          rule IsActive = No (never delete answered questions)
  I. SCORE A QUESTION           ChoiceOptions High|3;Medium|2;Low|1 and rule IsScored = Yes
  J. ADD A REQUEST TYPE         new IntakeRequestTypes row
  K. ADD A TEAM                 new IntakeTeams row + Manager row in IntakeRoleAssignments
  L. ADD A PERSON TO A ROLE     new IntakeRoleAssignments row (PersonEmail lower case)

  WHEN YOU DO NEED A FLOW CHANGE
    - A new CORE column that the app must send (e.g. a new field on New
      Request outside the question system): add it to the payload in the
      app and to the flow's Create item. Prefer a question instead.
    - Showing a new report column to requestors: add it to the
      REQUESTOR VIEW (recipe B4).

  RULES TO KEEP IT HEALTHY
    - Codes and keys never change once used. Change display text only.
    - Retire with IsActive = No. Do not delete config rows.
    - Promote only answers you filter, sort or chart on (30-60 max).
    - Only flows write the JSON columns. Never edit them by hand.


--------------------------------------------------------------------------
 9. LIMITS AND GOOD PRACTICE
--------------------------------------------------------------------------

  - Speed: each flow call takes about 1-4 seconds. The app loads setup
    once, caches lists, and refreshes on demand.
  - Daily action allowance: every flow action counts toward the service
    account's daily Power Platform request limit (about 6,000 per day
    with a Microsoft 365 licence). Estimate early - see 03-Flow-Recipes.txt
    PART E.
  - The app waits up to about 2 minutes for a flow; flows respond first
    and send emails afterwards.
  - JSON columns hold about 63,000 characters - far more than a form needs.
    They cannot be filtered or indexed; that is why report columns exist.
  - Index the columns marked Indexed = Yes before a list reaches 5,000
    items (the script does this).
  - Licensing: all standard connectors (included with Microsoft 365).
    Power BI sharing needs Pro. Confirm the service-account pattern with
    your licensing team.


--------------------------------------------------------------------------
 10. FAQ
--------------------------------------------------------------------------

  Q: Why no separate list for internal answers any more?
  A: It existed only to hide data from requestors who could read the
     lists. Now nobody can read the lists, and the flows decide which
     columns go back. One row per request is simpler to manage and report.

  Q: Can a requestor see internal data by tampering with the app?
  A: No. The flow works out who is calling from their sign-in, checks
     their role, and only puts internal columns in a TEAM response.

  Q: Where is a type-specific answer stored?
  A: Requestor question: IntakeRequests.AnswersJson. Team question:
     IntakeRequests.InternalJson. Plus its own column if ReportColumn is set.

  Q: What if the Promote flow fails?
  A: Nothing is lost - all answers are in the JSON. Fix the flow and set
     PromotePending = Yes on the affected requests.

  Q: Do managers need SharePoint access for reports?
  A: No. Use the in-app dashboard or a Power BI report that refreshes with
     the service account (05-PowerBI-and-Excel.txt).

  Q: Someone gets a SharePoint consent pop-up when opening the app.
  A: The app still has a SharePoint data source, or a flow is set to use
     the user's own connection. See 03-Flow-Recipes.txt A3 and A4.

==========================================================================
