# S10 – Intake Prioritization Queue (teams with scored questions)

**Wireframe:** `W10-prioritization-queue.png`
**Depends on:** S01, S03 (question renderer), flows F2 and F3

## Goal
For any team that has scored questions (IntakeQuestionRules.IsScored), list Submitted and Queued intakes ranked by Backlog Score, then priority, then needed-by date. A review panel lets the manager adjust scored answers, override the score, set priority and assign with a required comment.

## Formulas
```
// Teams this manager can prioritise
ClearCollect(colMyScoringTeams, Filter(MyManagedTeams, Title in colScoringTeams.Value));
// drpQueueTeam (visible when more than one)
// Columns = the team's scored questions
ClearCollect(colScoredCols, Distinct(Filter(colRules, IsScored, Team = drpQueueTeam.Selected.Title), QuestionKey));
// galPrioritization.Items
SortByColumns(
  Filter(IntakeRequests, RoutedTeam.Value = drpQueueTeam.Selected.Title,
         Status.Value = "Submitted" || Status.Value = "Queued"),
  "BacklogScore", SortOrder.Descending)
// Then-by priority and needed-by: sort the loaded rows in memory, e.g.
// SortByColumns(AddColumns(<above>, PriRank, Switch(Priority.Value, "Critical", 1, "High", 2, "Medium", 3, 4)),
//               "BacklogScore", SortOrder.Descending, "PriRank", SortOrder.Ascending, "NeededBy", SortOrder.Ascending)
// Rank cell: CountRows(galPrioritization.AllItems) ordinal – use a Sequence-indexed collection if you need exact ranks
// Answer cells (one per scored question, in a nested horizontal gallery bound to colScoredCols):
LookUp(IntakeAnswers, RequestItemId = ThisItem.ID && QuestionKey = ThisRecord.Value).AnswerValue
```

## Review panel (`pnlReview`)
- Scored questions for this intake rendered with the S03 question template (pre-filled from IntakeAnswers).
- `txtScore`: shows the calculated sum; the manager may type an override (whole number ≥ 0).
- `drpPriority`, `cmbAssignTo`, `txtComment` (required to assign).
- **Save, keep in queue**: upsert answers → `IntakeAnswersChanged.Run(id, "Requestor", "Prioritization review: …", me, If(locScoreOverridden, Value(txtScore.Text), -1))` (−1 = recalculate from points).
- **Assign & move on**: save as above, then `IntakeChangeStage.Run(id, "Assign", cmbAssignTo.Selected.Mail, txtComment.Text, me)`.

## Acceptance checks
- Only OMP appears for the OMP manager (POC); intakes with no score sit at the bottom.
- Changing Channel Enablement from "Material new build required" to "Existing pattern" raises the score by 2.
- Assigning requires a comment and removes the intake from the queue (status moves to Assigned / Under Review).
- Adding IsScored to a rule for another team makes the queue appear for that team's manager with no app change.

## Prompt to paste
```
Build scrPrioritization (S10) matching wireframe W10 with the formulas in 02-prompts/S10: queue limited to teams with scored
questions, dynamic columns for the team's scored questions, ranking by BacklogScore then priority then needed-by, and the
review panel (scored answers, score override, priority, assign with required comment) calling IntakeAnswersChanged and
IntakeChangeStage. Then run the acceptance checks.
```
