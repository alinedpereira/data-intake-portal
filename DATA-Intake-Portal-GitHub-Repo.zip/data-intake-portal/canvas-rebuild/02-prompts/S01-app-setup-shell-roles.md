# S01 – App set-up, navigation shell and roles

**Wireframes:** `W01-home-requestor.png` (header and left navigation), `W06-intake-detail-manager.png` (manager navigation)
**Original references:** `R05-home-bmo-branding.png`, `R06-bmo-colour-palette.jpg`
**Depends on:** SharePoint provisioned (01-provisioning)

## Goal
A responsive canvas app with the BMO header, a role-filtered left navigation, cached configuration, and role detection, that every later screen reuses.

## Data sources to add
IntakeRequests, IntakeTasks, IntakeWorkPackages, IntakeAnswers, IntakeInternalAnswers, IntakeActivity, IntakeTeams, IntakeTeamMembers, IntakeSubTeams, IntakeRequestTypes, IntakeQuestions, IntakeQuestionRules, IntakeQAConfig, IntakeTransitions, Office365Users. Flows are added as their screens need them.

## Build
1. **Theme** – App.Formulas named colours: `clrBlue = ColorValue("#0075BE")`, `clrNavy = ColorValue("#005789")`, `clrMidnight = ColorValue("#003758")`, `clrIce = ColorValue("#E1F3FE")`, `clrRed = ColorValue("#ED1C24")`, `clrGreen = ColorValue("#16803D")`, `clrHeader = ColorValue("#20262E")`.
2. **Header component** `cmpHeader`: title "D.A.T.A. - Intake Portal", and on the right a role switcher `drpRole` visible only when `varCanSwitchRole` (dev/test, or users with more than one role).
3. **Navigation component** `cmpNav` with gallery `galNav`. Items by role:
   - Requestor: Home, New intake, My Intakes, Help
   - Team Member: Intakes & tasks, Help
   - Manager: Intakes & tasks, Intake details, My Team's Work View, Intake Prioritization Queue (only if one of their teams has scored questions), Intakes Needing Attention, Help
   Selected item: Ice fill + 5 px BMO Blue left bar.
4. **Role detection and cache** (below).
5. One screen per destination (placeholders now): `scrHome`, `scrNewIntake`, `scrMyIntakes`, `scrIntakeDetail`, `scrWorkPackage`, `scrTeamQueue`, `scrTasks`, `scrPrioritization`, `scrDashboard`, `scrAtRisk`, `scrHelp`. Put `cmpHeader` and `cmpNav` on each.

## Formulas
```
// App.Formulas
CurrentUserEmail = Lower(User().Email);
MyManagedTeams = Filter(IntakeTeams, Lower(ManagerEmail) = CurrentUserEmail);
IsManager = !IsEmpty(MyManagedTeams);
MyMemberTeams = Filter(IntakeTeamMembers, Lower(Member.Email) = CurrentUserEmail, IsActive);
IsTeamMember = !IsEmpty(MyMemberTeams);

// App.OnStart
Concurrent(
    ClearCollect(colTypes, SortByColumns(Filter(IntakeRequestTypes, IsActive), "SortOrder")),
    ClearCollect(colTeams, IntakeTeams),
    ClearCollect(colSubTeams, IntakeSubTeams),
    ClearCollect(colQuestions, Filter(IntakeQuestions, IsActive)),
    ClearCollect(colRules, Filter(IntakeQuestionRules, IsActive)),
    ClearCollect(colQAConfig, IntakeQAConfig),
    ClearCollect(colTransitions, Filter(IntakeTransitions, IsActive)));
Set(varRole, If(IsManager, "Manager", IsTeamMember, "Team Member", "Requestor"));
Set(varCanSwitchRole, CountIf([IsManager, IsTeamMember, true], Value) > 1);
// Teams that score (get the prioritization queue)
ClearCollect(colScoringTeams, Distinct(Filter(colRules, IsScored, !IsBlank(Team)), Team));

// galNav.Items
Switch(varRole,
  "Requestor", Table({L:"Home", S:scrHome}, {L:"New intake", S:scrNewIntake}, {L:"My Intakes", S:scrMyIntakes}, {L:"Help", S:scrHelp}),
  "Team Member", Table({L:"Intakes & tasks", S:scrTeamQueue}, {L:"Help", S:scrHelp}),
  Filter(Table({L:"Intakes & tasks", S:scrTeamQueue}, {L:"Intake details", S:scrIntakeDetail},
               {L:"My Team's Work View", S:scrDashboard}, {L:"Intake Prioritization Queue", S:scrPrioritization},
               {L:"Intakes Needing Attention", S:scrAtRisk}, {L:"Help", S:scrHelp}),
         L <> "Intake Prioritization Queue" || !IsEmpty(Filter(MyManagedTeams, Title in colScoringTeams.Value))))
// galNav.OnSelect
Navigate(ThisItem.S, ScreenTransition.None)
```

## Acceptance checks
- A requestor sees Home, New intake, My Intakes, Help only.
- A manager of OMP sees the Intake Prioritization Queue; a manager of a team with no scored rules does not.
- Adding a row to IntakeRequestTypes and restarting the app shows the new type in colTypes (no app change).
- No team name, type name or question appears as a literal in any formula.

## Prompt to paste
```
Read .github/copilot-instructions.md and 00-context/solution-overview.md.
Build S01 for the canvas app "D.A.T.A. - Intake Portal": add the data sources listed in 02-prompts/S01, create the App.Formulas
colours and role formulas, App.OnStart cache, a header component (cmpHeader) and a navigation component (cmpNav with galNav)
matching wireframe W01 (BMO header, 230 px left nav, Ice selected state with a blue left bar). Create the empty screens listed
and place cmpHeader + cmpNav on each. Use the exact formulas in the Formulas section. Then walk me through the acceptance checks.
```
