import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { PriorityText, StatusPill } from "@/components/request-bits";
import { DML_STAGE, DML_TEAM, displayStatus, formatDate, requestNumber, statusOf, useRequestPage, type IntakeRequest } from "@/lib/intake";
import { ownerNames, ownerOf } from "@/lib/people";
import { teamsFilter, useMyManagedTeams } from "@/lib/teams";
import { segmentButtonClass, segmentGroupClass } from "@/lib/segment";
import { daysWaiting, isAwaitingRequestor } from "@/lib/questions";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const SCAN = 500;
const DAY = 86_400_000;
const DUE_SOON_DAYS = 7;
const NO_OWNER_DAYS = 3;

type Reason = "overdue" | "due-soon" | "no-owner" | "dml" | "requestor";
const REASON_LABEL: Record<Reason, string> = {
  overdue: "Past needed-by",
  "due-soon": `Due within ${DUE_SOON_DAYS} days`,
  "no-owner": `No owner ${NO_OWNER_DAYS}+ days`,
  dml: "Awaiting DML approval",
  requestor: "Waiting on requestor",
};
const REASON_TONE: Record<Reason, string> = {
  overdue: "bg-red-700 text-white",
  "due-soon": "bg-amber-100 text-amber-900 dark:bg-amber-900 dark:text-amber-100",
  "no-owner": "bg-accent text-accent-foreground",
  dml: "bg-primary text-primary-foreground",
  requestor: "bg-amber-100 text-amber-900 dark:bg-amber-900 dark:text-amber-100",
};

interface Risk {
  r: IntakeRequest;
  reasons: Reason[];
  /** Days past due (positive) or until due (negative); undefined without a needed-by date. */
  daysLate?: number;
  waitingDays?: number;
}

function assess(r: IntakeRequest, now: number): Risk | null {
  const reasons: Reason[] = [];
  const due = r.NeededBy ? new Date(r.NeededBy).getTime() : NaN;
  let daysLate: number | undefined;
  if (!Number.isNaN(due)) {
    daysLate = Math.floor((now - due) / DAY);
    if (due < now) reasons.push("overdue");
    else if (due - now <= DUE_SOON_DAYS * DAY) reasons.push("due-soon");
  }
  const submitted = new Date(r.SubmittedOn ?? r.Created ?? "").getTime();
  const waitingDays = Number.isNaN(submitted) ? undefined : Math.floor((now - submitted) / DAY);
  const s = statusOf(r);
  if ((s === "Submitted" || s === "Queued") && !ownerOf(r) && waitingDays !== undefined && waitingDays >= NO_OWNER_DAYS) {
    reasons.push("no-owner");
  }
  if (s === DML_STAGE) reasons.push("dml");
  if (isAwaitingRequestor(r)) reasons.push("requestor");
  return reasons.length ? { r, reasons, daysLate, waitingDays } : null;
}

/** Manager list of open intakes that are overdue, due soon, or waiting for an owner. */
export function AtRiskPage() {
  const role = useAppStore((s) => s.role);
  const mine = useMyManagedTeams();
  const ready = role === "Manager" && mine.teams.length > 0;
  const filter = ready ? `${teamsFilter(mine.teams)} and Status ne 'Closed' and Status ne 'Rejected'` : undefined;
  const q = useRequestPage(filter, undefined, SCAN);
  const [show, setShow] = useState<Reason | "all">("all");

  const risks = useMemo(() => {
    const now = Date.now();
    const order = (k: Risk) =>
      k.reasons.includes("overdue") ? 0 : k.reasons.includes("dml") ? 1 : k.reasons.includes("no-owner") ? 2 : 3;
    return (q.data?.rows ?? [])
      .map((r) => assess(r, now))
      .filter((k): k is Risk => !!k)
      .sort((a, b) => order(a) - order(b) || (b.daysLate ?? -9999) - (a.daysLate ?? -9999) || (b.waitingDays ?? 0) - (a.waitingDays ?? 0));
  }, [q.data]);
  const counts = {
    all: risks.length,
    overdue: risks.filter((k) => k.reasons.includes("overdue")).length,
    "due-soon": risks.filter((k) => k.reasons.includes("due-soon")).length,
    "no-owner": risks.filter((k) => k.reasons.includes("no-owner")).length,
    dml: risks.filter((k) => k.reasons.includes("dml")).length,
    requestor: risks.filter((k) => k.reasons.includes("requestor")).length,
  };
  // The DML (DMO manager) gets an "Awaiting DML approval" filter; it also appears for anyone with such intakes.
  const showDml = mine.teams.includes(DML_TEAM) || counts.dml > 0;
  const filters: (Reason | "all")[] = ["all", ...(showDml ? (["dml"] as const) : []), "overdue", "due-soon", "no-owner", "requestor"];
  const shown = show === "all" ? risks : risks.filter((k) => k.reasons.includes(show));

  if (role !== "Manager") return null;
  if (mine.isPending) return <div className="p-5 md:p-8"><LoadingState /></div>;
  if (!ready) {
    return (
      <div className="p-5 md:p-8">
        <EmptyState icon={TriangleAlert} title="Choose a manager at the top to see their team's intakes needing attention" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-5 p-5 md:p-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">{mine.teams.join(", ")} - Intakes Needing Attention</h1>
        <p className="text-sm text-muted-foreground">
          Open intakes past their needed-by date, due within {DUE_SOON_DAYS} days, waiting {NO_OWNER_DAYS}+ days without an owner, waiting on the requestor
          {mine.teams.includes(DML_TEAM) ? ", or awaiting your DML approval" : ""}.
        </p>
      </div>

      {q.isPending ? (
        <LoadingState />
      ) : q.isError ? (
        <ErrorState title="Intakes needing attention could not be loaded" action={<Button onClick={() => void q.refetch()}>Retry</Button>} />
      ) : (
        <>
          <div role="group" aria-label="Show" className={segmentGroupClass}>
            {filters.map((k) => (
              <button key={k} type="button" aria-pressed={show === k} className={segmentButtonClass(show === k)} onClick={() => setShow(k)}>
                {k === "all" ? "All" : REASON_LABEL[k]} ({counts[k]})
              </button>
            ))}
          </div>
          {shown.length === 0 ? (
            <EmptyState icon={TriangleAlert} title="Nothing needs attention" description={show === "dml" ? "No intakes are waiting for DML approval." : "Every open intake is on time and has an owner."} />
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border bg-card">
              <table className="w-full text-sm">
                <caption className="sr-only">Intakes needing attention</caption>
                <thead className="bg-accent text-left text-accent-foreground">
                  <tr>
                    {["Intake #", "Intake title", "Why it needs attention", "Needed by", "Team", "Owner", "Priority", "Status"].map((h) => (
                      <th key={h} scope="col" className="whitespace-nowrap px-3 py-3 font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {shown.map(({ r, reasons, daysLate, waitingDays }) => (
                    <tr key={r.ID} className="hover:bg-muted/60">
                      <td className="whitespace-nowrap px-3 py-3">
                        <Link to={`/work/${r.ID}`} className="font-semibold text-primary underline-offset-2 hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                          {requestNumber(r)}
                        </Link>
                      </td>
                      <td className="min-w-48 px-3 py-3 font-medium">{r.Title}</td>
                      <td className="px-3 py-3">
                        <div className="flex flex-wrap gap-1.5">
                          {reasons.map((k) => (
                            <span key={k} className={cn("inline-flex whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold", REASON_TONE[k])}>
                              {k === "overdue" && daysLate !== undefined
                                ? `${Math.max(daysLate, 1)} day${Math.max(daysLate, 1) === 1 ? "" : "s"} overdue`
                                : k === "due-soon" && daysLate !== undefined
                                  ? -daysLate <= 0 ? "Due today" : `Due in ${-daysLate} day${-daysLate === 1 ? "" : "s"}`
                                  : k === "no-owner"
                                    ? `No owner · ${waitingDays} days`
                                    : k === "requestor"
                                      ? `Waiting on requestor · ${daysWaiting(r) ?? 0} days`
                                      : REASON_LABEL[k]}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-3">{formatDate(r.NeededBy)}</td>
                      <td className="px-3 py-3">{r.RoutedTeam?.Value ?? "—"}</td>
                      <td className="px-3 py-3">{ownerNames(r) ?? <span className="text-muted-foreground">Unassigned</span>}</td>
                      <td className="px-3 py-3"><PriorityText priority={r.Priority?.Value} /></td>
                      <td className="px-3 py-3"><StatusPill status={statusOf(r)} label={displayStatus(r)} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <p className="text-sm italic text-muted-foreground">
            Open an intake to assign, re-route or update it.
            {q.data?.nextToken ? ` Checked the latest ${SCAN} open intakes.` : ""}
          </p>
        </>
      )}
    </div>
  );
}
