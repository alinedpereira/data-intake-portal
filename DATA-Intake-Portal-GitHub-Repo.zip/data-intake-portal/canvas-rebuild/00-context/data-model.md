# Data model quick reference

All lists live on one SharePoint site. Created by `01-provisioning/Provision-IntakeSite.ps1`. Bold = indexed.


## IntakeRequests

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| **RequestNumber** | Text |  |
| OnBehalfOf | Text |  |
| BusinessUnit | Choice | Personal Banking, Business Banking, Customer Lifecycle Management / Data & Analytics, Digital / AI & Transformation, Virtual Connect, Retail Payments, Customer Loyalty, Emerging Business |
| RequestTypeL1 | Choice | Reporting / Dashboard / Analytics, Campaign, App / Automation, Offer / Incentive, Data Quality, Data Science / Modeling, Data Risk Assessment, Other / Not Sure (fill-in allowed; values come from config lists) |
| RequestTypeL2 | Text |  |
| **RoutedTeam** | Choice | Product Analytics, Campaign Strategy, Application and Automation Development, OMP, P&BB DMO, AI / Model Team, Intake Triage, Customer Analytics, Digital Analytics, Distribution and BB Analytics, Channel Analytics & Reporting, Virtual Connect Business Analytics, Gen AI & Model Governance (fill-in allowed; values come from config lists) |
| RequestComments | Note |  |
| RequestDescription | Note |  |
| NeededBy | DateTime |  |
| Priority | Choice | Low, Medium, High, Critical |
| BusinessValue | Note |  |
| **Status** | Choice | Submitted, Queued, Assigned / Under Review, Requirements sign-off, Approved, In Progress, DML Approval, QA Testing, Acceptance sign-off, Closed, Rejected |
| RequirementsSignedOff | Boolean |  |
| AcceptanceSignedOff | Boolean |  |
| SubmittedOn | DateTime |  |
| Requestorsemail | Text |  |
| Reference | Text |  |
| **Requestor** | User |  |
| **Owner** | User |  |
| RequestStatus | Choice | Submitted, Queued, Assigned/Under Review, Approved, In progress, DML Approval, QA Testing, On Hold, Delivered/Pending Business Approval, Closed, Cancelled |
| BacklogScore | Number |  |
| AnalyticsDomain | Choice | Customer & Segment Data, Product & Pricing Data, Web & App Data, Channel & Sales Data, Virtual Connect Data, Distribution & Business Banking Data (fill-in allowed; values come from config lists) |
| QuestionAskedBy | Text |  |
| AnsweredOn | DateTime |  |
| OpenQuestion | Note |  |
| QuestionAskedOn | DateTime |  |
| RequestorAnswer | Note |  |
| AwaitingRequestor | Boolean |  |

## IntakeTasks

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| **RequestItemId** | Number |  |
| RequestNumber | Text |  |
| RequestTitle | Text |  |
| DueDate | DateTime |  |
| TaskStatus | Choice | Not started, In progress, Blocked, Done |
| TaskNotes | Note |  |
| CreatedByName | Text |  |
| **AssignedTo** | User |  |
| TaskType | Choice | Requirement Analysis, Design, Development, QA/Testing, Deployment, Other |
| **WorkPackageId** | Number |  |

## IntakeWorkPackages

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| WPOwner | User |  |
| WPDueDate | DateTime |  |
| **RequestItemId** | Number |  |
| WPStatus | Choice | Not started, Requirements, In progress, QA/Review, Ready for acceptance, Accepted, Sent back |
| SortOrder | Number |  |
| WPDescription | Note |  |
| SubTeam | Text |  |
| RequestNumber | Text |  |
| WPPriority | Choice | Low, Medium, High, Critical |

## IntakeTeams

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| ManagerName | Text |  |
| ManagerEmail | Text |  |
| FocusArea | Text |  |

## IntakeSubTeams

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| LeadName | Text |  |
| ParentTeam | Text |  |
| LeadEmail | Text |  |

## IntakeRequestTypes

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| Level1 | Text |  |
| DefaultTeam | Text |  |
| AskFocusArea | Boolean |  |
| SortOrder | Number |  |
| IsActive | Boolean |  |

## IntakeQuestions

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| QuestionKey | Text |  |
| QuestionType | Choice | Text, Long text, Number, Date, Choice, Yes/No |
| Choices | Note |  |
| HelpText | Text |  |
| OwnerTeam | Text |  |
| IsActive | Boolean |  |

## IntakeQuestionRules

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| QuestionKey | Text |  |
| Team | Text |  |
| RequestTypeL1 | Text |  |
| RequestTypeL2 | Text |  |
| Audience | Choice | Requestor, Internal |
| IsRequired | Boolean |  |
| IsScored | Boolean |  |
| SortOrder | Number |  |
| ShowIfKey | Text |  |
| ShowIfValue | Text |  |
| IsActive | Boolean |  |

## IntakeQAConfig

| Column | Type | Notes |
|---|---|---|
| Title | Text |  |
| Level1 | Text |  |
| Level2 | Text |  |
| RequiresQA | Boolean |  |

## IntakeTeamMembers (new in the rebuild)

| Column | Type | Notes |
|---|---|---|
| Team | Text | Matches IntakeTeams.Title |
| Member | User |  |
| IsActive | Boolean |  |

## IntakeTransitions (new in the rebuild)

| Column | Type | Notes |
|---|---|---|
| FromStage | Text |  |
| ToStage | Text |  |
| AllowedRole | Choice | Requestor, Owner, Manager, DML, System |
| ReasonRequired | Boolean |  |
| Lifecycle | Choice | Standard, IAAP, Any |
| RequestStatus | Text | Value F2 writes to IntakeRequests.RequestStatus |
| IsActive | Boolean |  |

## IntakeAnswers (new in the rebuild)

| Column | Type | Notes |
|---|---|---|
| **RequestItemId** | Number | IntakeRequests.ID |
| **QuestionKey** | Text |  |
| Title | Text | Question label at answer time |
| AnswerValue | Note | Text; Yes/No stored as Yes/No; dates as yyyy-mm-dd |
| Points | Number | From the chosen Choice line |
| AnsweredBy | Text |  |

## IntakeInternalAnswers (new in the rebuild)

| Column | Type | Notes |
|---|---|---|
| (same columns as IntakeAnswers) |  | Restricted to team members and managers |

## IntakeActivity (new in the rebuild)

| Column | Type | Notes |
|---|---|---|
| **RequestItemId** | Number |  |
| **WorkPackageId** | Number | 0 or blank = intake-level |
| TaskId | Number |  |
| EntryText | Note |  |
| ActorName | Text |  |
| ActorRole | Text | Requestor, Team Member, Manager, DML, System |
| IsInternal | Boolean | Hidden from requestors |
| Created | DateTime | Built-in; the timestamp |

## Documents library
Folder per RequestNumber (created by F1); sub-folder `WP-{id}` per work package (created by F4).
