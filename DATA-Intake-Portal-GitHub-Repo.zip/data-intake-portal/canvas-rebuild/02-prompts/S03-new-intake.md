# S03 – New Intake (3 pages + dynamic team questions)

**Wireframes:** `W02-new-intake-p1-routing.png`, `W03-new-intake-p3-team-questions.png`
**Original references:** `R03-new-intake-page1-design.png`, `R02-new-intake-page2-design.png`
**Depends on:** S01; flows C1 and F1 (`IntakeProcessSubmission`)

## Goal
A three-page form (Routing, Intake, Priorities) whose options, routing and team questions all come from configuration lists. On submit it writes the intake and the answers, then calls F1 for the number, score, folder and notifications.

## Page 1 – Routing (W02)
| Control | Type | Key properties |
|---|---|---|
| galSteps | Horizontal gallery | 1 Routing / 2 Intake / 3 Priorities; current = `varStep` (0,1,2) |
| txtRequestor | Text (read-only for requestors) / cmbRequestor (people picker for managers submitting on behalf) | Default `User().FullName` |
| drpBusinessUnit | Dropdown | `Choices(IntakeRequests.BusinessUnit)` |
| txtOnBehalfOf | Text input | optional |
| drpLevel1 | Dropdown | `SortByColumns(Distinct(colTypes, Level1), "Value")` |
| drpLevel2 | Dropdown | `Filter(colTypes, Level1 = drpLevel1.Selected.Value)`, DisplayFields `["Title"]` |
| drpFocus | Dropdown | Visible `drpLevel2.Selected.AskFocusArea`; Items `Filter(colTeams, !IsBlank(FocusArea))`, DisplayFields `["FocusArea"]` |
| drpTeam | Dropdown | Items `colTeams` (Title); Default = suggested team (below) |
| lblTeamHint | Label | "Changed from the suggested team (X)" / "No team is mapped to this combination…" |
| txtComments | Text input | optional |
| btnNext | Button | validates the page, `Set(varStep, varStep + 1)` |

## Page 2 – Intake
`txtTitle` (required, 255 max), `txtDescription` (multiline, required, hint "Goal, background, scope, and definition of done.").

## Page 3 – Priorities + team questions (W03)
`dteNeeded` (required), `drpPriority` (`Choices(IntakeRequests.Priority)`, required), `txtValue` (multiline), then section **"Questions from {team}"** with `galQuestions`, then `btnPrevious` and `btnSubmit`.

## Formulas
```
// Suggested team – drpTeam.Default (re-evaluates when type/focus changes)
With({t: drpLevel2.Selected},
    If(t.AskFocusArea,
        LookUp(colTeams, FocusArea = drpFocus.Selected.FocusArea).Title,
        t.DefaultTeam))

// Build the applicable requestor questions whenever team or type changes
// (call from drpTeam.OnChange, drpLevel2.OnChange and screen OnVisible)
Set(varTeam, drpTeam.Selected.Title);
ClearCollect(colApplied,
    AddColumns(
        Filter(colRules, Audience.Value = "Requestor",
            IsBlank(Team) || Team = varTeam,
            IsBlank(RequestTypeL1) || RequestTypeL1 = drpLevel1.Selected.Value,
            IsBlank(RequestTypeL2) || RequestTypeL2 = drpLevel2.Selected.Title),
        Specificity, If(IsBlank(Team), 0, 1) + If(IsBlank(RequestTypeL1), 0, 1) + If(IsBlank(RequestTypeL2), 0, 2),
        Q, LookUp(colQuestions, QuestionKey = ThisRecord.QuestionKey)));
ClearCollect(colForm,
    Filter(
        ForAll(Distinct(colApplied, QuestionKey) As k,
            First(SortByColumns(Filter(colApplied, QuestionKey = k.Value), "Specificity", SortOrder.Descending))),
        !IsBlank(Q.QuestionKey)));
// Drop answers to questions that no longer apply
RemoveIf(colAnswers, !(Key in colForm.QuestionKey));

// galQuestions.Items
SortByColumns(colForm, "SortOrder")
// Row (template container) Visible – show-if
IsBlank(ThisItem.ShowIfKey) || LookUp(colAnswers, Key = ThisItem.ShowIfKey).Value = ThisItem.ShowIfValue
// lblQ.Text
ThisItem.Q.Title & If(ThisItem.IsRequired, " *", "")
// lblHelp.Text
ThisItem.Q.HelpText

// One control per type; only the matching one is visible
// txtAnswer.Visible
ThisItem.Q.QuestionType.Value in ["Text", "Long text", "Number"]
// txtAnswer.Mode
If(ThisItem.Q.QuestionType.Value = "Long text", TextMode.MultiLine, TextMode.SingleLine)
// txtAnswer.Format
If(ThisItem.Q.QuestionType.Value = "Number", TextFormat.Number, TextFormat.Text)
// drpAnswer.Visible
ThisItem.Q.QuestionType.Value in ["Choice", "Yes/No"]
// drpAnswer.Items  (choices are one per line; "Label|points" carries points)
If(ThisItem.Q.QuestionType.Value = "Yes/No",
    Table({Label: "Yes", Points: Blank()}, {Label: "No", Points: Blank()}),
    ForAll(Split(ThisItem.Q.Choices, Char(10)) As c,
        {Label: Trim(First(Split(c.Value, "|")).Value),
         Points: If(CountRows(Split(c.Value, "|")) > 1, Value(Last(Split(c.Value, "|")).Value))}))
// dteAnswer.Visible
ThisItem.Q.QuestionType.Value = "Date"

// Capture answers – OnChange of each answer control (example for drpAnswer)
RemoveIf(colAnswers, Key = ThisItem.QuestionKey);
Collect(colAnswers, {Key: ThisItem.QuestionKey, Label: ThisItem.Q.Title,
                     Value: Self.Selected.Label, Points: Self.Selected.Points});
// txtAnswer.OnChange: same with Value: Self.Text, Points: Blank()
// dteAnswer.OnChange: same with Value: Text(Self.SelectedDate, "yyyy-mm-dd"), Points: Blank()

// Required check (ignore questions hidden by show-if)
Set(varMissing, Filter(colForm, IsRequired,
    IsBlank(ShowIfKey) || LookUp(colAnswers, Key = ShowIfKey).Value = ShowIfValue,
    IsBlank(LookUp(colAnswers, Key = QuestionKey).Value)));

// Score preview label (optional, managers only)
Sum(Filter(colAnswers, Key in Filter(colForm, IsScored).QuestionKey), Points)

// btnSubmit.OnSelect
If(!IsEmpty(varMissing),
    Notify("Answer the required " & varTeam & " questions.", NotificationType.Error),
    Set(varNew, Patch(IntakeRequests, Defaults(IntakeRequests), {
        Title: txtTitle.Text,
        Requestor: {Claims: "i:0#.f|membership|" & CurrentUserEmail, DisplayName: User().FullName,
                    Email: CurrentUserEmail, Department: "", JobTitle: "", Picture: ""},
        Requestorsemail: CurrentUserEmail,
        BusinessUnit: drpBusinessUnit.Selected,
        OnBehalfOf: txtOnBehalfOf.Text,
        RequestTypeL1: {Value: drpLevel1.Selected.Value},
        RequestTypeL2: drpLevel2.Selected.Title,
        AnalyticsDomain: If(drpLevel2.Selected.AskFocusArea, {Value: drpFocus.Selected.FocusArea}),
        RoutedTeam: If(!IsBlank(drpTeam.Selected.Title), {Value: drpTeam.Selected.Title}),
        RequestComments: txtComments.Text,
        RequestDescription: txtDescription.Text,
        NeededBy: dteNeeded.SelectedDate,
        Priority: drpPriority.Selected,
        BusinessValue: txtValue.Text,
        SubmittedOn: Now()}));
    ForAll(Filter(colAnswers, !IsBlank(Value), Key in colForm.QuestionKey) As a,
        Patch(IntakeAnswers, Defaults(IntakeAnswers), {
            Title: a.Label, RequestItemId: varNew.ID, QuestionKey: a.Key,
            AnswerValue: a.Value, Points: a.Points, AnsweredBy: User().FullName}));
    Set(varResult, IntakeProcessSubmission.Run(varNew.ID));
    Clear(colAnswers);
    Navigate(scrSubmitted))
```
Status is **not** set by the app: F1 sets Status = Submitted, RequestNumber, RequestStatus, BacklogScore, folder and QA task.

## Behaviour
- Changing Level 1 clears Level 2 if it no longer belongs; changing Level 2 or focus area re-suggests the team.
- The focus-area dropdown is required only when visible.
- The questions section is hidden when `IsEmpty(colForm)`.
- `scrSubmitted` shows the number from `varResult.requestnumber` and a "View intake and add files" button.

## Acceptance checks
- Offer / Incentive + Campaign / Offer routes to OMP and shows 4 OMP questions; choosing "Yes" for the existing-offer question reveals "Existing offer code".
- Reporting / Dashboard / Analytics + Data Analysis / Extract asks for the focus area; "Customer & Segment Data" suggests Customer Analytics, which has no upfront questions (section hidden).
- Data Quality / Data Quality / Rule Change routes to P&BB DMO and requires "Accountable data owner" and "Contains PII".
- Submitting without a required answer is blocked with a message; after submit the intake has a request number, answers in IntakeAnswers, and (for OMP) a Backlog Score of the summed points.
- Adding a new rule row in IntakeQuestionRules makes the question appear without editing the app.

## Prompt to paste
```
Using .github/copilot-instructions.md and 00-context/solution-overview.md, build scrNewIntake (S03) as a three-page form
controlled by varStep, matching wireframes W02 (page 1 routing) and W03 (page 3 with "Questions from {team}") and the
original references R03/R02. All options come from collections colTypes and colTeams; no literal team or type names.
Implement the dynamic question gallery galQuestions exactly as in 02-prompts/S03 (rule matching with specificity, show-if,
one control per question type, answers in colAnswers, required check varMissing). btnSubmit patches IntakeRequests and
IntakeAnswers and then calls IntakeProcessSubmission.Run(varNew.ID). Create scrSubmitted. Then walk through every acceptance check.
```
