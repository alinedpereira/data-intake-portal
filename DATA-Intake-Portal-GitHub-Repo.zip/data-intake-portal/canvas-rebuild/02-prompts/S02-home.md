# S02 – Home (requestor)

**Wireframe:** `W01-home-requestor.png`  **Original reference:** `R05-home-bmo-branding.png`
**Depends on:** S01

## Goal
A welcome page for requestors: a four-step "how it works" strip, three action cards, and their five most recent intakes.

## Controls
| Control | Type | Key properties |
|---|---|---|
| lblWelcome | Label | "Welcome to the D.A.T.A. Intake Portal" (30 pt bold); sub-line "Submit an intake, track where it stands, and get help, all in one place." |
| galHowItWorks | Horizontal gallery (4 items) | Red numbered circles: Submit / Routed / In progress / Sign off, each with a one-line caption |
| btnNewIntake, btnMyIntakes, btnHelp | Buttons inside three cards | Red fill for the first two, outline for Help; Navigate to scrNewIntake / scrMyIntakes / scrHelp |
| lblOpenCount | Label in the My Intakes card | `CountRows(Filter(IntakeRequests, Requestor.Email = User().Email, Status.Value <> "Closed")) & " open · status and priority"` |
| galRecentIntakes | Vertical gallery | Items below; each row: RequestNumber (bold blue), Title, status pill |

## Formulas
```
// galRecentIntakes.Items
FirstN(SortByColumns(Filter(IntakeRequests, Requestor.Email = User().Email), "Created", SortOrder.Descending), 5)
// galRecentIntakes.OnSelect
Set(varIntake, ThisItem); Navigate(scrIntakeDetail)
// Status pill Fill (reuse everywhere as a named formula StatusFill(status))
Switch(ThisItem.Status.Value,
  "Closed", ColorValue("#DCF5E4"),
  "Requirements sign-off", ColorValue("#FFF3D6"), "Acceptance sign-off", ColorValue("#FFF3D6"),
  "Assigned / Under Review", ColorValue("#FFF3D6"),
  clrIce)
```
Note: person-column equality on `.Email` is delegable for SharePoint. If CountRows shows a delegation warning on large lists, move the count to a flow or accept the 2,000-row limit for the count only.

## Acceptance checks
- Requestor sees only their own intakes; newest first; clicking opens the intake.
- Buttons go to the right screens; layout matches W01 at 1366 px and on a tablet.

## Prompt to paste
```
Using .github/copilot-instructions.md, build scrHome (S02) to match wireframe W01 and the BMO home reference R05:
welcome heading, four-step "how it works" strip with red numbered circles, three cards (Start a new intake, View my intakes, Get help)
with btnNewIntake/btnMyIntakes (red) and btnHelp (outline), and galRecentIntakes showing the user's five newest intakes with status pills.
Use the formulas in 02-prompts/S02. Then run the acceptance checks.
```
