# S12 – Help

**Depends on:** S01

## Goal
A static help screen per role: how intake works (the four steps), what each stage means (from StandardStages and the solution overview), who to contact (team managers from colTeams), and FAQs (how to answer a team question, how sign-off works, how work packages are accepted).

## Build
- `galStageHelp`: one row per stage with a one-sentence explanation.
- `galContacts`: `SortByColumns(colTeams, "Title")` with ManagerName and a mailto link `Launch("mailto:" & ThisItem.ManagerEmail)`.
- Role-specific FAQ sections using `Visible: varRole = "…"`.

## Prompt to paste
```
Build scrHelp (S12): the four-step "how intake works" strip, a stage glossary (galStageHelp), a contact list of team managers
from colTeams with mailto links, and short role-specific FAQs for Requestor, Team Member and Manager. Match the BMO style
in .github/copilot-instructions.md.
```
