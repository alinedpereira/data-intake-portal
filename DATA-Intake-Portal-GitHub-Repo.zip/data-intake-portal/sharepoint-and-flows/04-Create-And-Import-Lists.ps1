<#
  D.A.T.A. Intake Portal (VERSION 4: 6 lists, read in the app, save through flows)
  Creates the 6 lists, imports the CSV data and sets permissions.

  WHAT IT DOES
    1. Creates every list and column in 01-Column-Definitions.csv
       (types, required, indexes, unique keys, defaults, choices) and turns
       on attachments for IntakeRequests and IntakeTasks.
    2. Imports the setup lists (teams, request types, attributes).
    3. Optionally imports the sample working data and re-links tasks and
       activity to the real request IDs.
    4. If you pass -ReadersLogin and -ServiceAccount: each list stops
       inheriting site permissions and gets
          site Owners group ... Full Control
          your users group .... Read          (the app reads as the user)
          service account ..... Contribute    (the flows save as this account)
    5. If you pass -HideLists: hides the lists from Site contents and
       keeps them out of search.

  BEFORE YOU RUN
    - PowerShell 7.2+:        winget install Microsoft.PowerShell
    - PnP PowerShell:         Install-Module PnP.PowerShell -Scope CurrentUser
    - A PnP Client ID (ask IT), or:
        Register-PnPEntraIDAppForInteractiveLogin -ApplicationName "PnP Intake" -Tenant yourtenant.onmicrosoft.com
    - You must be a Site Owner.

  RUN (first time, with sample data)
    ./04-Create-And-Import-Lists.ps1 -SiteUrl https://yourtenant.sharepoint.com/sites/DATA-Intake -ClientId <guid> -EmailDomain yourcompany.com

  RUN (production: no sample data, set permissions, hide lists)
    ./04-Create-And-Import-Lists.ps1 -SiteUrl <url> -ClientId <guid> -EmailDomain yourcompany.com -SkipSampleData `
        -ReadersLogin "intake-users@yourcompany.com" -ServiceAccount "svc-intake@yourcompany.com" -HideLists

    -ReadersLogin: the email of a security group or Microsoft 365 group of
      app users. For everyone in the company use the login
      "c:0-.f|rolemanager|spo-grid-all-users/<your-tenant-id>"
      (tenant id: Entra admin center > Overview).

  SAFE TO RE-RUN: existing lists and columns are skipped. Data rows are added
  again on each run, so add -SkipSampleData -SkipConfigData when re-running
  only for permissions.
#>
param(
  [Parameter(Mandatory=$true)][string]$SiteUrl,
  [Parameter(Mandatory=$true)][string]$ClientId,
  # Your email domain, e.g. contoso.com. Replaces {EmailDomain} in the CSV files.
  [string]$EmailDomain,
  [switch]$SkipSampleData,
  [switch]$SkipConfigData,
  [string]$ReadersLogin,
  [string]$ServiceAccount,
  [switch]$HideLists
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((-not $SkipSampleData -or -not $SkipConfigData) -and [string]::IsNullOrWhiteSpace($EmailDomain)) {
  throw "Pass -EmailDomain (for example -EmailDomain contoso.com) so the sample emails become real accounts in your tenant."
}
$EmailDomain = $EmailDomain.Trim().TrimStart("@")
Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Interactive

$defs = Import-Csv (Join-Path $here "01-Column-Definitions.csv")
$libraries = @()
$withAttachments = @("IntakeRequests","IntakeTasks")
function X([string]$s){ [System.Security.SecurityElement]::Escape($s) }

# ---------- 1. LISTS AND COLUMNS ----------
foreach ($listName in ($defs.List | Select-Object -Unique)) {
  $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
  if (-not $list) {
    $template = if ($libraries -contains $listName) { "DocumentLibrary" } else { "GenericList" }
    Write-Host "Creating $listName ($template)" -ForegroundColor Cyan
    $list = New-PnPList -Title $listName -Template $template -OnQuickLaunch
    Set-PnPList -Identity $listName -EnableVersioning $true | Out-Null
    if ($withAttachments -contains $listName) { Set-PnPList -Identity $listName -EnableAttachments $true | Out-Null }
  } else { Write-Host "$listName already exists - adding missing columns only" -ForegroundColor Yellow }

  $existing = (Get-PnPField -List $listName).InternalName
  foreach ($d in ($defs | Where-Object List -eq $listName)) {
    if ($d.Column -eq "Title") {
      if ($d.Required -ne "Yes") { Set-PnPField -List $listName -Identity Title -Values @{Required=$false} | Out-Null }
      continue
    }
    if ($existing -contains $d.Column) { continue }
    $req = if ($d.Required -eq "Yes") { "TRUE" } else { "FALSE" }
    $name = X $d.Column
    $common = "DisplayName='$name' Name='$name' StaticName='$name' Required='$req'"
    switch ($d.Type) {
      "Single line of text"    { $xml = "<Field Type='Text' $common MaxLength='255' />" }
      "Multiple lines of text" { $xml = "<Field Type='Note' $common NumLines='6' RichText='FALSE' AppendOnly='FALSE' UnlimitedLengthInDocumentLibrary='TRUE' />" }
      "Number"                 { $xml = "<Field Type='Number' $common Decimals='0' />"; if ($d.Column -match "Score|Days|Weight") { $xml = "<Field Type='Number' $common />" } }
      "Date and time"          { $xml = "<Field Type='DateTime' $common Format='DateTime' />" }
      "Date only"              { $xml = "<Field Type='DateTime' $common Format='DateOnly' />" }
      "Yes/No"                 { $xml = "<Field Type='Boolean' $common />" }
      "Hyperlink"              { $xml = "<Field Type='URL' $common Format='Hyperlink' />" }
      "Choice" {
        $choices = ($d.Choices -split ";" | ForEach-Object { "<CHOICE>$(X $_.Trim())</CHOICE>" }) -join ""
        $xml = "<Field Type='Choice' $common Format='Dropdown' FillInChoice='FALSE'><CHOICES>$choices</CHOICES></Field>"
      }
      default { throw "Unknown type '$($d.Type)' for $listName.$($d.Column)" }
    }
    if ($d.Default) {
      $dv = switch ($d.Default) { "Yes" {"1"} "No" {"0"} default { X $d.Default } }
      $xml = $xml -replace "\s*/>$", "><Default>$dv</Default></Field>"
      $xml = $xml -replace "</CHOICES></Field>$", "</CHOICES><Default>$dv</Default></Field>"
    }
    Add-PnPFieldFromXml -List $listName -FieldXml $xml | Out-Null
    if ($d.Indexed -eq "Yes") {
      $vals = @{ Indexed = $true }
      if ($d.Unique -eq "Yes") { $vals.EnforceUniqueValues = $true }
      Set-PnPField -List $listName -Identity $d.Column -Values $vals | Out-Null
    }
    Write-Host "   + $($d.Column) ($($d.Type))"
  }
  # Default view: show every column except the technical JSON copies
  $view = Get-PnPView -List $listName | Where-Object DefaultView | Select-Object -First 1
  $first = if ($libraries -contains $listName) { @("DocIcon","LinkFilename") } else { @("LinkTitle") }
  $cols = $first + @(($defs | Where-Object { $_.List -eq $listName -and $_.Column -ne "Title" -and $_.Column -notin @("AnswersJson","InternalJson","PromotePending","RowVersion","ApprovalComments") }).Column)
  Set-PnPView -List $listName -Identity $view.Id -Fields $cols | Out-Null
}

# ---------- 2. DATA IMPORT ----------
$typeOf = @{}
foreach ($d in $defs) { $typeOf["$($d.List)|$($d.Column)"] = $d.Type }

function Convert-Value($list, $col, $raw) {
  if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
  switch ($typeOf["$list|$col"]) {
    "Yes/No"        { return ($raw -in @("Yes","TRUE","True","1")) }
    "Number"        { return [double]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture) }
    "Date only"     { return [datetime]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture) }
    "Date and time" { return [datetime]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() }
    default         { return $raw }
  }
}
function Import-ListCsv($listName, $path, [hashtable]$idMap) {
  if (-not (Test-Path $path)) { return }
  $rows = Import-Csv $path -Encoding UTF8
  Write-Host "Importing $($rows.Count) rows into $listName" -ForegroundColor Cyan
  $created = @{}
  foreach ($r in $rows) {
    $vals = @{}
    foreach ($p in $r.PSObject.Properties) {
      $raw = if ($p.Value) { ([string]$p.Value).Replace("{EmailDomain}", $EmailDomain) } else { $p.Value }
      $v = Convert-Value $listName $p.Name $raw
      if ($null -ne $v) { $vals[$p.Name] = $v }
    }
    if ($idMap -and $r.RequestNumber -and $idMap.ContainsKey($r.RequestNumber)) {
      $vals["RequestID"] = $idMap[$r.RequestNumber]          # re-link to the real ID
    }
    $item = Add-PnPListItem -List $listName -Values $vals
    if ($listName -eq "IntakeRequests") { $created[$r.RequestNumber] = $item.Id }
  }
  return $created
}

if (-not $SkipConfigData) {
  foreach ($n in "IntakeTeams","IntakeRequestTypes","IntakeAttributes") {
    Import-ListCsv $n (Join-Path $here "1-Setup-Lists/$n.csv") $null | Out-Null
  }
}
if (-not $SkipSampleData) {
  $map = Import-ListCsv "IntakeRequests" (Join-Path $here "2-Working-Lists/IntakeRequests.csv") $null
  foreach ($n in "IntakeTasks","IntakeActivity") {
    Import-ListCsv $n (Join-Path $here "2-Working-Lists/$n.csv") $map | Out-Null
  }
}
# ---------- 3. PERMISSIONS (optional) ----------
if ($ReadersLogin -and $ServiceAccount) {
  $owners = Get-PnPGroup -AssociatedOwnerGroup
  foreach ($listName in ($defs.List | Select-Object -Unique)) {
    Write-Host "Permissions on $listName : Owners Full Control, users Read, service account Contribute" -ForegroundColor Cyan
    # Break inheritance WITHOUT copying, so site Members/Visitors get nothing here
    Set-PnPList -Identity $listName -BreakRoleInheritance -ClearSubscopes | Out-Null
    Set-PnPListPermission -Identity $listName -Group $owners -AddRole "Full Control" | Out-Null
    Set-PnPListPermission -Identity $listName -User $ReadersLogin -AddRole "Read" | Out-Null
    Set-PnPListPermission -Identity $listName -User $ServiceAccount -AddRole "Contribute" | Out-Null
  }
} elseif ($ReadersLogin -or $ServiceAccount) {
  Write-Host "Pass BOTH -ReadersLogin and -ServiceAccount to set permissions. Skipped." -ForegroundColor Yellow
}

# ---------- 4. HIDE (optional) ----------
if ($HideLists) {
  foreach ($listName in ($defs.List | Select-Object -Unique)) {
    Set-PnPList -Identity $listName -Hidden $true -NoCrawl | Out-Null
    Write-Host "Hidden from Site contents and search: $listName"
  }
}
Write-Host "Done. Check the lists (README step 3 checklist)." -ForegroundColor Green
