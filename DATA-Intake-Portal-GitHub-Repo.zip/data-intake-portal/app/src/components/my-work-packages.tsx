import { Link } from "react-router-dom";
import { Boxes } from "lucide-react";
import { formatDate } from "@/lib/intake";
import { useAppStore } from "@/lib/store";
import { useMyWorkPackages, wpStatusOf, type WpSummary } from "@/lib/workpackages";
import { WpStatusPill } from "@/components/work-packages";

/** Team member: work packages they own, across intakes. Hidden when they own none. */
export function MyWorkPackages() {
  const me = useAppStore((s) => s.me);
  const q = useMyWorkPackages(me?.Email);
  const rows = (q.data ?? []).filter((w) => wpStatusOf(w) !== "Accepted");
  if (!me?.Email || q.isPending || q.isError || rows.length === 0) return null;
  return (
    <section aria-labelledby="my-wp-h" className="overflow-hidden rounded-lg border border-border bg-card">
      <h2 id="my-wp-h" className="flex items-center gap-2 border-l-4 border-primary bg-accent px-4 py-2.5 font-semibold text-accent-foreground">
        <Boxes className="size-5" aria-hidden="true" /> My work packages
      </h2>
      <ul className="divide-y divide-border">
        {rows.map((w) => (
          <li key={w.ID} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-sm">
            <span className="min-w-0">
              <Link to={`/workpackages/${w.ID}`} className="font-semibold text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring">
                {w.Title}
              </Link>
              <span className="block text-xs text-muted-foreground">
                {w.RequestNumber} · {w.SubTeam ?? "No sub-team"}
                {w.WPDueDate ? ` · due ${formatDate(w.WPDueDate)}` : ""}
              </span>
            </span>
            <WpStatusPill status={wpStatusOf(w)} />
          </li>
        ))}
      </ul>
    </section>
  );
}

/** Small line under an intake's status: "Work packages 1 of 3 accepted". */
export function WpSummaryLine({ s }: { s?: WpSummary }) {
  if (!s || s.total === 0) return null;
  return (
    <span className="mt-1 block text-xs font-medium text-muted-foreground">
      Work packages {s.accepted} of {s.total} accepted{s.ready ? ` · ${s.ready} ready` : ""}
    </span>
  );
}
