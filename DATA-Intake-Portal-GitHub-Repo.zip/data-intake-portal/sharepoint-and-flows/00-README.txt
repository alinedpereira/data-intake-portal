==========================================================================
  D.A.T.A. INTAKE PORTAL - SHAREPOINT LISTS
  VERSION 4: 6 LISTS. READ IN THE APP, SAVE THROUGH FLOWS.
  For: Power Apps canvas app + SharePoint lists + Power Automate
==========================================================================

  Read this first (about 10 minutes).
  Steps marked [DO] are things you do.


--------------------------------------------------------------------------
 1. THE IDEA IN 4 LINES
--------------------------------------------------------------------------

  - Only 6 lists to maintain (3 setup + 3 working). No document library.
  - Users have READ access. The app reads the lists as the user.
  - Every SAVE goes through a flow running as a service account,
    so nobody can edit a list directly in SharePoint.
  - New attributes (questions) are added as rows. No app or flow change.


--------------------------------------------------------------------------
 2. THE 6 LISTS
--------------------------------------------------------------------------

  SETUP LISTS (admins maintain)
  ----------------------------------------------------------------------
  IntakeTeams         One row per team, with its people:
                        ManagerEmails, MemberEmails, CanReassignEmails
                        (emails separated by ;)
                      Two special rows:
                        DMO-APPROVERS  people who decide DML / Fast Track
                        ADMIN          app admins (see everything)
                      Everyone else is a Requestor automatically.

  IntakeRequestTypes  The Level 1 > Level 2 menu, default team, approval
                      path (Standard / DML Approval / Fast Track), QA and
                      sign-off flags.

  IntakeAttributes    Every piece of information you ask for.
                        AppliesToTeams  CA;OMP           blank = all teams
                        AppliesToTypes  RPT-NEW;RPT-CHG  blank = all types
                        AskedOf         Requestor or Team
                      Shown when BOTH match. Also: type, choices, help,
                      section, order, required, show-if, scoring,
                      ReportColumn.

  WORKING LISTS (the flows write, everyone reads)
  ----------------------------------------------------------------------
  IntakeRequests      ONE row per request:
                        core fields (title, type, team, stage, people)
                        all requestor answers  (AnswersJson + AnswersSummary)
                        all team answers       (InternalJson + InternalSummary)
                        report columns         (filled from answers)
                        the CURRENT approval   (type, approver, status, dates)
                        requestor files        (list attachments)

  IntakeTasks         One row per task. Evidence files are attachments
                      on the task.

  IntakeActivity      The timeline and audit trail: submitted, assigned,
                      stage changes, questions and answers, files, and
                      every approval requested and decided.


--------------------------------------------------------------------------
 3. [DO] SET UP - IN THIS ORDER
--------------------------------------------------------------------------

  STEP 1  Service account (ask IT)
     e.g. svc-intake@yourcompany.com with a mailbox and Power Automate
     (a Microsoft 365 licence).

  STEP 2  Users group
     Pick a group that holds all app users: an existing security group,
     or everyone in the company. No per-person setup.

  STEP 3  Create the lists - ONE option

     OPTION A - SCRIPT (recommended, about 10 minutes)
       1. Install PowerShell 7:   winget install Microsoft.PowerShell
       2. In PowerShell 7:        Install-Module PnP.PowerShell -Scope CurrentUser
       3. Get a PnP Client ID from IT, or (if allowed):
            Register-PnPEntraIDAppForInteractiveLogin -ApplicationName "PnP Intake" -Tenant yourtenant.onmicrosoft.com
       4. Unzip this pack, then:
            cd "C:\path\to\DATA-Intake-SharePoint-Lists-v4"
            ./04-Create-And-Import-Lists.ps1 -SiteUrl https://yourtenant.sharepoint.com/sites/DATA-Intake -ClientId <id> -EmailDomain yourcompany.com
          -EmailDomain swaps {EmailDomain} in the CSVs for your domain, so
          sample people (e.g. mauricioa@{EmailDomain}) become your accounts.
          This creates the 6 lists with the right column types, indexes
          and choices, turns on attachments, and loads the setup and
          sample data.

     OPTION B - BY HAND (about 1 hour)
       FIRST: the CSVs use {EmailDomain} in place of a real email domain.
       Open each CSV in Notepad, Replace All  {EmailDomain}  with your
       domain (for example contoso.com), save, then continue.
       For each CSV in 1-Setup-Lists, then 2-Working-Lists
       (IntakeRequests FIRST, into a brand-new list, so IDs are 1-14):
         1. Site > New > List > From CSV. Keep the file name as list name.
         2. Set each column type as in 01-Column-Definitions.csv.
            Multi-line columns (AnswersJson, InternalJson, the Summaries,
            Description, Notes, Details, ChoiceOptions, HelpText,
            ManagerEmails, MemberEmails, CanReassignEmails,
            ApprovalComments) > Multiple lines of text.
         3. After creating: each multi-line column > "Plain text" (NOT
            enhanced rich text), "Append changes" = No.
         4. List settings > Indexed columns: every column with Indexed = Yes.
         5. List settings > Advanced settings > Attachments = Enabled
            on IntakeRequests and IntakeTasks.

     CHECK:
       [ ] 6 lists exist with the exact names above
       [ ] IntakeTeams 15 rows, IntakeRequestTypes 18, IntakeAttributes 28
       [ ] IntakeRequests 14 sample requests, IntakeTasks 17, IntakeActivity 85
       [ ] Attachments enabled on IntakeRequests and IntakeTasks

  STEP 4  Permissions (run the script again with these added)
       ./04-Create-And-Import-Lists.ps1 -SiteUrl <url> -ClientId <id> -SkipSampleData -SkipConfigData `
           -ReadersLogin "intake-users@yourcompany.com" -ServiceAccount "svc-intake@yourcompany.com" -HideLists
     Result on every list:
       site Owners (your admins) .. Full Control
       users group ................ Read
       service account ............ Contribute
       hidden from Site contents and search
     By hand instead: each list > Settings > Permissions for this list >
       Stop inheriting > remove Members and Visitors > grant the users
       group Read and the service account Contribute.

  STEP 5  Replace the sample people
     IntakeTeams: put your real managers and members in ManagerEmails /
     MemberEmails (lower case, separated by ; and nothing else).

  STEP 6  Build the 6 flows   (03-Flow-Recipes.txt)
     Signed in as the service account. Order:
       IF_SubmitRequest > IF_Auto_PromoteAnswers > IF_UpdateRequest >
       IF_ChangeStage > IF_SaveTask > IF_AddAttachment

  STEP 7  Build the app   (02-PowerFx-Snippets.txt)
     Add the 6 lists (for reading) and the 5 app flows (for saving).
     Never Patch or SubmitForm to a list.
     Screens: New Request > My Requests > Request detail > My Work >
     Manager Dashboard > Help

  STEP 8  Test with 3 users (requestor, team member, manager)
     [ ] Requestor opens a list in SharePoint > can view, cannot edit
     [ ] Requestor submits > request appears with a number; report
         columns and AnswersSummary fill within about a minute
     [ ] Requestor attaches a file > it shows on the request
     [ ] Manager assigns; team member saves team answers; requestor
         does not see the team tab
     [ ] Sign-off and acceptance approvals work from My Work
     [ ] Task with "evidence required" cannot be Done until a file is attached
     [ ] Two people save the same request > second gets "conflict"
     [ ] Then delete the sample rows in the 3 working lists


--------------------------------------------------------------------------
 4. HOW ANSWERS ARE STORED
--------------------------------------------------------------------------

  Every answer is saved on the request row as JSON text:
    [{"k":"business_impact","q":"Expected business impact","t":"Choice","v":"High"}]
    k = attribute key, q = label at the time, t = type, v = answer

    AskedOf = Requestor  > AnswersJson
    AskedOf = Team       > InternalJson

  Attributes with a ReportColumn are ALSO copied into a real column by
  the Promote flow, so you can filter, sort and chart them:
    BusinessObjective, BusinessImpact, RegulatoryDriver, RegulatoryReference,
    OmpRevenueBand, OmpChannelEnablement, TargetLaunchDate, DataOwner,
    ContainsPII, EffortDays, DataClassification, PrivacyReview,
    LegalReviewNeeded
  AnswersSummary / InternalSummary show all answers as readable lines.


--------------------------------------------------------------------------
 5. [DO] DAY-TO-DAY CHANGES (NO APP OR FLOW CHANGE)
--------------------------------------------------------------------------

  ADD AN ATTRIBUTE
    IntakeAttributes > New:
      Title          Target customer segment
      AttributeKey   target_segment        (lower_snake_case, never reused)
      AttributeType  Choice
      ChoiceOptions  Retail;Small Business;Enterprise
      AppliesToTeams CA;DA                  (blank = all teams)
      AppliesToTypes                        (blank = all types)
      AskedOf        Requestor
      Section        Team questions
      SortOrder      50
      IsRequired     Yes
      IsActive       Yes

  ADD A TEAM OR TYPE TO AN EXISTING ATTRIBUTE
    Edit AppliesToTeams / AppliesToTypes, e.g. CA;DA > CA;DA;OMP

  DIFFERENT SETTINGS FOR ONE TEAM (e.g. required only for CA)
    Add a second row with the SAME AttributeKey and AppliesToTeams = CA.
    The more specific row wins for CA; the general row applies elsewhere.

  SHOW ONLY IF ANOTHER ANSWER MATCHES
    ShowIfKey = regulatory_driver, ShowIfValue = Yes

  MAKE AN ATTRIBUTE REPORTABLE
    1. IntakeRequests > Add column (e.g. TargetSegment; text for choices)
    2. IntakeAttributes > ReportColumn = TargetSegment
    3. Old requests: set PromotePending = Yes on them (or run the backfill)

  RETIRE AN ATTRIBUTE      IsActive = No (never delete one that was answered)
  CHANGE THE WORDING       Edit Title (old requests keep their old wording)
  ADD A PERSON             add their email to the team's ManagerEmails or MemberEmails
  ADD A TEAM               new IntakeTeams row (TeamKind = Delivery team)
  ADD AN APPROVER          add to MemberEmails on the DMO-APPROVERS row
  ADD AN ADMIN             add to MemberEmails on the ADMIN row
  ADD A REQUEST TYPE       new IntakeRequestTypes row

  KEEP IT HEALTHY
    - Codes and keys never change once used.
    - Emails: lower case, separated by ; only. A typo means that person
      gets no team access (the app and flows simply do not match them).
    - Same for AppliesToTeams / AppliesToTypes: a misspelt code means the
      attribute does not appear. Check the form after each change.
    - Promote only what you filter or chart on.


--------------------------------------------------------------------------
 6. WHAT IS IN THIS PACK
--------------------------------------------------------------------------

  00-README.txt .................. this file
  01-Column-Definitions.csv ...... every column: type, required, indexed,
                                   unique, default, choices, who writes it,
                                   purpose
  02-PowerFx-Snippets.txt ........ app formulas: roles, dynamic form,
                                   submit, read screens, saves, dashboard
  03-Flow-Recipes.txt ............ the 6 flows step by step, with the
                                   identity and role checks
  04-Create-And-Import-Lists.ps1 . creates lists, imports data, sets
                                   permissions, hides lists
  05-Reporting.txt ............... Power BI / Excel
  06-Flow-Catalogue.csv .......... one line per flow: who may do what,
                                   input, output, lists written

  1-Setup-Lists/   your real setup, converted from the app we built
     IntakeTeams.csv ......... 13 teams + DMO-APPROVERS + ADMIN
     IntakeRequestTypes.csv .. 18 request types
     IntakeAttributes.csv .... 28 attributes (13 with a ReportColumn;
                               e.g. data_classification and effort_days
                               apply to CA;OMP)

  2-Working-Lists/ SAMPLE data from the requests in the app
     IntakeRequests.csv ...... 14 requests in every stage, with current
                               approval (one pending acceptance)
     IntakeTasks.csv ......... 17 tasks
     IntakeActivity.csv ...... 85 timeline entries incl. approval history

  Sample files are not included (attachments cannot be imported from CSV).
  Demo values: business impact (from priority), business objective (from
  the POC business value), the regulatory reference on the risk review.


--------------------------------------------------------------------------
 7. WHAT YOU ACCEPT WITH THIS DESIGN
--------------------------------------------------------------------------

  - Anyone with Read who opens a list in SharePoint can SEE all requests,
    including team answers. They cannot change anything. Keep truly
    sensitive information out of the attributes, or add one extra
    team-only list for it later.
  - People are typed as email text, not picked - check spelling.
  - Files are attachments: simple, but no folders and no file versions.
  - Only the current approval is on the request; the full history is in
    IntakeActivity.


--------------------------------------------------------------------------
 8. FAQ
--------------------------------------------------------------------------

  Q: Why can't users just save directly from the app?
  A: In SharePoint, whatever the app can change, the user can change in
     the browser too. Read-only users + save flows is what prevents edits.

  Q: Do I need to add every user to SharePoint?
  A: No. One group with Read, once.

  Q: Do new attributes need an app or flow change?
  A: No. Add a row in IntakeAttributes. For a report column, add the
     column and set ReportColumn.

  Q: What if the Promote flow fails?
  A: Nothing is lost - answers are in the JSON. Fix it and set
     PromotePending = Yes on the affected requests.

  Q: A user gets "You do not have permission" when saving.
  A: Check their email in IntakeTeams for that team.

==========================================================================
