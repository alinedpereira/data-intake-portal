import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { EyeOff, Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { actorName, useAppStore } from "@/lib/store";
import { appendLog, updateRequest, type IntakeRequest } from "@/lib/intake";
import {
  applicable,
  changedLabels,
  draftFrom,
  formatAnswer,
  invalidNumbers,
  isShown,
  mergeAnswers,
  parseAnswers,
  scopeOf,
  useQuestionConfig,
  type AppliedQuestion,
  type Answers,
  type Draft,
} from "@/lib/team-questions";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Inputs                                                              */
/* ------------------------------------------------------------------ */

export function QuestionFields({
  questions,
  draft,
  onChange,
  idPrefix,
  showErrors,
  className,
}: {
  questions: AppliedQuestion[];
  draft: Draft;
  onChange: (key: string, value: string) => void;
  idPrefix: string;
  showErrors?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("grid gap-x-6 gap-y-4 md:grid-cols-2", className)}>
      {questions.filter((q) => isShown(q, draft)).map((q) => {
        const id = `${idPrefix}-${q.key}`;
        const helpId = q.help ? `${id}-help` : undefined;
        const errId = `${id}-err`;
        const value = draft[q.key] ?? "";
        const missing = showErrors && q.required && !value.trim();
        const badNumber = q.type === "Number" && value.trim() !== "" && !Number.isFinite(Number(value));
        const describedBy = [helpId, missing || badNumber ? errId : undefined].filter(Boolean).join(" ") || undefined;
        return (
          <div key={q.key} className={cn("grid content-start gap-1.5", q.type === "Long text" && "md:col-span-2")}>
            <Label htmlFor={id} className="font-semibold">
              {q.label}
              {q.required && <span className="text-primary" aria-hidden="true">*</span>}
              {q.required && <span className="sr-only"> (required)</span>}
            </Label>
            {q.type === "Long text" ? (
              <Textarea id={id} rows={3} value={value} onChange={(e) => onChange(q.key, e.target.value)} aria-describedby={describedBy} aria-invalid={missing || undefined} className="bg-card" />
            ) : q.type === "Choice" || q.type === "Yes/No" ? (
              <div className="[&>[data-slot=native-select-wrapper]]:w-full">
                <NativeSelect id={id} value={value} onChange={(e) => onChange(q.key, e.target.value)} aria-describedby={describedBy} aria-invalid={missing || undefined} className="bg-card">
                  <NativeSelectOption value="">Choose…</NativeSelectOption>
                  {(q.type === "Yes/No" ? ["Yes", "No"] : q.choices.map((c) => c.label)).map((c) => (
                    <NativeSelectOption key={c} value={c}>{c}</NativeSelectOption>
                  ))}
                </NativeSelect>
              </div>
            ) : (
              <Input
                id={id}
                type={q.type === "Number" ? "number" : q.type === "Date" ? "date" : "text"}
                inputMode={q.type === "Number" ? "decimal" : undefined}
                value={value}
                onChange={(e) => onChange(q.key, e.target.value)}
                aria-describedby={describedBy}
                aria-invalid={missing || badNumber || undefined}
                className="bg-card"
              />
            )}
            {q.help && <p id={helpId} className="text-xs text-muted-foreground">{q.help}</p>}
            {missing && <p id={errId} className="text-xs text-destructive">Answer this question.</p>}
            {badNumber && <p id={errId} className="text-xs text-destructive">Enter a number.</p>}
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Read-only answers                                                   */
/* ------------------------------------------------------------------ */

export function AnswersList({ questions, answers, showPoints }: { questions: AppliedQuestion[]; answers: Answers; showPoints?: boolean }) {
  const draft = draftFrom(questions, answers);
  const shown = questions.filter((q) => isShown(q, draft));
  const keys = new Set(questions.map((q) => q.key));
  const other = Object.entries(answers).filter(([k]) => !keys.has(k));
  return (
    <div className="space-y-3">
      {shown.length > 0 && (
        <dl className="grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
          {shown.map((q) => {
            const a = answers[q.key];
            const text = formatAnswer(q.type, a?.v);
            return (
              <div key={q.key} className={q.type === "Long text" ? "sm:col-span-2" : undefined}>
                <dt className="text-xs font-medium text-muted-foreground">{q.label}</dt>
                <dd className="whitespace-pre-wrap">
                  {text ?? <span className="text-muted-foreground">{q.required ? "Not answered (required)" : "—"}</span>}
                  {showPoints && q.scored && a?.p !== undefined && <span className="ml-2 text-xs text-muted-foreground">({a.p} pts)</span>}
                </dd>
              </div>
            );
          })}
        </dl>
      )}
      {other.length > 0 && (
        <div className="rounded-md border border-border bg-muted/40 p-3">
          <p className="text-xs font-semibold text-muted-foreground">Also on file (asked under an earlier team or intake type)</p>
          <dl className="mt-1 grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
            {other.map(([k, a]) => (
              <div key={k}>
                <dt className="text-xs text-muted-foreground">{a.q}</dt>
                <dd>{formatAnswer(undefined, a.v)}</dd>
              </div>
            ))}
          </dl>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Intake page: requestor's answers (everyone)                         */
/* ------------------------------------------------------------------ */

export function RequestorAnswersSection({ r }: { r: IntakeRequest }) {
  const role = useAppStore((s) => s.role);
  const cfg = useQuestionConfig();
  const questions = applicable(cfg.data, scopeOf(r), "Requestor");
  const answers = parseAnswers(r.RequestorAnswers);
  if (cfg.isPending || (questions.length === 0 && Object.keys(answers).length === 0)) return null;
  return (
    <section aria-labelledby="req-answers-h" className="space-y-2">
      <h2 id="req-answers-h" className="border-b border-border pb-1 text-base font-semibold">
        {r.RoutedTeam?.Value ?? "Team"} questions
      </h2>
      {cfg.isError ? (
        <p role="alert" className="text-sm text-destructive">
          The team's questions couldn't be loaded.{" "}
          <button type="button" className="underline" onClick={() => void cfg.refetch()}>Retry</button>
        </p>
      ) : (
        <AnswersList questions={questions} answers={answers} showPoints={role !== "Requestor"} />
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Intake page: internal team details (manager + team only)            */
/* ------------------------------------------------------------------ */

export function TeamDetailsSection({ r, canEdit }: { r: IntakeRequest; canEdit: boolean }) {
  const role = useAppStore((s) => s.role);
  const cfg = useQuestionConfig();
  const [editing, setEditing] = useState(false);
  if (role === "Requestor") return null;
  const questions = applicable(cfg.data, scopeOf(r), "Internal");
  const answers = parseAnswers(r.InternalAnswers);
  const team = r.RoutedTeam?.Value;
  if (cfg.isSuccess && questions.length === 0 && Object.keys(answers).length === 0 && role !== "Manager") return null;
  const filled = questions.filter((q) => answers[q.key] !== undefined).length;

  return (
    <section aria-labelledby="team-details-h" className="space-y-2 rounded-lg border border-dashed border-primary/40 bg-primary/5 p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 id="team-details-h" className="text-base font-semibold">{team ?? "Team"} internal details</h2>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <EyeOff className="size-3.5" aria-hidden="true" /> Internal · not visible to the requestor
            {questions.length > 0 && ` · ${filled} of ${questions.length} filled`}
          </p>
        </div>
        {canEdit && questions.length > 0 && !editing && (
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>
            <Pencil aria-hidden="true" /> {filled ? "Edit internal details" : "Fill in internal details"}
          </Button>
        )}
      </div>
      {cfg.isPending && <p className="text-sm text-muted-foreground">Loading…</p>}
      {cfg.isError && (
        <p role="alert" className="text-sm text-destructive">
          The team's questions couldn't be loaded.{" "}
          <button type="button" className="underline" onClick={() => void cfg.refetch()}>Retry</button>
        </p>
      )}
      {cfg.isSuccess && questions.length === 0 && (
        <p className="text-sm text-muted-foreground">
          {team ?? "This team"} has no internal questions for {r.RequestTypeL2 ?? "this intake type"}. Add rules with Audience = Internal in the
          IntakeQuestionRules list.
        </p>
      )}
      {editing ? (
        <InternalForm r={r} questions={questions} answers={answers} onDone={() => setEditing(false)} />
      ) : (
        (questions.length > 0 || Object.keys(answers).length > 0) && <AnswersList questions={questions} answers={answers} />
      )}
    </section>
  );
}

function InternalForm({ r, questions, answers, onDone }: { r: IntakeRequest; questions: AppliedQuestion[]; answers: Answers; onDone: () => void }) {
  const qc = useQueryClient();
  const role = useAppStore((s) => s.role);
  const actor = useAppStore(actorName);
  const [draft, setDraft] = useState<Draft>(() => draftFrom(questions, answers));
  const next = mergeAnswers(questions, draft, answers);
  const changed = changedLabels(questions, answers, next);
  const bad = invalidNumbers(questions, draft).length > 0;

  const save = useMutation({
    mutationFn: () =>
      updateRequest(r.ID as number, {
        InternalAnswers: JSON.stringify(next),
        ActivityLog: appendLog(r.ActivityLog, {
          at: new Date().toISOString(),
          by: actor,
          role,
          internal: true,
          text: `Internal details updated: ${changed.join(", ")}`,
        }),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      void qc.invalidateQueries({ queryKey: ["requests"] });
      toast.success("Internal details saved.");
      onDone();
    },
    onError: () => toast.error("Internal details could not be saved. Please try again."),
  });

  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (changed.length && !bad) save.mutate();
      }}
    >
      <QuestionFields questions={questions} draft={draft} onChange={(k, v) => setDraft((p) => ({ ...p, [k]: v }))} idPrefix="internal" />
      <div className="flex flex-wrap gap-2">
        <Button type="submit" disabled={save.isPending || !changed.length || bad}>{save.isPending ? "Saving…" : "Save internal details"}</Button>
        <Button type="button" variant="outline" disabled={save.isPending} onClick={onDone}>Cancel</Button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/* List-driven selects                                                 */
/* ------------------------------------------------------------------ */

export function ListSelect({
  id,
  value,
  onChange,
  options,
  placeholder = "Choose…",
  required,
  disabled,
  loading,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  loading?: boolean;
}) {
  // Keep a current value that's no longer offered, so editing never silently drops it.
  const opts = value && !options.includes(value) ? [value, ...options] : options;
  return (
    <div className="[&>[data-slot=native-select-wrapper]]:w-full">
      <NativeSelect id={id} value={value} required={required} disabled={disabled || loading} onChange={(e) => onChange(e.target.value)} className="bg-card">
        <NativeSelectOption value="">{loading ? "Loading options…" : placeholder}</NativeSelectOption>
        {opts.map((o) => (
          <NativeSelectOption key={o} value={o}>{o}</NativeSelectOption>
        ))}
      </NativeSelect>
    </div>
  );
}
