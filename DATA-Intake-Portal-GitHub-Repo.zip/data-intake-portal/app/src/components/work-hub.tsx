import { useSearchParams } from "react-router-dom";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { ViewTabsList, ViewTabsTrigger } from "@/components/view-tabs";
import { WorkRequestList } from "@/components/work-request-list";
import { MyWorkPackages } from "@/components/my-work-packages";
import { TasksPage } from "@/pages/tasks";
import { useAppStore } from "@/lib/store";
import { managersOf, useTeams } from "@/lib/teams";
import { useState } from "react";
import { DateRangeFilter } from "@/components/date-range-filter";
import { DEFAULT_RANGE, rangeFilter, type SubmittedRange } from "@/lib/date-range";

/** "Requests & tasks" landing page: one page with Requests and Tasks tabs (?tab=tasks deep-links). */
export function WorkHub() {
  const role = useAppStore((s) => s.role);
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") === "tasks" ? "tasks" : "requests";
  const isManager = role === "Manager";
  const manager = useAppStore((s) => s.manager);
  const teams = useTeams();
  const myTeams =
    managersOf(teams.data).find((m) => m.email.toLowerCase() === (manager?.email ?? "").toLowerCase())?.teams ?? [];
  const [range, setRange] = useState<SubmittedRange>(DEFAULT_RANGE);
  const dateFilter = isManager ? rangeFilter(range) : undefined;
  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-semibold tracking-tight">
        {isManager ? `${myTeams.length ? myTeams.join(", ") : "My team"} - Intakes & tasks` : "My Assigned Intakes & Tasks"}
      </h1>
      {isManager && <DateRangeFilter value={range} onChange={setRange} />}
      <Tabs
        value={tab}
        onValueChange={(v) => setParams(v === "tasks" ? { tab: "tasks" } : {}, { replace: true })}
        className="gap-5"
      >
        <ViewTabsList aria-label="Show">
          <ViewTabsTrigger value="requests">{isManager ? "My team's intakes" : "My assigned intakes"}</ViewTabsTrigger>
          <ViewTabsTrigger value="tasks">{isManager ? "My team tasks" : "My tasks"}</ViewTabsTrigger>
        </ViewTabsList>
        <TabsContent value="requests" className="space-y-5">
          {!isManager && <MyWorkPackages />}
          <WorkRequestList extraFilter={dateFilter} />
        </TabsContent>
        <TabsContent value="tasks">
          <TasksPage embedded extraFilter={dateFilter} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
