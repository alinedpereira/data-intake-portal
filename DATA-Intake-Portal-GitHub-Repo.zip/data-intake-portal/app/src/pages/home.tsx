import { Link, Navigate } from "react-router-dom";
import { ArrowRight, FilePlus2, LifeBuoy, TableProperties } from "lucide-react";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { StatusPill } from "@/components/request-bits";
import { DEFAULT_REQUESTOR, useAppStore } from "@/lib/store";
import { REJECTED, displayStatus, requestNumber, statusOf, useRequestPage } from "@/lib/intake";
import { useMyRequestScope } from "@/lib/people";
import { isAwaitingRequestor } from "@/lib/questions";
import { QuestionTag } from "@/components/question-tag";

const RECENT = 5;
/** Requests read to count open ones; beyond this the count is shown as "N+". */
const COUNT_SCAN = 200;

export function HomePage() {
  const role = useAppStore((s) => s.role);
  // Managers and assignees land on their "Requests & tasks" page instead.
  if (role !== "Requestor") return <Navigate to="/work" replace />;
  return <RequestorHome />;
}

/** Requestor landing page: start a request, see your intakes, get help, and recent requests. */
function RequestorHome() {
  const me = DEFAULT_REQUESTOR;
  const firstName = me?.DisplayName?.trim().split(/\s+/)[0] ?? "";
  const { needsIdentity, filter } = useMyRequestScope();
  const q = useRequestPage(needsIdentity ? undefined : filter, undefined, COUNT_SCAN);
  const ready = !needsIdentity && q.isSuccess;
  const rows = ready ? q.data.rows : [];
  const openCount = rows.filter((r) => !["Closed", REJECTED].includes(statusOf(r))).length;
  const more = ready && !!q.data.nextToken;
  const needAnswer = rows.filter(isAwaitingRequestor).length;

  const intakesLine = needsIdentity
    ? "Pick yourself as Requestor to see your intakes"
    : q.isPending
      ? "Counting your open intakes…"
      : q.isError
        ? "Your intakes couldn't be counted"
        : `${openCount}${more ? "+" : ""} open ${openCount === 1 && !more ? "intake" : "intakes"} - Track status and priority`;

  return (
    <div className="mx-auto max-w-6xl space-y-8 p-5 md:p-8">
      <section aria-labelledby="welcome-h" className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="space-y-4 p-6 md:p-8">
          <div className="space-y-2">
            <h1 id="welcome-h" className="text-3xl font-semibold tracking-tight">
              Welcome to the <span className="text-primary">D.A.T.A.</span> Intake Portal{firstName ? `, ${firstName}` : ""}
            </h1>
            <p className="text-muted-foreground">Submit an intake, track its progress, and get help, all in one place.</p>
          </div>
        </div>
        <JourneyStrip />
      </section>

      <div className="grid gap-5 md:grid-cols-3">
        <ActionCard
          icon={<FilePlus2 aria-hidden="true" />}
          title="Start a new intake"
          line="Choose what you need and we'll route it to the right team"
          to="/new"
          cta="Start an Intake"
        />
        <ActionCard
          icon={<TableProperties aria-hidden="true" />}
          title="View my intakes"
          line={intakesLine}
          alert={needAnswer ? `${needAnswer} intake${needAnswer === 1 ? " needs" : "s need"} your answer` : undefined}
          to="/intakes"
          cta="View My Intakes"
        />
        <ActionCard
          icon={<LifeBuoy aria-hidden="true" />}
          title="Get help"
          line="Understand the intake process, stages, and where to get support"
          to="/help"
          cta="Get Help"
          quiet
        />
      </div>

      <section aria-labelledby="recent-h" className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h2 id="recent-h" className="text-lg font-semibold">Your recent intakes</h2>
          {ready && rows.length > 0 && (
            <Link to="/intakes" className="text-sm font-medium text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring">
              See all
            </Link>
          )}
        </div>
        {needsIdentity ? (
          <p className="rounded-lg border border-dashed border-border bg-card p-5 text-sm text-muted-foreground">
            Pick yourself as Requestor at the top of the page to see your recent intakes.
          </p>
        ) : q.isPending ? (
          <p className="text-sm text-muted-foreground">Loading your intakes…</p>
        ) : q.isError ? (
          <p role="alert" className="text-sm text-destructive">
            Your intakes couldn't be loaded.{" "}
            <button type="button" className="underline" onClick={() => void q.refetch()}>Retry</button>
          </p>
        ) : rows.length === 0 ? (
          <p className="rounded-lg border border-dashed border-border bg-card p-5 text-sm text-muted-foreground">
            You haven't submitted any intakes yet.
          </p>
        ) : (
          <ul className="space-y-2">
            {rows.slice(0, RECENT).map((r) => (
              <li key={r.ID}>
                <Link
                  to={`/requests/${r.ID}`}
                  className="flex items-center justify-between gap-4 rounded-lg border border-border bg-card px-4 py-3 text-sm hover:border-primary hover:bg-accent/40 focus-visible:outline-2 focus-visible:outline-ring"
                >
                  <span className="flex min-w-0 items-center gap-4">
                    <span className="shrink-0 font-mono text-xs font-semibold text-primary">{requestNumber(r)}</span>
                    <span className="truncate font-medium">{r.Title}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2">
                    <QuestionTag r={r} forRequestor />
                    <StatusPill status={statusOf(r)} label={displayStatus(r)} />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function ActionCard({
  icon,
  title,
  line,
  to,
  cta,
  quiet = false,
  alert,
}: {
  icon: ReactNode;
  title: string;
  line: string;
  to: string;
  cta: string;
  quiet?: boolean;
  alert?: string;
}) {
  return (
    <section className="flex flex-col gap-3 rounded-xl border-2 border-primary/70 bg-card p-5">
      <h2 className="flex items-center gap-2 text-lg font-semibold [&_svg]:size-5 [&_svg]:text-primary">
        {icon}
        {title}
      </h2>
      <p className="flex-1 text-sm text-muted-foreground">{line}</p>
      {alert && (
        <p className="rounded-md border-l-4 border-amber-500 bg-amber-50 px-3 py-2 text-sm font-semibold text-amber-900 dark:bg-amber-950 dark:text-amber-100">
          {alert}
        </p>
      )}
      <Button asChild variant={quiet ? "outline" : "default"} className="self-start">
        <Link to={to}>
          <ArrowRight aria-hidden="true" /> {cta}
        </Link>
      </Button>
    </section>
  );
}

/** How a request moves, shown as a simple route diagram under the welcome. */
function JourneyStrip() {
  const steps = [
    { n: 1, label: "Submit", sub: "Tell us what you need" },
    { n: 2, label: "Routed", sub: "Sent to the right team" },
    { n: 3, label: "In progress", sub: "The team works on your intake" },
    { n: 4, label: "Sign off", sub: "Confirm the intake meets your needs" },
  ];
  const w = 960;
  const step = w / steps.length;
  return (
    <figure className="border-t border-border bg-muted/50 px-4 py-5 md:px-8">
      <svg viewBox={`0 0 ${w} 96`} role="img" aria-labelledby="journey-title journey-desc" className="w-full">
        <title id="journey-title">How an intake moves through the process</title>
        <desc id="journey-desc">{steps.map((s) => `${s.n}. ${s.label}: ${s.sub}`).join("; ")}</desc>
        <line x1={step / 2} x2={w - step / 2} y1={28} y2={28} className="stroke-primary/40" strokeWidth={4} strokeDasharray="10 8" />
        {steps.map((s, i) => {
          const cx = step / 2 + i * step;
          return (
            <g key={s.n}>
              <circle cx={cx} cy={28} r={20} className="fill-primary" />
              <text x={cx} y={34} textAnchor="middle" className="fill-primary-foreground text-[16px] font-bold">
                {s.n}
              </text>
              <text x={cx} y={70} textAnchor="middle" className="fill-foreground text-[15px] font-semibold">
                {s.label}
              </text>
              <text x={cx} y={89} textAnchor="middle" className="fill-muted-foreground text-[12px]">
                {s.sub}
              </text>
            </g>
          );
        })}
      </svg>
    </figure>
  );
}
