import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Pencil } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ChoiceSelect } from "@/components/choice-select";
import { ListSelect, QuestionFields } from "@/components/team-questions";
import { actorName, useAppStore } from "@/lib/store";
import { appendLog, formatDate, requestNumber, updateRequest, type IntakeRequest, type IntakeWrite } from "@/lib/intake";
import { useRouting } from "@/lib/routing";
import {
  applicable,
  changedLabels,
  draftFrom,
  invalidNumbers,
  mergeAnswers,
  parseAnswers,
  scoreOf,
  useQuestionConfig,
  type Draft,
} from "@/lib/team-questions";

/** Manager: correct the requestor's details and answers. Every change is logged (visible to the requestor). */
export function EditIntakeButton({ r }: { r: IntakeRequest }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        <Pencil aria-hidden="true" /> Edit intake details
      </Button>
      {open && <EditIntakeDialog r={r} onClose={() => setOpen(false)} />}
    </>
  );
}

const dateOnly = (iso?: string) => (iso ? iso.slice(0, 10) : "");

function EditIntakeDialog({ r, onClose }: { r: IntakeRequest; onClose: () => void }) {
  const qc = useQueryClient();
  const role = useAppStore((s) => s.role);
  const actor = useAppStore(actorName);
  const routing = useRouting();
  const cfg = useQuestionConfig();
  const [title, setTitle] = useState(r.Title ?? "");
  const [description, setDescription] = useState(r.RequestDescription ?? "");
  const [priority, setPriority] = useState(r.Priority?.Value ?? "");
  const [neededBy, setNeededBy] = useState(dateOnly(r.NeededBy));
  const [l1, setL1] = useState(r.RequestTypeL1?.Value ?? "");
  const [l2, setL2] = useState(r.RequestTypeL2 ?? "");
  const [domain, setDomain] = useState(r.AnalyticsDomain?.Value ?? "");
  const [reason, setReason] = useState("");
  const team = r.RoutedTeam?.Value;

  const previous = parseAnswers(r.RequestorAnswers);
  const questions = applicable(cfg.data, { team, level1: l1, level2: l2 }, "Requestor");
  const [draftEdits, setDraftEdits] = useState<Draft>({});
  const draft: Draft = { ...draftFrom(questions, previous), ...draftEdits };
  const nextAnswers = mergeAnswers(questions, draft, previous);
  const answerChanges = changedLabels(questions, previous, nextAnswers);
  const newScore = scoreOf(questions, nextAnswers);

  const showDomain = routing.needsFocusArea(l1, l2);
  const suggested = routing.suggestTeam(l1, l2, showDomain ? domain : undefined);
  const teamMismatch = !!suggested && suggested !== team;

  const changes: Partial<Omit<IntakeWrite, "ID">> = {};
  const notes: string[] = [];
  const diff = (label: string, before: string | undefined, after: string) => notes.push(`${label}: ${before || "not set"} → ${after || "not set"}`);
  if (title.trim() && title.trim() !== r.Title) {
    changes.Title = title.trim();
    diff("Title", r.Title, title.trim());
  }
  if (description.trim() && description.trim() !== (r.RequestDescription ?? "").trim()) {
    changes.RequestDescription = description.trim();
    notes.push("Description updated");
  }
  if (priority && priority !== r.Priority?.Value) {
    changes.Priority = { Value: priority };
    diff("Priority", r.Priority?.Value, priority);
  }
  if (neededBy && neededBy !== dateOnly(r.NeededBy)) {
    changes.NeededBy = `${neededBy}T12:00:00Z`;
    diff("Needed by", r.NeededBy ? formatDate(r.NeededBy) : undefined, formatDate(`${neededBy}T12:00:00Z`));
  }
  if (l1 && l1 !== r.RequestTypeL1?.Value) {
    changes.RequestTypeL1 = { Value: l1 };
    diff("Level 1 type", r.RequestTypeL1?.Value, l1);
  }
  if (l2 && l2 !== r.RequestTypeL2) {
    changes.RequestTypeL2 = l2;
    diff("Level 2 type", r.RequestTypeL2, l2);
  }
  if (showDomain && domain && domain !== r.AnalyticsDomain?.Value) {
    changes.AnalyticsDomain = { Value: domain };
    diff("Business focus area", r.AnalyticsDomain?.Value, domain);
  }
  if (answerChanges.length) {
    changes.RequestorAnswers = JSON.stringify(nextAnswers);
    notes.push(`Answers updated: ${answerChanges.join(", ")}`);
    if (newScore !== undefined && newScore !== r.BacklogScore) {
      changes.BacklogScore = newScore;
      notes.push(`Score recalculated ${typeof r.BacklogScore === "number" ? `${r.BacklogScore} → ` : "to "}${newScore}`);
    }
  }
  const dirty = notes.length > 0;
  const bad = invalidNumbers(questions, draft).length > 0;

  const save = useMutation({
    mutationFn: () =>
      updateRequest(r.ID as number, {
        ...changes,
        ActivityLog: appendLog(r.ActivityLog, {
          at: new Date().toISOString(),
          by: actor,
          role,
          text: `Intake details updated by manager. ${notes.join("; ")}.${reason.trim() ? ` Reason: ${reason.trim()}` : ""}`,
        }),
      }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      void qc.invalidateQueries({ queryKey: ["requests"] });
      toast.success("Intake details updated. The requestor can see the change in the activity history.");
      onClose();
    },
    onError: () => toast.error("The intake details could not be saved. Please try again."),
  });

  return (
    <Dialog open onOpenChange={(o) => !o && !save.isPending && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit intake details</DialogTitle>
          <DialogDescription>{requestNumber(r)} · Changes are recorded in the activity history, which the requestor can see.</DialogDescription>
        </DialogHeader>
        <form
          id="edit-intake-form"
          className="grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (dirty && !bad) save.mutate();
          }}
        >
          <div className="grid gap-1.5">
            <Label htmlFor="ei-title">Intake title</Label>
            <Input id="ei-title" required value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="ei-desc">Intake description</Label>
            <Textarea id="ei-desc" rows={4} required value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="ei-priority">Priority</Label>
              <ChoiceSelect id="ei-priority" field="Priority" value={priority} onChange={setPriority} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="ei-needed">Needed by</Label>
              <Input id="ei-needed" type="date" value={neededBy} onChange={(e) => setNeededBy(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="ei-l1">Level 1 intake type</Label>
              <ListSelect
                id="ei-l1"
                value={l1}
                loading={routing.isPending}
                options={routing.level1Options}
                onChange={(v) => {
                  setL1(v);
                  if (!routing.level2Options(v).includes(l2)) setL2("");
                }}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="ei-l2">Level 2 intake type</Label>
              <ListSelect id="ei-l2" value={l2} loading={routing.isPending} options={routing.level2Options(l1)} onChange={setL2} />
            </div>
            {showDomain && (
              <div className="grid gap-1.5 sm:col-span-2">
                <Label htmlFor="ei-domain">Business focus area</Label>
                <ListSelect id="ei-domain" value={domain} options={routing.focusAreaOptions} onChange={setDomain} />
              </div>
            )}
          </div>
          {routing.isError && <p role="alert" className="text-xs text-destructive">Intake types couldn't be loaded.</p>}
          {teamMismatch && (
            <p className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-700 dark:bg-amber-950 dark:text-amber-100">
              These types normally go to <strong>{suggested}</strong>. Saving keeps it with {team ?? "the current team"}; use Re-route to another team to move it.
            </p>
          )}
          {questions.length > 0 && (
            <fieldset className="space-y-3 rounded-md border border-border p-3">
              <legend className="px-1 text-sm font-semibold">{team} questions (answered by the requestor)</legend>
              <QuestionFields questions={questions} draft={draft} onChange={(k, v) => setDraftEdits((p) => ({ ...p, [k]: v }))} idPrefix="ei-q" />
              {questions.some((q) => q.scored) && (
                <p className="text-xs text-muted-foreground">
                  Score from these answers: <strong>{newScore ?? "not complete"}</strong>
                  {typeof r.BacklogScore === "number" ? ` (currently ${r.BacklogScore})` : ""}
                </p>
              )}
            </fieldset>
          )}
          <div className="grid gap-1.5">
            <Label htmlFor="ei-reason">Reason for the change (optional)</Label>
            <Input id="ei-reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Agreed with the requestor at intake review" />
          </div>
          {dirty && (
            <div className="rounded-md border border-border bg-muted/50 px-3 py-2 text-xs">
              <p className="font-semibold">What will change</p>
              <ul className="mt-1 list-disc space-y-0.5 pl-4">
                {notes.map((n) => <li key={n}>{n}</li>)}
              </ul>
            </div>
          )}
        </form>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={save.isPending}>Cancel</Button>
          <Button type="submit" form="edit-intake-form" disabled={save.isPending || !dirty || bad || !title.trim() || !description.trim()}>
            {save.isPending ? "Saving…" : "Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
