# S06 – Manager panel, internal details and Edit intake details

**Wireframes:** `W06-intake-detail-manager.png`, `W07-edit-intake-dialog.png`
**Depends on:** S05; flows F2 (`IntakeChangeStage`), F3 (`IntakeAnswersChanged`)

## Goal
On scrIntakeDetail, managers of the routed team get: assign owner, reference, re-route, set status (allowed targets only), reopen, the internal details panel (team questions with Audience = Internal), and an **Edit intake details** dialog that also edits the requestor's answers.

## Manager actions (`conManagerActions`, visible when `varIsTeamManager`)
| Control | Behaviour |
|---|---|
| cmbOwner + btnAssign | `IntakeChangeStage.Run(varIntake.ID, "Assign", cmbOwner.Selected.Mail, "", CurrentUserEmail)` – F2 sets Owner and moves Submitted/Queued → Assigned / Under Review (IAAP → In Progress) |
| txtReference + btnSetRef | `Patch(IntakeRequests, varIntake, {Reference: txtReference.Text})` then log via `IntakeAskRequestor.Run(varIntake.ID, "Log", "Reference set to " & txtReference.Text, CurrentUserEmail)` |
| drpRerouteTeam, drpRerouteFocus, txtRerouteReason, btnReroute | `IntakeChangeStage.Run(varIntake.ID, "Reroute", drpRerouteTeam.Selected.Title, txtRerouteReason.Text, CurrentUserEmail)`; reason required; F2 clears owner and moves pre-work stages back to Queued |
| drpStatus + btnSetStatus | Items = allowed targets for a Manager from colTransitions (below); OnSelect `IntakeChangeStage.Run(varIntake.ID, "Move", drpStatus.Selected.ToStage, txtStatusReason.Text, CurrentUserEmail)` (show txtStatusReason when the transition row has ReasonRequired) |
| btnReopen (when varLocked) | reason dialog → `IntakeChangeStage.Run(varIntake.ID, "Move", "In Progress", txtReason.Text, CurrentUserEmail)` |
| btnEditIntake | `Set(varShowEdit, true)` – opens the dialog |

```
// drpStatus.Items – only moves IntakeTransitions allows for a manager from the current stage
Filter(colTransitions, FromStage = varIntake.Status.Value, AllowedRole.Value = "Manager",
       Lifecycle.Value = "Any" || Lifecycle.Value = If(varIsIaap, "IAAP", "Standard")).ToStage
// drpRerouteTeam.Items
Filter(colTeams, Title <> varIntake.RoutedTeam.Value)
```

## Internal details panel (`conInternal`, visible when `varRole <> "Requestor"`)
```
// Build applicable INTERNAL questions with the S03 rule-matching formula, using
// Team = varIntake.RoutedTeam.Value, L1 = varIntake.RequestTypeL1.Value, L2 = varIntake.RequestTypeL2, Audience = "Internal"
// → colInternalForm
ClearCollect(colIntAnswers, Filter(IntakeInternalAnswers, RequestItemId = varIntake.ID));
// lblInternalCaption
"Internal · not visible to the requestor · " &
  CountRows(Filter(colInternalForm, QuestionKey in colIntAnswers.QuestionKey)) & " of " & CountRows(colInternalForm) & " filled"
// galInternalAnswers (read mode): label + LookUp(colIntAnswers, QuestionKey = ThisItem.QuestionKey).AnswerValue
// btnEditInternal (managers): switches the gallery to edit mode, reusing the S03 control-per-type template
// btnSaveInternal.OnSelect – upsert one row per changed answer, then log via F3
ForAll(colInternalDraft As a,
    With({existing: LookUp(colIntAnswers, QuestionKey = a.Key)},
        If(IsBlank(a.Value),
            If(!IsBlank(existing), Remove(IntakeInternalAnswers, existing)),
            Patch(IntakeInternalAnswers, Coalesce(existing, Defaults(IntakeInternalAnswers)),
                {Title: a.Label, RequestItemId: varIntake.ID, QuestionKey: a.Key, AnswerValue: a.Value, Points: a.Points,
                 AnsweredBy: User().FullName}))));
IntakeAnswersChanged.Run(varIntake.ID, "Internal", "Internal details updated: " & Concat(colInternalDraft, Label, ", "), CurrentUserEmail, -1);
Set(varEditInternal, false)
```
F3 writes an **IsInternal** activity row ("Internal details updated: …"), so requestors never see it.

## Edit intake details dialog (`conEditDialog`, W07)
Fields: Title, Description, Priority, Needed by, Level 1, Level 2, Business focus area (when the type asks for it), the team's **requestor** questions (same renderer as S03, pre-filled from IntakeAnswers), Reason (optional), a "What will change" summary, Cancel / Save changes.
```
// lblDiffSummary.Text – list each changed field as "Label: old → new"
Concat(Filter(Table(
    {L: "Title", O: varIntake.Title, N: txtEditTitle.Text},
    {L: "Priority", O: varIntake.Priority.Value, N: drpEditPriority.Selected.Value},
    {L: "Needed by", O: Text(varIntake.NeededBy, "d mmm yyyy"), N: Text(dteEditNeeded.SelectedDate, "d mmm yyyy")},
    {L: "Level 1 type", O: varIntake.RequestTypeL1.Value, N: drpEditL1.Selected.Value},
    {L: "Level 2 type", O: varIntake.RequestTypeL2, N: drpEditL2.Selected.Title}), O <> N),
  L & ": " & O & " → " & N, "; ")
// lblTeamMismatch – visible when the suggested team for the new types differs from the routed team:
// "These types normally go to X. Saving keeps it with Y; use Re-route to move it."

// btnSaveEdit.OnSelect
Patch(IntakeRequests, varIntake, {
    Title: txtEditTitle.Text, RequestDescription: txtEditDesc.Text, Priority: drpEditPriority.Selected,
    NeededBy: dteEditNeeded.SelectedDate, RequestTypeL1: {Value: drpEditL1.Selected.Value},
    RequestTypeL2: drpEditL2.Selected.Title,
    AnalyticsDomain: If(drpEditL2.Selected.AskFocusArea, {Value: drpEditFocus.Selected.FocusArea}, varIntake.AnalyticsDomain)});
// upsert changed requestor answers into IntakeAnswers (same pattern as internal), then:
IntakeAnswersChanged.Run(varIntake.ID, "Requestor",
    "Intake details updated by manager. " & lblDiffSummary.Text & If(!IsBlank(txtEditReason.Text), ". Reason: " & txtEditReason.Text, ""),
    CurrentUserEmail, -1);
Set(varShowEdit, false); Set(varIntake, LookUp(IntakeRequests, ID = varIntake.ID))
```
F3 logs the change (visible to the requestor) and recalculates BacklogScore when scored answers changed.

## Acceptance checks
- Status dropdown offers only transitions allowed for a manager from the current stage.
- Assign moves Queued → Assigned / Under Review and logs "Owner set to …"; IAAP goes to In Progress.
- Re-route needs a reason, clears the owner, and the intake disappears from the old manager's queue.
- Internal panel: requestor cannot see it (and cannot read IntakeInternalAnswers in SharePoint); saving logs an internal activity row.
- Edit dialog: changing priority and an OMP answer shows both in "What will change", logs one visible entry, and recalculates the score.

## Prompt to paste
```
On scrIntakeDetail build S06 from 02-prompts/S06: the manager actions container (assign owner, reference, re-route with reason,
status dropdown limited by colTransitions, reopen), the internal details panel conInternal (Audience = Internal questions, read
and edit modes, upsert into IntakeInternalAnswers, then IntakeAnswersChanged.Run) and the Edit intake details dialog that
matches wireframe W07 (fields, the team's requestor questions, reason, "What will change" summary). Every stage change goes
through IntakeChangeStage.Run. Then run the acceptance checks for Manager and Requestor.
```
