import { useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Check, FileSearch, ListChecks, Lock, RotateCcw, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { EmptyState, ErrorState, LoadingState } from "@/components/states";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { RequestProgress } from "@/components/lifecycle";
import { RequestTaskPanel } from "@/components/request-tasks";
import { RequestFiles } from "@/components/request-files";
import { QaPanel } from "@/components/qa-panel";
import { ensureQaTask, hasQaTask, requiresQa, useQaConfig } from "@/lib/qa";
import { DmlPanel } from "@/components/dml-panel";
import { RequestorQuestions } from "@/components/requestor-questions";
import { WorkPackagesSection } from "@/components/work-packages";
import { EditIntakeButton } from "@/components/intake-edit";
import { ListSelect, RequestorAnswersSection, TeamDetailsSection } from "@/components/team-questions";
import { teamHasScoring, useQuestionConfig } from "@/lib/team-questions";
import { useRouting } from "@/lib/routing";
import { usesWorkPackages } from "@/lib/workpackages";
import { useTaskPage } from "@/lib/tasks";
import { teamManagerName, useTeams } from "@/lib/teams";
import { ownerNames, ownerOf, personWrite, requestorOf, useMyRequestScope, type Person } from "@/lib/people";
import { PersonPicker } from "@/components/person-picker";
import { WorkHub } from "@/components/work-hub";
import { StatusPill } from "@/components/request-bits";
import { ChoiceSelect } from "@/components/choice-select";
import { actorName, roleLabel, useAppStore } from "@/lib/store";
import {
  isIaap,
  isLockedStatus,
  QA_STAGE,
  REOPEN_TO,
  SEND_BACK_TO,
  lifecycleFor,
  stageLabel,
  appendLog,
  formatDate,
  parseLog,
  requestNumber,
  statusOf,
  stageAfterAssign,
  DML_STAGE,
  isDataRisk,
  updateRequest,
  useRequest,
  useRequestPage,
  type IntakeRequest,
  type IntakeWrite,
} from "@/lib/intake";

/** Stages an assignee can move forward from; sign-off stages wait for the requestor. */
const ASSIGNEE_NEXT: Record<string, string> = {
  Submitted: "Queued",
  Queued: "Assigned / Under Review",
  "Assigned / Under Review": "Requirements sign-off",
  Approved: "In Progress",
  "In Progress": "Acceptance sign-off",
};

/** IAAP requests skip the sign-off stages. */
const ASSIGNEE_NEXT_IAAP: Record<string, string> = {
  Submitted: "Queued",
  Queued: "In Progress",
  "In Progress": DML_STAGE,
};

export function RequestDetailPage({ withTasks = false }: { withTasks?: boolean }) {
  const { id } = useParams();
  const role = useAppStore((s) => s.role);
  const basePath = withTasks ? "/work" : "/requests";
  const q = useRequest(id);
  const from = (useLocation().state as { from?: string } | null)?.from;
  const backTo = (withTasks && id) || role === "Manager" ? "/work" : from === "/intakes" ? "/intakes" : "/";
  return (
    <div className="mx-auto max-w-6xl space-y-4 p-5 md:p-8">
      {!(withTasks && !id) && (
      <div className="flex flex-wrap items-end justify-between gap-4">
        <Link to={backTo} className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline focus-visible:outline-2 focus-visible:outline-ring">
          <ArrowLeft className="size-4" aria-hidden="true" /> {backTo === "/work" ? (role === "Manager" ? "Back to My Team's Queue" : "Back to My Work Queue") : backTo === "/intakes" ? "Back to My Intakes" : role === "Requestor" ? "Back to home" : "Back to My Work Queue"}
        </Link>
        <RequestPicker currentId={id} basePath={basePath} />
      </div>
      )}
      {withTasks && role === "Requestor" ? (
        <EmptyState icon={Lock} title="This screen is only available to team members and managers" />
      ) : !id && withTasks ? (
        <WorkHub />
      ) : !id ? (
        <>
          <h1 className="text-2xl font-semibold tracking-tight">{withTasks ? "Intake and tasks" : "Intake details"}</h1>
          <EmptyState icon={FileSearch} title={withTasks ? "Choose an intake to see its details and tasks" : "Choose an intake to see its details and progress"} />
        </>
      ) : q.isPending ? (
        <LoadingState rows={6} />
      ) : q.isError || !q.data ? (
        <ErrorState title="This intake could not be loaded" action={<Button onClick={() => void q.refetch()}>Retry</Button>} />
      ) : (
        <Detail r={q.data} withTasks={withTasks} />
      )}
    </div>
  );
}

/** Jump to any request the current view can see. */
function RequestPicker({ currentId, basePath }: { currentId?: string; basePath: string }) {
  const navigate = useNavigate();
  const { role, needsIdentity, filter } = useMyRequestScope();
  const [skipToken, setSkipToken] = useState<string | undefined>();
  const [prev, setPrev] = useState<(string | undefined)[]>([]);
  const q = useRequestPage(filter, skipToken, 100);
  if (needsIdentity)
    return (
      <p className="text-sm text-muted-foreground">
        {role === "Manager" ? (
          "Choose a manager at the top to pick an intake."
        ) : (
          <>
            {role === "Requestor" ? (
              "Pick yourself as Requestor at the top of the page to pick an intake."
            ) : (
              <>
                Pick yourself as Owner on{" "}
                <Link to="/work" className="font-medium text-primary underline">My Work Queue</Link> to pick an intake.
              </>
            )}
          </>
        )}
      </p>
    );
  const rows = q.data?.rows ?? [];
  const nextToken = q.data?.nextToken;
  return (
    <div className="flex items-end gap-2">
      <div className="grid gap-1">
        <Label htmlFor="pick-request">Open intake</Label>
        {q.isError ? (
          <p role="alert" className="text-sm text-destructive">
            Intakes could not be loaded. <button type="button" className="underline" onClick={() => void q.refetch()}>Retry</button>
          </p>
        ) : (
          <div className="[&>[data-slot=native-select-wrapper]]:w-72">
            <NativeSelect
              id="pick-request"
              value={currentId ?? ""}
              disabled={q.isPending}
              onChange={(e) => e.target.value && navigate(`${basePath}/${e.target.value}`)}
              className="bg-card"
            >
              <NativeSelectOption value="">{q.isPending ? "Loading intakes…" : rows.length ? "Choose an intake…" : "No intakes yet"}</NativeSelectOption>
              {rows.map((r) => (
                <NativeSelectOption key={r.ID} value={String(r.ID)}>
                  {requestNumber(r)} · {r.Title}
                </NativeSelectOption>
              ))}
            </NativeSelect>
          </div>
        )}
      </div>
      {prev.length > 0 && (
        <Button variant="outline" size="sm" disabled={q.isFetching} onClick={() => { setSkipToken(prev[prev.length - 1]); setPrev((p) => p.slice(0, -1)); }}>
          Newer
        </Button>
      )}
      {nextToken && (
        <Button variant="outline" size="sm" disabled={q.isFetching} onClick={() => { setPrev((p) => [...p, skipToken]); setSkipToken(nextToken); }}>
          Older
        </Button>
      )}
    </div>
  );
}

function Detail({ r, withTasks }: { r: IntakeRequest; withTasks: boolean }) {
  const role = useAppStore((s) => s.role);
  const qc = useQueryClient();
  const status = statusOf(r);
  const iaap = isIaap(r);
  const qaConfig = useQaConfig();
  const teamsQ = useTeams();
  // QA stage applies to configured request types, or to any request that has a QA/Testing task.
  const requestTasks = useTaskPage(`RequestItemId eq ${Number(r.ID)}`, undefined, 200);
  const qaEnabled = !iaap && (requiresQa(qaConfig.data, r) || hasQaTask(requestTasks.data?.rows.filter((t) => !t.WorkPackageId)));
  const stages = lifecycleFor(r, qaEnabled);
  const actor = useAppStore(actorName);
  // Backfill: the first time a manager opens an open QA-enabled request with no QA task, add one.
  const latest = useRef({ r, actor });
  latest.current = { r, actor };
  const requestId = r.ID;
  useEffect(() => {
    if (role !== "Manager" || !qaEnabled || !requestId) return;
    ensureQaTask(latest.current.r, latest.current.actor, role)
      .then((made) => made && toast.success("QA task added (unassigned). Assign it to the tester."))
      .catch(() => toast.error("The QA task for this intake couldn't be added. Use Add task to create it."));
  }, [requestId, role, qaEnabled, status]);
  const dataRisk = isDataRisk(r);
  const questionCfg = useQuestionConfig();
  const scored = teamHasScoring(questionCfg.data, r.RoutedTeam?.Value);
  const label = (st: string) => stageLabel(st, iaap);
  const locked = isLockedStatus(status);
  const log = parseLog(r.ActivityLog).filter((e) => role !== "Requestor" || !e.internal);

  const save = useMutation({
    mutationFn: ({ changes, note }: { changes: Partial<Omit<IntakeWrite, "ID">>; note: string }) =>
      updateRequest(r.ID as number, {
        ...changes,
        ActivityLog: appendLog(r.ActivityLog, { at: new Date().toISOString(), by: actor, role, text: note }),
      }),
    onSuccess: (_updated, { changes }) => {
      // Re-read everything that shows this request so every screen reflects the new stage and fields.
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      void qc.invalidateQueries({ queryKey: ["requests"] });
      void qc.invalidateQueries({ queryKey: ["tasks"] });
      const stage = changes.Status?.Value;
      toast.success(stage ? `Moved to ${label(stage)}` : "Saved");
    },
    onError: () => toast.error("The change could not be saved. Please try again."),
  });

  const navigate = useNavigate();
  const myManager = useAppStore((s) => s.manager);
  /** Stages that go back to Queued when re-routed (work hasn't started yet). */
  const PRE_WORK = ["Submitted", "Queued", "Assigned / Under Review", "Requirements sign-off", "Approved"];
  const reroute = useMutation({
    mutationFn: async ({ team, reason, domain }: { team: string; reason: string; domain?: string }) => {
      const from = r.RoutedTeam?.Value ?? "no team";
      const domainChanged = !!domain && domain !== r.AnalyticsDomain?.Value;
      const domainPart = domainChanged ? { AnalyticsDomain: { Value: domain } } : {};
      const domainNote = domainChanged ? `Business focus area changed from ${r.AnalyticsDomain?.Value ?? "none"} to ${domain}` : "";
      if (team === r.RoutedTeam?.Value) {
        // Focus area only: the team stays, so the owner and stage are untouched.
        await updateRequest(r.ID as number, {
          ...domainPart,
          ActivityLog: appendLog(r.ActivityLog, { at: new Date().toISOString(), by: actor, role, text: `${domainNote}: ${reason}` }),
        });
        return { team, ownerCleared: false, hadOwner: false, sameTeam: true };
      }
      const backToQueue = PRE_WORK.includes(status);
      const base: Partial<Omit<IntakeWrite, "ID">> = {
        RoutedTeam: { Value: team },
        ...domainPart,
        ...(backToQueue && status !== "Queued" ? { Status: { Value: "Queued" } } : {}),
      };
      const hadOwner = !!ownerOf(r);
      const note = (ownerCleared: boolean) =>
        (domainNote ? `${domainNote}. ` : "") +
        `Re-routed from ${from} to ${team}: ${reason}` +
        (backToQueue && status !== "Queued" ? " (moved back to Queued)" : "") +
        (hadOwner ? (ownerCleared ? " (owner cleared for the new team to assign)" : " (owner kept; the new team should reassign)") : "");
      const log = (ownerCleared: boolean) =>
        appendLog(r.ActivityLog, { at: new Date().toISOString(), by: actor, role, text: note(ownerCleared) });
      if (!hadOwner) {
        await updateRequest(r.ID as number, { ...base, ActivityLog: log(false) });
        return { team, ownerCleared: false, hadOwner, sameTeam: false };
      }
      // Clear the owner so the new team's manager assigns their own person. If SharePoint
      // won't accept an empty person value, re-route anyway and say the owner was kept.
      try {
        const updated = await updateRequest(r.ID as number, {
          ...base,
          Owner: null as unknown as undefined,
          ActivityLog: log(true),
        });
        if (updated?.Owner?.Claims) {
          await updateRequest(r.ID as number, { ActivityLog: log(false) });
          return { team, ownerCleared: false, hadOwner, sameTeam: false };
        }
        return { team, ownerCleared: true, hadOwner, sameTeam: false };
      } catch {
        await updateRequest(r.ID as number, { ...base, ActivityLog: log(false) });
        return { team, ownerCleared: false, hadOwner, sameTeam: false };
      }
    },
    onSuccess: ({ team, ownerCleared, hadOwner, sameTeam }) => {
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      if (sameTeam) {
        void qc.invalidateQueries({ queryKey: ["requests"] });
        toast.success("Business focus area updated.");
        return;
      }
      void qc.invalidateQueries({ queryKey: ["requests"] });
      void qc.invalidateQueries({ queryKey: ["tasks"] });
      const newManager = teamManagerName(teamsQ.data, team);
      toast.success(
        `Routed to ${team}${newManager ? ` (${newManager})` : ""}.` +
          (hadOwner && !ownerCleared ? " The owner couldn't be cleared; the new manager should reassign it." : ""),
      );
      const stillMine = teamsQ.data?.some(
        (t) => t.team === team && t.managerEmail.toLowerCase() === (myManager?.email ?? "").toLowerCase(),
      );
      if (!stillMine) navigate("/work");
    },
    onError: () => toast.error("The intake couldn't be re-routed. Please try again."),
  });

  const setStatus = (to: string, extra: Partial<Omit<IntakeWrite, "ID">> = {}, note?: string) =>
    save.mutate({ changes: { Status: { Value: to }, ...extra }, note: note ?? `Status changed to ${label(to)}` });

  return (
    <div className="mt-4 space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-primary">{requestNumber(r)}</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight">{r.Title}</h1>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {!withTasks && role !== "Requestor" && (
            <Button asChild variant="outline" size="sm">
              <Link to={`/work/${r.ID}`}>
                <ListChecks aria-hidden="true" /> Open with tasks
              </Link>
            </Button>
          )}
          <StatusPill status={status} label={label(status)} />
        </div>
      </div>

      <RequestProgress status={status} stages={stages} label={label} />

      <RequestorQuestions r={r} />

      {usesWorkPackages(r) && <WorkPackagesSection r={r} />}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          {role === "Manager" && !locked && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-muted/40 px-3 py-2">
              <p className="text-xs text-muted-foreground">Correct the title, description, types, priority or needed-by date.</p>
              <EditIntakeButton r={r} />
            </div>
          )}
          <DetailSection title="Requestor">
            <Row k="Requestor" v={requestorOf(r)} />
            <Row k="Requestor's email" v={r.Requestor?.Email || r.Requestorsemail} />
            <Row k="On behalf of" v={r.OnBehalfOf} />
            <Row k="Business unit" v={r.BusinessUnit?.Value} />
            <Row k="Submitted" v={formatDate(r.SubmittedOn ?? r.Created)} />
          </DetailSection>
          <DetailSection title="Routing">
            <Row k="Level 1 type" v={r.RequestTypeL1?.Value} />
            <Row k="Level 2 type" v={r.RequestTypeL2} />
            <Row k="Business focus area" v={r.AnalyticsDomain?.Value} />
            <Row k="Routed to" v={r.RoutedTeam?.Value} />
            <Row k="Team manager" v={teamManagerName(teamsQ.data, r.RoutedTeam?.Value)} />
            <Row k="Owner" v={ownerNames(r) ?? "Unassigned"} />
            <Row k="Intake status" v={r.RequestStatus?.Value} />
            <Row k="Reference" v={r.Reference} />
            <Row k="Comments" v={r.RequestComments} />
          </DetailSection>
          <DetailSection title="Intake">
            <Row k="Description" v={r.RequestDescription} />
          </DetailSection>
          <DetailSection title="Dates, priority and value">
            <Row k="Needed by" v={formatDate(r.NeededBy)} />
            <Row k="Priority" v={r.Priority?.Value} />
            {role !== "Requestor" && (scored || typeof r.BacklogScore === "number") && (
              <Row k="Backlog Score" v={typeof r.BacklogScore === "number" ? String(r.BacklogScore) : undefined} />
            )}
            <Row k="Business value" v={r.BusinessValue} />
            {!iaap && <Row k="Requirements" v={r.RequirementsSignedOff ? "Signed off" : "Not signed off"} />}
            {!iaap && <Row k="Acceptance" v={r.AcceptanceSignedOff ? "Signed off" : "Not signed off"} />}
          </DetailSection>
          <RequestorAnswersSection r={r} />
          <TeamDetailsSection r={r} canEdit={role === "Manager" && !locked} />
          <RequestFiles requestNo={requestNumber(r)} />
        </div>

      <div className="space-y-6">
        <section aria-labelledby="actions-h" className="space-y-3 border-t border-border pt-5">
          <h2 id="actions-h" className="text-lg font-semibold">{roleLabel(role)} actions</h2>
          <CommentBox disabled={save.isPending} onAdd={(text) => save.mutate({ changes: {}, note: text })} />

          {role === "Requestor" && iaap && (
            <p className="text-sm text-muted-foreground">IAAP intakes don't need sign-off. You'll see the intake marked Completed when it's done.</p>
          )}
          {role === "Requestor" && !iaap && (
            <div className="grid gap-3 sm:grid-cols-2">
              <SignOff
                label="Requirements sign-off"
                done={!!r.RequirementsSignedOff}
                enabled={status === "Requirements sign-off"}
                busy={save.isPending}
                onClick={() => setStatus("Approved", { RequirementsSignedOff: true }, "Requirements signed off")}
              />
              <SignOff
                label="Acceptance sign-off"
                done={!!r.AcceptanceSignedOff}
                enabled={status === "Acceptance sign-off"}
                busy={save.isPending}
                onClick={() => setStatus("Closed", { AcceptanceSignedOff: true }, "Work accepted and closed")}
              />
              {SEND_BACK_TO[status] && (
                <SendBack
                  stageLabel={status === "Requirements sign-off" ? "requirements" : "delivered work"}
                  to={label(SEND_BACK_TO[status])}
                  busy={save.isPending}
                  onSend={(reason) =>
                    setStatus(SEND_BACK_TO[status], {}, `Sent back by requestor to ${label(SEND_BACK_TO[status])}: ${reason}`)
                  }
                />
              )}
              <p className="text-xs italic text-muted-foreground sm:col-span-2">
                {status === "Requirements sign-off"
                  ? "The team member is waiting for you to confirm the requirements."
                  : status === "Acceptance sign-off"
                    ? "The work is complete. Accept it to close the intake."
                    : r.RequirementsSignedOff && !r.AcceptanceSignedOff
                      ? "Requirements signed off · acceptance sign-off unlocks when the work is complete."
                      : "Sign-off unlocks when the intake reaches that stage."}
              </p>
            </div>
          )}

          {role !== "Requestor" && locked && (
            <div className="space-y-3 rounded-lg border border-border bg-muted/60 p-4 text-sm">
              <p className="flex items-center gap-2 font-semibold">
                <Lock className="size-4" aria-hidden="true" />
                {status === "Closed" ? "This intake is closed." : "This intake is waiting for the requestor's acceptance."}
              </p>
              <p>The intake and its tasks can no longer be changed. You can still add comments.</p>
              {role === "Manager" && (
                <Reopen
                  to={label(REOPEN_TO)}
                  busy={save.isPending}
                  onReopen={(reason) => setStatus(REOPEN_TO, {}, `Reopened by manager: ${reason}`)}
                />
              )}
            </div>
          )}

          {role === "Assignee" && !locked && (
            <AssigneeActions
              status={status}
              next={
                iaap
                  ? ASSIGNEE_NEXT_IAAP[status]
                  : dataRisk && status === "In Progress"
                    ? DML_STAGE
                    : status === "In Progress" && usesWorkPackages(r) && !qaEnabled
                      ? undefined
                    : status === "In Progress" && (qaEnabled || stages.includes(QA_STAGE))
                      ? undefined
                      : ASSIGNEE_NEXT[status]
              }
              label={label}
              busy={save.isPending}
              onMove={(to) => setStatus(to)}
              hint={status === "In Progress" && usesWorkPackages(r) && !qaEnabled ? "Work is delivered through the work packages above. The requestor accepts each one and the manager closes the intake." : undefined}
            />
          )}

          {role !== "Requestor" && dataRisk && status === DML_STAGE && (
            <DmlPanel
              r={r}
              busy={save.isPending}
              onApprove={(comment) => {
                const next = stages[stages.indexOf(DML_STAGE) + 1] ?? "Closed";
                setStatus(next, {}, `DML approved${comment ? `: ${comment}` : ""}. Moved to ${label(next)}`);
              }}
              onSendBack={(reason, owner) => {
                setStatus("In Progress", {}, `Sent back by DML to ${owner ?? "the team"}: ${reason}`);
              }}
            />
          )}

          {role !== "Requestor" && qaConfig.isError && (
            <p role="alert" className="text-sm text-destructive">
              QA settings couldn't be loaded, so the QA Testing stage may be missing.{" "}
              <button type="button" className="underline" onClick={() => void qaConfig.refetch()}>Retry</button>
            </p>
          )}

          {role !== "Requestor" && stages.includes(QA_STAGE) && (
            <QaPanel
              r={r}
              role={role}
              status={status}
              busy={save.isPending}
              onMoveToQa={() => setStatus(QA_STAGE, {}, "Moved to QA Testing by manager")}
              onRecord={(note) => save.mutate({ changes: {}, note: note.startsWith("QA evidence") ? note : `QA result: ${note}` })}
              onComplete={() => setStatus("Acceptance sign-off", {}, "QA Testing complete; moved to Acceptance sign-off")}
            />
          )}

          {role === "Manager" && !locked && (
            <ManagerActions
              key={`${r.Modified ?? ""}-${statusOf(r)}`}
              r={r}
              stages={stages}
              label={label}
              busy={save.isPending}
              onAssign={(person) => {
                const to = stageAfterAssign(r);
                save.mutate({
                  changes: { Owner: personWrite(person), ...(to ? { Status: { Value: to } } : {}) },
                  note: `Owner set to ${person.DisplayName}${to ? `; moved to ${label(to)}` : ""}`,
                });
              }}
              onReference={(ref) => save.mutate({ changes: { Reference: ref }, note: `Reference set to ${ref}` })}
              scored={scored}
              onScore={(n) => save.mutate({ changes: { BacklogScore: n }, note: `Backlog Score set to ${n}` })}
              onTeam={(team, reason, domain) => reroute.mutate({ team, reason, domain })}
              rerouting={reroute.isPending}
              onStatus={(s) => setStatus(s)}
            />
          )}
        </section>

        <section aria-labelledby="log-h" className="space-y-2">
          <h2 id="log-h" className="text-lg font-semibold">Activity</h2>
          {log.length === 0 ? (
            <p className="text-sm text-muted-foreground">No activity yet.</p>
          ) : (
            <ol className="space-y-2">
              {[...log].reverse().map((e, i) => (
                <li key={`${e.at}-${i}`} className="rounded-md border border-border bg-card px-3 py-2 text-sm">
                  <p className="whitespace-pre-wrap">{e.text}</p>
                  {e.internal && <p className="mt-1 text-xs font-medium text-primary">Internal · hidden from the requestor</p>}
                  <p className="mt-1 text-xs text-muted-foreground">
                    {e.by} · {roleLabel(e.role)} · {new Date(e.at).toLocaleString()}
                  </p>
                </li>
              ))}
            </ol>
          )}
        </section>
      </div>
      </div>
      {withTasks && <RequestTaskPanel request={r} locked={locked} />}
    </div>
  );
}

function DetailSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card">
      <h2 className="border-l-4 border-primary bg-accent px-4 py-2 font-semibold text-accent-foreground">{title}</h2>
      <dl className="grid grid-cols-[9rem_minmax(0,1fr)] gap-x-4 gap-y-3 p-4 text-sm">{children}</dl>
    </section>
  );
}

function Row({ k, v }: { k: string; v?: string }) {
  return (
    <>
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="whitespace-pre-wrap break-words font-semibold">{v || "—"}</dd>
    </>
  );
}

function CommentBox({ onAdd, disabled }: { onAdd: (t: string) => void; disabled: boolean }) {
  const [text, setText] = useState("");
  return (
    <form
      className="flex gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!text.trim()) return;
        onAdd(text.trim());
        setText("");
      }}
    >
      <Label htmlFor="comment" className="sr-only">Comment</Label>
      <Input id="comment" value={text} onChange={(e) => setText(e.target.value)} placeholder="Add a comment…" className="bg-card" />
      <Button type="submit" disabled={disabled || !text.trim()}>Add comment</Button>
    </form>
  );
}

/** Requestor sends the request back one stage with a required reason. */
function SendBack({ stageLabel, to, busy, onSend }: { stageLabel: string; to: string; busy: boolean; onSend: (reason: string) => void }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  if (!open)
    return (
      <Button type="button" size="lg" variant="outline" className="sm:col-span-2" disabled={busy} onClick={() => setOpen(true)}>
        <Undo2 aria-hidden="true" /> Send back with comments
      </Button>
    );
  return (
    <form
      className="grid gap-2 rounded-lg border border-border bg-card p-3 sm:col-span-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!reason.trim()) return;
        onSend(reason.trim());
        setReason("");
        setOpen(false);
      }}
    >
      <Label htmlFor="send-back-reason">What needs to change in the {stageLabel}?</Label>
      <Textarea id="send-back-reason" rows={3} required value={reason} onChange={(e) => setReason(e.target.value)} aria-describedby="send-back-hint" />
      <p id="send-back-hint" className="text-xs text-muted-foreground">The intake goes back to “{to}” with your comment.</p>
      <div className="flex gap-2">
        <Button type="submit" disabled={busy || !reason.trim()}>Send back</Button>
        <Button type="button" variant="outline" onClick={() => { setOpen(false); setReason(""); }}>Cancel</Button>
      </div>
    </form>
  );
}

/** Manager reopens a locked request with a required reason. */
function Reopen({ to, busy, onReopen }: { to: string; busy: boolean; onReopen: (reason: string) => void }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  if (!open)
    return (
      <Button type="button" variant="outline" disabled={busy} onClick={() => setOpen(true)}>
        <RotateCcw aria-hidden="true" /> Reopen intake
      </Button>
    );
  return (
    <form
      className="grid gap-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!reason.trim()) return;
        onReopen(reason.trim());
        setReason("");
        setOpen(false);
      }}
    >
      <Label htmlFor="reopen-reason">Why is this intake being reopened?</Label>
      <Textarea id="reopen-reason" rows={3} required value={reason} onChange={(e) => setReason(e.target.value)} aria-describedby="reopen-hint" />
      <p id="reopen-hint" className="text-xs text-muted-foreground">The intake moves back to “{to}” and can be changed again.</p>
      <div className="flex gap-2">
        <Button type="submit" disabled={busy || !reason.trim()}>Reopen</Button>
        <Button type="button" variant="outline" onClick={() => { setOpen(false); setReason(""); }}>Cancel</Button>
      </div>
    </form>
  );
}

function SignOff({ label, done, enabled, busy, onClick }: { label: string; done: boolean; enabled: boolean; busy: boolean; onClick: () => void }) {
  if (done)
    return (
      <p className="flex h-11 items-center justify-center gap-2 rounded-md border-2 border-emerald-700 bg-emerald-50 text-sm font-semibold text-emerald-900 dark:bg-emerald-950 dark:text-emerald-100">
        <Check className="size-4" aria-hidden="true" /> {label} done
      </p>
    );
  return (
    <Button type="button" size="lg" variant={enabled ? "default" : "secondary"} disabled={!enabled || busy} onClick={onClick}>
      {label}
    </Button>
  );
}

function AssigneeActions({
  status,
  next,
  label,
  busy,
  onMove,
  hint,
}: {
  status: string;
  next: string | undefined;
  label: (s: string) => string;
  busy: boolean;
  onMove: (to: string) => void;
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      {next ? (
        <Button size="lg" disabled={busy} onClick={() => onMove(next)}>
          Move to “{label(next)}”
        </Button>
      ) : (
        <p className="text-sm text-muted-foreground">
          {hint ? hint : status === "Requirements sign-off" || status === "Acceptance sign-off"
            ? "Waiting for the requestor to sign off."
            : status === DML_STAGE
              ? "Waiting for the Manager/DML to approve."
              : status === "In Progress"
              ? "Next is QA Testing: start the QA/Testing task, or a manager moves it."
              : status === "QA Testing"
                ? "In QA Testing. A manager marks QA complete."
                : "No further action at this stage."}
        </p>
      )}
    </div>
  );
}

function ManagerActions({
  r,
  stages,
  label,
  busy,
  onAssign,
  onReference,
  scored,
  onScore,
  onTeam,
  rerouting,
  onStatus,
}: {
  r: IntakeRequest;
  stages: readonly string[];
  label: (s: string) => string;
  busy: boolean;
  onAssign: (person: Person) => void;
  onReference: (ref: string) => void;
  onTeam: (team: string, reason: string, domain?: string) => void;
  rerouting: boolean;
  scored: boolean;
  onScore: (score: number) => void;
  onStatus: (s: string) => void;
}) {
  const current = ownerOf(r);
  const [owner, setOwner] = useState<Person | null>(current);
  const ownerChanged = !!owner && owner.Claims !== current?.Claims;
  const [reference, setReference] = useState(r.Reference ?? "");
  const [team, setTeam] = useState("");
  const [routeReason, setRouteReason] = useState("");
  const routing = useRouting();
  const showDomain = routing.needsFocusArea(r.RequestTypeL1?.Value ?? "", r.RequestTypeL2 ?? "");
  const [domain, setDomain] = useState(r.AnalyticsDomain?.Value ?? "");
  const domainChanged = showDomain && !!domain && domain !== r.AnalyticsDomain?.Value;
  const targetTeam = team || r.RoutedTeam?.Value || "";
  const teamChanged = !!team && team !== r.RoutedTeam?.Value;
  const canRoute = (teamChanged || domainChanged) && !!targetTeam && !!routeReason.trim();
  const [score, setScore] = useState(typeof r.BacklogScore === "number" ? String(r.BacklogScore) : "");
  const scoreNum = score.trim() === "" ? NaN : Number(score);
  const scoreValid = Number.isInteger(scoreNum) && scoreNum >= 0;
  const showScore = scored || typeof r.BacklogScore === "number";
  const [status, setStatusDraft] = useState(statusOf(r));
  return (
    <div className="grid gap-4 rounded-lg border border-border bg-card p-4 sm:grid-cols-2">
      <div className="grid gap-1.5 sm:col-span-2">
        <Label htmlFor="owner-pick">Owner</Label>
        <div className="flex gap-2">
          <PersonPicker id="owner-pick" field="Owner" className="min-w-0 flex-1" value={owner} onChange={setOwner} />
          <Button type="button" disabled={busy || !ownerChanged} onClick={() => owner && onAssign(owner)}>Assign</Button>
        </div>
        {stageAfterAssign(r) && (
          <p className="text-xs text-muted-foreground">Assigning moves it to “{label(stageAfterAssign(r) as string)}”.</p>
        )}
      </div>
      <form className="grid gap-1.5 sm:col-span-2" onSubmit={(e) => { e.preventDefault(); if (reference.trim()) onReference(reference.trim()); }}>
        <Label htmlFor="reference">Reference</Label>
        <div className="flex gap-2">
          <Input id="reference" value={reference} onChange={(e) => setReference(e.target.value)} placeholder="e.g. project or ticket reference" />
          <Button type="submit" variant="outline" disabled={busy || !reference.trim() || reference.trim() === r.Reference}>Set</Button>
        </div>
      </form>
      <form
        className="grid gap-2 rounded-md border border-border bg-muted/40 p-3 sm:col-span-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!canRoute) return;
          onTeam(targetTeam, routeReason.trim(), domainChanged ? domain : undefined);
        }}
      >
        <p className="text-sm font-semibold">
          Re-route to another team <span className="font-normal text-muted-foreground">· currently {r.RoutedTeam?.Value ?? "not routed"}</span>
        </p>
        {showDomain && (
          <>
            <Label htmlFor="m-domain">Business focus area <span className="font-normal text-muted-foreground">· currently {r.AnalyticsDomain?.Value ?? "not set"}</span></Label>
            <ListSelect
              id="m-domain"
              options={routing.focusAreaOptions}
              value={domain}
              onChange={(v) => {
                setDomain(v);
                const mapped = routing.suggestTeam(r.RequestTypeL1?.Value ?? "", r.RequestTypeL2 ?? "", v);
                if (mapped) setTeam(mapped);
              }}
              placeholder="Choose a focus area"
            />
          </>
        )}
        <Label htmlFor="m-team">New team</Label>
        <ListSelect
          id="m-team"
          options={routing.teamOptions}
          loading={routing.isPending}
          value={team}
          onChange={setTeam}
          placeholder="Choose a team"
        />
        {team && team === r.RoutedTeam?.Value && !domainChanged && <p className="text-xs text-muted-foreground">That's the current team.</p>}
        {domainChanged && !teamChanged && <p className="text-xs text-muted-foreground">Only the focus area will change; the team stays the same.</p>}
        <Label htmlFor="m-route-reason">Reason for re-routing</Label>
        <Textarea
          id="m-route-reason"
          rows={2}
          required
          value={routeReason}
          onChange={(e) => setRouteReason(e.target.value)}
          placeholder="Why this belongs with the other team"
          aria-describedby="m-route-hint"
        />
        <p id="m-route-hint" className="text-xs text-muted-foreground">
          The reason is saved to the activity history. The owner is cleared for the new team to assign, and intakes that haven't started work go back to Queued.
        </p>
        <Button
          type="submit"
          className="justify-self-start"
          disabled={busy || rerouting || !canRoute}
        >
          {rerouting ? "Saving…" : teamChanged ? "Route to team" : domainChanged ? "Update focus area" : "Route to team"}
        </Button>
      </form>
      {showScore && (
        <>
          <form
            className="grid gap-1.5 sm:col-span-2"
            onSubmit={(e) => { e.preventDefault(); if (scoreValid) onScore(scoreNum); }}
          >
            <Label htmlFor="m-score">Backlog Score</Label>
            <div className="flex gap-2">
              <Input id="m-score" type="number" min={0} step={1} inputMode="numeric" value={score} onChange={(e) => setScore(e.target.value)} className="w-32" aria-describedby="m-score-hint" />
              <Button type="submit" variant="outline" disabled={busy || !scoreValid || scoreNum === r.BacklogScore}>Set</Button>
            </div>
            <p id="m-score-hint" className="text-xs text-muted-foreground">Calculated from the team's scored questions. Set a different whole number to override.</p>
          </form>
        </>
      )}
      <div className="grid gap-1.5 sm:col-span-2">
        <Label htmlFor="m-status">Status</Label>
        <div className="flex gap-2">
          <div className="min-w-0 flex-1"><ChoiceSelect id="m-status" field="Status" value={status} onChange={setStatusDraft} allowed={stages.filter((st) => st !== QA_STAGE)} optionLabel={label} /></div>
          <Button variant="outline" disabled={busy || !status || status === statusOf(r)} onClick={() => onStatus(status)}>Set</Button>
        </div>
      </div>
      <p className="text-xs text-muted-foreground sm:col-span-2">Lifecycle: {stages.map(label).join(" → ")}</p>
    </div>
  );
}
