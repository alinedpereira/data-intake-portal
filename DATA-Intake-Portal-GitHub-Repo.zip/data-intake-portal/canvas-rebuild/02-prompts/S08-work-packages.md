# S08 – Work packages (intake overview + work package screen)

**Wireframes:** `W05-intake-detail-requestor.png` (overview with Accept / Send back), `W08-work-package.png` (package screen)
**Depends on:** S05–S07; flow F4 (`IntakeWorkPackageChange`)

## Goal
Managers split an intake into work packages owned by sub-teams. Each package has its own screen with stage bar, tasks, files, comments and history. The requestor accepts or sends back each package from the intake. Only package milestones are logged on the intake.

## On scrIntakeDetail (`conWorkPackages`, visible when packages exist or the manager can add them)
```
// Load once in OnVisible
ClearCollect(colIntakeWPs, SortByColumns(Filter(IntakeWorkPackages, RequestItemId = varIntake.ID), "SortOrder"));
ClearCollect(colWPTasks, Filter(IntakeTasks, RequestItemId = varIntake.ID, WorkPackageId > 0));
// Header
CountRows(Filter(colIntakeWPs, WPStatus.Value = "Accepted")) & " of " & CountRows(colIntakeWPs) & " accepted"
// Progress bar width = Parent.Width * accepted / total
// galWorkPackages.Items = colIntakeWPs; row subtitle:
ThisItem.SubTeam & " · " & ThisItem.WPOwner.DisplayName & " · due " & Text(ThisItem.WPDueDate, "d mmm yyyy") & " · " &
CountRows(Filter(colWPTasks, WorkPackageId = ThisItem.ID, TaskStatus.Value = "Done")) & " of " &
CountRows(Filter(colWPTasks, WorkPackageId = ThisItem.ID)) & " tasks done"
// Row title prefix: "WP " & ThisItem.SortOrder
// btnOpenWP (team and managers only): Set(varWP, ThisItem); Navigate(scrWorkPackage)
// btnAcceptWP / btnSendBackWP (requestor, only when WPStatus = "Ready for acceptance"):
IntakeWorkPackageChange.Run(ThisItem.ID, "Move", "Accepted", "", CurrentUserEmail)
IntakeWorkPackageChange.Run(ThisItem.ID, "Move", "Sent back", txtWpReason.Text, CurrentUserEmail)   // reason required
// btnAddWP (manager): opens conWPDialog
```
**Add work package dialog:** Title, Description, Sub-team (`Filter(colSubTeams, ParentTeam = varIntake.RoutedTeam.Value)`), Owner (defaults to the sub-team lead: `LookUp(colSubTeams, Title = drpSubTeam.Selected.Title).LeadEmail`), Due date, Priority. Save → `IntakeWorkPackageChange.Run(varIntake.ID, "Create", JSON({Title: txtWPTitle.Text, Description: txtWPDesc.Text, SubTeam: drpSubTeam.Selected.Title, OwnerEmail: cmbWPOwner.Selected.Mail, Due: Text(dteWPDue.SelectedDate, "yyyy-mm-dd"), Priority: drpWPPriority.Selected.Value}), "", CurrentUserEmail)` (for Create the first argument is the intake ID) – F4 creates the row with the next SortOrder, the WP folder and logs "Work package … created" on the intake.

## Work package screen (`scrWorkPackage`, W08) – team members and managers only
| Area | Content |
|---|---|
| Header | "← Back to {RequestNumber} · WP n of N", package title, status pill |
| galWPStages | Not started → Requirements → In progress → QA/Review → Ready for acceptance → Accepted (Sent back shows as In progress with an amber pill) |
| Parent intake | RequestNumber + title, requestor, intake owner, needed by |
| Work package | sub-team, owner, priority, due, description |
| Tasks | `Filter(IntakeTasks, WorkPackageId = varWP.ID)`; add task sets `WorkPackageId: varWP.ID` |
| Files | `ForAll(Table(ParseJSON(IntakeListFiles.Run(varIntake.RequestNumber & "/WP-" & varWP.ID).files)) As f, {Name: Text(f.Value.name), Url: Text(f.Value.url)})` |
| Actions | `btnWPNext`: "Move to {next}" for the package owner or manager → `IntakeWorkPackageChange.Run(varWP.ID, "Move", <next>, "", CurrentUserEmail)`; comment box; manager panel to edit title, description, sub-team, owner, priority, due, status and to remove the package |
| History | `Filter(IntakeActivity, WorkPackageId = varWP.ID)` |

```
// Next package stage
Switch(varWP.WPStatus.Value,
  "Not started", "Requirements", "Requirements", "In progress", "Sent back", "In progress",
  "In progress", "QA/Review", "QA/Review", "Ready for acceptance", Blank())
// Requestors who reach scrWorkPackage see: "Work packages are managed by the team. You can follow and accept them on your intake's page."
```

## Logging rule (enforced by F4)
On the **intake**: created, removed, sent for the requestor's acceptance, accepted (complete), sent back. In the **package history only**: stage moves, edits, comments and tasks. When the last package is accepted, F4 tells the manager to close the intake.

## Acceptance checks
- Manager adds three packages; numbering follows SortOrder; owner defaults to the sub-team lead.
- Team member moves WP 3 to QA/Review: package history shows it, intake activity does not.
- Moving WP 2 to Ready for acceptance shows Accept/Send back to the requestor and logs on the intake.
- Requestor accepts the last package → manager gets a Teams message; intake stays In Progress until the manager closes it.

## Prompt to paste
```
Build S08 from 02-prompts/S08: the work package overview on scrIntakeDetail (progress, rows with sub-team, owner, due,
task counts, status pill, Accept/Send back for the requestor, Open for the team, Add work package dialog for the manager)
and scrWorkPackage matching wireframe W08 (stage bar, parent intake, package details, tasks, files, actions, history).
All package changes go through IntakeWorkPackageChange.Run. Then run the acceptance checks for Manager, Team Member and Requestor.
```
