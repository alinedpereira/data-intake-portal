import { useQuery } from "@tanstack/react-query";
import { IntakeQuestionRulesService, IntakeQuestionsService } from "../../generated";
import type { IntakeRequest } from "@/lib/intake";

/* Team questions: defined once in IntakeQuestions, attached by IntakeQuestionRules
 * (team / Level 1 / Level 2 / audience), answered into RequestorAnswers or InternalAnswers. */

export type QuestionType = "Text" | "Long text" | "Number" | "Date" | "Choice" | "Yes/No";
export type Audience = "Requestor" | "Internal";
export type AnswerValue = string | number | boolean;

export interface ChoiceOption {
  label: string;
  points?: number;
}

export interface Question {
  key: string;
  label: string;
  type: QuestionType;
  choices: ChoiceOption[];
  help?: string;
  ownerTeam?: string;
}

export interface Rule {
  id: number;
  key: string;
  team?: string;
  level1?: string;
  level2?: string;
  audience: Audience;
  required: boolean;
  scored: boolean;
  order: number;
  showIfKey?: string;
  showIfValue?: string;
}

/** A question as it applies to one intake (question + the rule that brought it in). */
export interface AppliedQuestion extends Question {
  audience: Audience;
  required: boolean;
  scored: boolean;
  order: number;
  showIfKey?: string;
  showIfValue?: string;
}

/** Stored answer: value plus a snapshot of the label (and points) at answer time. */
export interface Answer {
  q: string;
  v: AnswerValue;
  p?: number;
}
export type Answers = Record<string, Answer>;

export interface QuestionConfig {
  questions: Map<string, Question>;
  rules: Rule[];
}

const TYPES: QuestionType[] = ["Text", "Long text", "Number", "Date", "Choice", "Yes/No"];
const clean = (s?: string | null) => s?.trim() || undefined;
const anyValue = (s?: string) => !s || s.toLowerCase() === "any";

function parseChoices(raw?: string): ChoiceOption[] {
  return (raw ?? "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const i = line.lastIndexOf("|");
      if (i > 0) {
        const n = Number(line.slice(i + 1).trim());
        if (Number.isFinite(n)) return { label: line.slice(0, i).trim(), points: n };
      }
      return { label: line };
    });
}

export function useQuestionConfig() {
  return useQuery({
    queryKey: ["question-config"],
    staleTime: 5 * 60_000,
    queryFn: async (): Promise<QuestionConfig> => {
      const [qRes, rRes] = await Promise.all([
        IntakeQuestionsService.getAll({
          select: ["ID", "Title", "QuestionKey", "QuestionType", "Choices", "HelpText", "OwnerTeam", "IsActive"],
          top: 1000,
        }),
        IntakeQuestionRulesService.getAll({
          select: [
            "ID", "QuestionKey", "Team", "RequestTypeL1", "RequestTypeL2", "Audience", "IsRequired", "IsScored",
            "SortOrder", "ShowIfKey", "ShowIfValue", "IsActive",
          ],
          top: 2000,
        }),
      ]);
      if (!qRes.success) throw qRes.error ?? new Error("Questions couldn't be loaded");
      if (!rRes.success) throw rRes.error ?? new Error("Question rules couldn't be loaded");
      const questions = new Map<string, Question>();
      for (const q of qRes.data ?? []) {
        const key = clean(q.QuestionKey);
        if (!key || q.IsActive === false) continue;
        const t = q.QuestionType?.Value as QuestionType | undefined;
        questions.set(key, {
          key,
          label: q.Title,
          type: t && TYPES.includes(t) ? t : "Text",
          choices: parseChoices(q.Choices),
          help: clean(q.HelpText),
          ownerTeam: clean(q.OwnerTeam),
        });
      }
      const rules: Rule[] = (rRes.data ?? [])
        .filter((r) => r.IsActive !== false && clean(r.QuestionKey))
        .map((r) => ({
          id: Number(r.ID),
          key: clean(r.QuestionKey) as string,
          team: clean(r.Team),
          level1: clean(r.RequestTypeL1),
          level2: clean(r.RequestTypeL2),
          audience: r.Audience?.Value === "Internal" ? "Internal" : "Requestor",
          required: !!r.IsRequired,
          scored: !!r.IsScored,
          order: r.SortOrder ?? 0,
          showIfKey: clean(r.ShowIfKey),
          showIfValue: clean(r.ShowIfValue),
        }));
      return { questions, rules };
    },
  });
}

export interface Scope {
  team?: string;
  level1?: string;
  level2?: string;
}

export function scopeOf(r: Pick<IntakeRequest, "RoutedTeam" | "RequestTypeL1" | "RequestTypeL2">): Scope {
  return { team: r.RoutedTeam?.Value, level1: r.RequestTypeL1?.Value, level2: r.RequestTypeL2 };
}

/** Questions that apply to a team + type for one audience, in display order (one per key). */
export function applicable(config: QuestionConfig | undefined, scope: Scope, audience: Audience): AppliedQuestion[] {
  if (!config || !scope.team) return [];
  const matches = (want: string | undefined, have: string | undefined) => anyValue(want) || want === have;
  const specificity = (r: Rule) => (r.team && !anyValue(r.team) ? 1 : 0) + (r.level1 ? 1 : 0) + (r.level2 ? 2 : 0);
  const best = new Map<string, Rule>();
  for (const r of config.rules) {
    if (r.audience !== audience) continue;
    if (!matches(r.team, scope.team) || !matches(r.level1, scope.level1) || !matches(r.level2, scope.level2)) continue;
    const prev = best.get(r.key);
    if (!prev || specificity(r) > specificity(prev)) best.set(r.key, r);
  }
  const out: AppliedQuestion[] = [];
  for (const r of best.values()) {
    const q = config.questions.get(r.key);
    if (!q) continue;
    out.push({ ...q, audience, required: r.required, scored: r.scored, order: r.order, showIfKey: r.showIfKey, showIfValue: r.showIfValue });
  }
  return out.sort((a, b) => a.order - b.order || a.label.localeCompare(b.label));
}

/** True if the team has any scored question (for any type). */
export function teamHasScoring(config: QuestionConfig | undefined, team: string | undefined): boolean {
  return !!team && !!config?.rules.some((r) => r.scored && (r.team === team || anyValue(r.team)));
}

/** Teams that score their intakes (they get a prioritization queue). */
export function scoringTeams(config: QuestionConfig | undefined): string[] {
  return [...new Set((config?.rules ?? []).filter((r) => r.scored && r.team && !anyValue(r.team)).map((r) => r.team as string))];
}

export function parseAnswers(raw: string | undefined): Answers {
  if (!raw) return {};
  try {
    const v: unknown = JSON.parse(raw);
    if (!v || typeof v !== "object" || Array.isArray(v)) return {};
    const out: Answers = {};
    for (const [k, a] of Object.entries(v as Record<string, unknown>)) {
      if (!a || typeof a !== "object") continue;
      const { q, v: val, p } = a as Record<string, unknown>;
      if (typeof val !== "string" && typeof val !== "number" && typeof val !== "boolean") continue;
      out[k] = { q: typeof q === "string" ? q : k, v: val, ...(typeof p === "number" ? { p } : {}) };
    }
    return out;
  } catch {
    return {};
  }
}

/* ---- form values: everything is a string while editing ---- */

export type Draft = Record<string, string>;

export function toInput(q: Pick<Question, "type">, v: AnswerValue | undefined): string {
  if (v === undefined) return "";
  if (q.type === "Yes/No") return v === true || v === "true" || v === "Yes" ? "Yes" : v === false || v === "false" || v === "No" ? "No" : "";
  return String(v);
}

function fromInput(q: Question, s: string): AnswerValue | undefined {
  const t = s.trim();
  if (!t) return undefined;
  if (q.type === "Yes/No") return t === "Yes";
  if (q.type === "Number") {
    const n = Number(t);
    return Number.isFinite(n) ? n : undefined;
  }
  return t;
}

export function draftFrom(questions: AppliedQuestion[], answers: Answers): Draft {
  return Object.fromEntries(questions.map((q) => [q.key, toInput(q, answers[q.key]?.v)]));
}

/** Show-if: only shown when another answer in the draft equals the given value. */
export function isShown(q: AppliedQuestion, draft: Draft): boolean {
  if (!q.showIfKey) return true;
  return (draft[q.showIfKey] ?? "").trim().toLowerCase() === (q.showIfValue ?? "").trim().toLowerCase();
}

export function missingRequired(questions: AppliedQuestion[], draft: Draft): AppliedQuestion[] {
  return questions.filter((q) => q.required && isShown(q, draft) && !(draft[q.key] ?? "").trim());
}

export function invalidNumbers(questions: AppliedQuestion[], draft: Draft): AppliedQuestion[] {
  return questions.filter((q) => q.type === "Number" && (draft[q.key] ?? "").trim() !== "" && !Number.isFinite(Number(draft[q.key])));
}

/** Merge a draft into stored answers. Answers to questions outside this set are kept. */
export function mergeAnswers(questions: AppliedQuestion[], draft: Draft, previous: Answers): Answers {
  const next: Answers = { ...previous };
  for (const q of questions) {
    const v = isShown(q, draft) ? fromInput(q, draft[q.key] ?? "") : undefined;
    if (v === undefined) {
      delete next[q.key];
      continue;
    }
    const points = q.type === "Choice" ? q.choices.find((c) => c.label === v)?.points : undefined;
    next[q.key] = { q: q.label, v, ...(points !== undefined ? { p: points } : {}) };
  }
  return next;
}

/** Labels of the questions whose value differs between two answer sets. */
export function changedLabels(questions: AppliedQuestion[], before: Answers, after: Answers): string[] {
  return questions.filter((q) => before[q.key]?.v !== after[q.key]?.v).map((q) => q.label);
}

/** Sum of points over scored questions; undefined until every scored question has a pointed answer. */
export function scoreOf(questions: AppliedQuestion[], answers: Answers): number | undefined {
  const scored = questions.filter((q) => q.scored);
  if (scored.length === 0) return undefined;
  let total = 0;
  for (const q of scored) {
    const a = answers[q.key];
    const p = a?.p ?? q.choices.find((c) => c.label === a?.v)?.points;
    if (p === undefined) return undefined;
    total += p;
  }
  return total;
}

export function formatAnswer(type: QuestionType | undefined, v: AnswerValue | undefined): string | undefined {
  if (v === undefined || v === "") return undefined;
  if (typeof v === "boolean") return v ? "Yes" : "No";
  if (type === "Number" && typeof v === "number") return v.toLocaleString();
  if (type === "Date" && typeof v === "string" && /^\d{4}-\d{2}-\d{2}/.test(v)) {
    const d = new Date(`${v.slice(0, 10)}T12:00:00Z`);
    if (!Number.isNaN(d.getTime())) return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  }
  return typeof v === "number" ? v.toLocaleString() : String(v);
}
