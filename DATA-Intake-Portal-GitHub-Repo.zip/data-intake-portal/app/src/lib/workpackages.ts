import { useQuery } from "@tanstack/react-query";
import { IntakeRequestsService, IntakeSubTeamsService, IntakeWorkPackagesService } from "../../generated";
import type { IntakeWorkPackagesRead, IntakeWorkPackagesWrite } from "../../generated/models/IntakeWorkPackagesModel";
import { appendLog, odataString, updateRequest, type IntakeRequest } from "@/lib/intake";
import { queryClient } from "@/lib/query-client";

export type WorkPackage = IntakeWorkPackagesRead;
export type WorkPackageWrite = Partial<Omit<IntakeWorkPackagesWrite, "ID">>;

/** Routed team that uses work packages (POC). */
export const WP_TEAM = "Customer Analytics";

export const WP_STATUSES = ["Not started", "Requirements", "In progress", "QA/Review", "Ready for acceptance", "Accepted", "Sent back"] as const;
export type WpStatus = (typeof WP_STATUSES)[number];

/** Stages on a work package's progress bar ("Sent back" sits at In progress). */
export const WP_STAGES = ["Not started", "Requirements", "In progress", "QA/Review", "Ready for acceptance", "Accepted"] as const;

/** Next stage the owner (or manager) can move a work package to; acceptance is the requestor's. */
export const WP_NEXT: Partial<Record<WpStatus, WpStatus>> = {
  "Not started": "Requirements",
  Requirements: "In progress",
  "Sent back": "In progress",
  "In progress": "QA/Review",
  "QA/Review": "Ready for acceptance",
};

/** Where a status sits on the progress bar. */
export function wpStage(s: WpStatus): string {
  return s === "Sent back" ? "In progress" : s;
}

export function usesWorkPackages(r: Pick<IntakeRequest, "RoutedTeam">): boolean {
  return r.RoutedTeam?.Value === WP_TEAM;
}

export function wpStatusOf(w: WorkPackage): WpStatus {
  const v = w.WPStatus?.Value as WpStatus | undefined;
  return v && (WP_STATUSES as readonly string[]).includes(v) ? v : "Not started";
}

export function wpNumber(w: WorkPackage, index: number): string {
  return `WP ${index + 1}`;
}

export interface SubTeam {
  name: string;
  leadName: string;
  leadEmail: string;
}

/** Sub-teams of a routed team, from the IntakeSubTeams SharePoint list. */
export function useSubTeams(parentTeam = WP_TEAM) {
  return useQuery({
    queryKey: ["sub-teams", parentTeam],
    staleTime: 5 * 60 * 1000,
    queryFn: async (): Promise<SubTeam[]> => {
      const res = await IntakeSubTeamsService.getAll({
        select: ["Title", "ParentTeam", "LeadName", "LeadEmail"],
        filter: `ParentTeam eq ${odataString(parentTeam)}`,
        top: 200,
      });
      if (!res.success) {
        console.error("sub-teams load failed", res.error);
        throw new Error("Unable to load sub-teams.");
      }
      return (res.data ?? [])
        .filter((s) => s.Title)
        .map((s) => ({ name: s.Title.trim(), leadName: (s.LeadName ?? "").trim(), leadEmail: (s.LeadEmail ?? "").trim() }));
    },
  });
}

const WP_SELECT = [
  "ID",
  "Title",
  "RequestItemId",
  "RequestNumber",
  "WPDescription",
  "SubTeam",
  "WPOwner",
  "WPDueDate",
  "SortOrder",
  "WPStatus",
  "WPActivity",
  "WPPriority",
  "Modified",
];

function byOrder(a: WorkPackage, b: WorkPackage) {
  return (a.SortOrder ?? 999) - (b.SortOrder ?? 999) || (a.ID ?? 0) - (b.ID ?? 0);
}

async function loadWorkPackages(filter: string): Promise<WorkPackage[]> {
  const res = await IntakeWorkPackagesService.getAll({ select: WP_SELECT, filter, top: 500 });
  if (!res.success) {
    console.error("work packages load failed", res.error);
    throw new Error("Unable to load work packages.");
  }
  return (res.data ?? []).sort(byOrder);
}

/** Work packages for one intake, in order. */
export function useWorkPackages(requestId: number | undefined) {
  return useQuery({
    queryKey: ["workpackages", "intake", requestId],
    enabled: !!requestId,
    staleTime: 30_000,
    refetchInterval: 30_000,
    queryFn: () => loadWorkPackages(`RequestItemId eq ${Number(requestId)}`),
  });
}

/** Work packages owned by one person (the team member's queue). */
export function useMyWorkPackages(email: string | undefined) {
  return useQuery({
    queryKey: ["workpackages", "owner", email?.toLowerCase()],
    enabled: !!email,
    staleTime: 30_000,
    refetchInterval: 30_000,
    queryFn: () => loadWorkPackages(`WPOwner/EMail eq ${odataString(email as string)}`),
  });
}

/** One work package by id. */
export function useWorkPackage(id: number | undefined) {
  return useQuery({
    queryKey: ["workpackages", "one", id],
    enabled: !!id,
    staleTime: 30_000,
    refetchInterval: 30_000,
    queryFn: async () => {
      const rows = await loadWorkPackages(`ID eq ${Number(id)}`);
      if (!rows[0]) throw new Error("Work package not found.");
      return rows[0];
    },
  });
}

export interface WpSummary {
  total: number;
  accepted: number;
  ready: number;
}

/** Accepted / total counts for a set of intakes (for list rows). */
export function useWorkPackageSummary(ids: number[]) {
  const key = [...ids].sort((a, b) => a - b).slice(0, 50);
  return useQuery({
    queryKey: ["workpackages", "summary", key],
    enabled: key.length > 0,
    staleTime: 30_000,
    queryFn: async () => {
      const rows = await loadWorkPackages(`(${key.map((id) => `RequestItemId eq ${id}`).join(" or ")})`);
      const map = new Map<number, WpSummary>();
      for (const w of rows) {
        const id = w.RequestItemId;
        if (!id) continue;
        const s = map.get(id) ?? { total: 0, accepted: 0, ready: 0 };
        s.total += 1;
        if (wpStatusOf(w) === "Accepted") s.accepted += 1;
        if (wpStatusOf(w) === "Ready for acceptance") s.ready += 1;
        map.set(id, s);
      }
      return map;
    },
  });
}

export function invalidateWorkPackages() {
  void queryClient.invalidateQueries({ queryKey: ["workpackages"] });
}

export async function createWorkPackage(record: Omit<IntakeWorkPackagesWrite, "ID">): Promise<WorkPackage> {
  const res = await IntakeWorkPackagesService.create(record);
  if (!res.success) {
    console.error("work package create failed", res.error);
    throw new Error("The work package could not be created.");
  }
  return res.data;
}

export async function updateWorkPackage(id: number, changes: WorkPackageWrite): Promise<WorkPackage> {
  const res = await IntakeWorkPackagesService.update(String(id), changes);
  if (!res.success) {
    console.error("work package update failed", res.error);
    throw new Error("The work package could not be saved.");
  }
  return res.data;
}

export async function deleteWorkPackage(id: number): Promise<void> {
  try {
    await IntakeWorkPackagesService.delete(String(id));
  } catch (e) {
    console.error("work package delete failed", e);
    throw new Error("The work package could not be deleted.");
  }
}

/** Append an entry to the intake's activity history, reading the latest log first. */
export async function logToIntake(requestId: number, entry: { by: string; role: string; text: string }): Promise<void> {
  const res = await IntakeRequestsService.getAll({ select: ["ID", "ActivityLog"], filter: `ID eq ${Number(requestId)}`, top: 1 });
  const current = res.success ? (res.data ?? [])[0]?.ActivityLog : undefined;
  await updateRequest(requestId, { ActivityLog: appendLog(current, { at: new Date().toISOString(), ...entry }) });
  void queryClient.invalidateQueries({ queryKey: ["request", String(requestId)] });
}

/** Folder for one work package's files, inside its intake's folder. */
export function wpFolder(requestNo: string, wpId: number): string {
  return `${requestNo}/WP-${wpId}`;
}
