import { useQuery } from "@tanstack/react-query";
import { IntakeTeamsService } from "../../generated";
import { odataString } from "@/lib/intake";
import { useAppStore } from "@/lib/store";
import { emailFor } from "@/config";

export interface TeamRow {
  team: string;
  managerName: string;
  managerEmail: string;
  /** Business focus area that routes to this team (IntakeTeams.FocusArea), if any. */
  focusArea?: string;
}

export interface TeamManager {
  name: string;
  email: string;
  teams: string[];
}

/** Read routed teams and their managers from the IntakeTeams SharePoint list. */
export async function loadTeams(): Promise<TeamRow[]> {
  const result = await IntakeTeamsService.getAll({ select: ["Title", "ManagerName", "ManagerEmail", "FocusArea"], top: 500 });
  if (!result.success) {
    console.error("teams load failed", result.error);
    throw new Error("Unable to load teams.");
  }
  return (result.data ?? [])
    .filter((r) => r.Title && r.ManagerName && r.ManagerEmail)
    .map((r) => ({
      team: r.Title.trim(),
      managerName: (r.ManagerName ?? "").trim(),
      managerEmail: (r.ManagerEmail ?? "").trim(),
      focusArea: r.FocusArea?.trim() || undefined,
    }));
}

export const TEAMS_KEY = ["intake-teams"] as const;

/** Routed teams and their managers, from the IntakeTeams SharePoint list. */
export function useTeams() {
  return useQuery({ queryKey: TEAMS_KEY, staleTime: 5 * 60 * 1000, queryFn: loadTeams });
}

/** One entry per manager (by email) with the teams they manage, sorted by name. */
export function managersOf(rows: TeamRow[] | undefined): TeamManager[] {
  const byEmail = new Map<string, TeamManager>();
  for (const r of rows ?? []) {
    const key = r.managerEmail.toLowerCase();
    const m = byEmail.get(key) ?? { name: r.managerName, email: r.managerEmail, teams: [] };
    m.teams.push(r.team);
    byEmail.set(key, m);
  }
  return [...byEmail.values()].sort((a, b) => a.name.localeCompare(b.name));
}

export function teamManagerName(rows: TeamRow[] | undefined, team: string | undefined): string | undefined {
  if (!team) return undefined;
  return rows?.find((r) => r.team === team)?.managerName;
}

/** OData filter matching requests routed to any of these teams. */
export function teamsFilter(teams: string[]): string {
  if (teams.length === 0) return "ID eq 0";
  return `(${teams.map((t) => `RoutedTeam eq ${odataString(t)}`).join(" or ")})`;
}

/** Manager picked by default in Manager view for this POC. */
export const DEFAULT_MANAGER_EMAIL = emailFor(import.meta.env.VITE_DEFAULT_MANAGER_ALIAS ?? "andrel");


/** Teams managed by the manager picked in the header (empty until both load). */
export function useMyManagedTeams(): { teams: string[]; isPending: boolean; isError: boolean } {
  const q = useTeams();
  const manager = useAppStore((s) => s.manager);
  const mine = managersOf(q.data).find((m) => m.email.toLowerCase() === (manager?.email ?? "").toLowerCase());
  return { teams: mine?.teams ?? [], isPending: q.isPending, isError: q.isError };
}
