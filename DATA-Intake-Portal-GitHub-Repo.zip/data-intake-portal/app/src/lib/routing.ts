import { useQuery } from "@tanstack/react-query";
import { IntakeRequestTypesService } from "../../generated";
import { useTeams, type TeamRow } from "@/lib/teams";

/** One offered Level 1 + Level 2 combination, from the IntakeRequestTypes list. */
export interface RequestType {
  id: number;
  level1: string;
  level2: string;
  /** Team it routes to, unless the business focus area decides. */
  team?: string;
  askFocusArea: boolean;
  order: number;
}

export function useRequestTypes() {
  return useQuery({
    queryKey: ["request-types"],
    staleTime: 5 * 60_000,
    queryFn: async (): Promise<RequestType[]> => {
      const res = await IntakeRequestTypesService.getAll({
        select: ["ID", "Title", "Level1", "DefaultTeam", "AskFocusArea", "SortOrder", "IsActive"],
        top: 500,
      });
      if (!res.success) throw res.error ?? new Error("Intake types couldn't be loaded");
      return (res.data ?? [])
        .filter((t) => t.IsActive !== false && t.Title && t.Level1)
        .map((t) => ({
          id: Number(t.ID),
          level1: (t.Level1 as string).trim(),
          level2: t.Title.trim(),
          team: t.DefaultTeam?.trim() || undefined,
          askFocusArea: !!t.AskFocusArea,
          order: t.SortOrder ?? 0,
        }))
        .sort((a, b) => a.order - b.order || a.id - b.id);
    },
  });
}

export interface Routing {
  isPending: boolean;
  isError: boolean;
  refetch: () => void;
  level1Options: string[];
  level2Options: (level1: string) => string[];
  teamOptions: string[];
  focusAreaOptions: string[];
  needsFocusArea: (level1: string, level2: string) => boolean;
  /** Team the types (and focus area) route to, if the lists say so. */
  suggestTeam: (level1: string, level2: string, focusArea?: string) => string | undefined;
}

export function routingFrom(types: RequestType[] | undefined, teams: TeamRow[] | undefined) {
  const t = types ?? [];
  const find = (l1: string, l2: string) => t.find((x) => x.level1 === l1 && x.level2 === l2);
  return {
    level1Options: [...new Set(t.map((x) => x.level1))],
    level2Options: (l1: string) => t.filter((x) => x.level1 === l1).map((x) => x.level2),
    teamOptions: (teams ?? []).map((x) => x.team),
    focusAreaOptions: (teams ?? []).flatMap((x) => (x.focusArea ? [x.focusArea] : [])),
    needsFocusArea: (l1: string, l2: string) => !!find(l1, l2)?.askFocusArea,
    suggestTeam: (l1: string, l2: string, area?: string) => {
      const type = find(l1, l2);
      if (!type) return undefined;
      if (type.askFocusArea) return area ? teams?.find((x) => x.focusArea === area)?.team : undefined;
      return type.team;
    },
  };
}

/** Intake types, routing and focus areas, all read from SharePoint lists. */
export function useRouting(): Routing {
  const typesQ = useRequestTypes();
  const teamsQ = useTeams();
  return {
    isPending: typesQ.isPending || teamsQ.isPending,
    isError: typesQ.isError || teamsQ.isError,
    refetch: () => {
      void typesQ.refetch();
      void teamsQ.refetch();
    },
    ...routingFrom(typesQ.data, teamsQ.data),
  };
}
