# S05 – Intake detail (shared screen, all roles)

**Wireframes:** `W05-intake-detail-requestor.png` (requestor), `W06-intake-detail-manager.png` (manager)
**Original reference:** `R01-intake-detail-progress-design.png`
**Depends on:** S01; flows F2 (`IntakeChangeStage`), F6 (`IntakeAskRequestor`), `IntakeListFiles`

## Goal
One screen that shows an intake to every role: header, stage bar, work-package overview (when present), detail sections, the team's requestor questions, internal details (team only), files, role actions and activity. Manager-only parts are built in S06, team-member actions and tasks in S07, work packages in S08; this prompt builds the frame and the shared parts.

## Layout
- Header: RequestNumber (blue), Title (30 pt), status pill right.
- `conStages`: "Where this intake is in the process" + `galStages`.
- `conWorkPackages` (S08) – only when the intake has packages.
- Two columns below: left 56 % = details (`conDetails`), requestor answers (`galRequestorAnswers`), internal details (`conInternal`, S06), files (`galFiles`); right 44 % = actions (`conActions`) and activity (`galActivity`).

## Formulas
```
// App.Formulas (stage order is lifecycle behaviour, defined once here)
StandardStages = ["Submitted", "Queued", "Assigned / Under Review", "Requirements sign-off", "Approved",
                  "In Progress", "QA Testing", "DML Approval", "Acceptance sign-off", "Closed"];
IaapStages = ["Submitted", "Queued", "In Progress", "DML Approval", "Closed"];

// Screen OnVisible – refresh, work out QA/DML/IAAP and build the stage bar
Set(varIntake, LookUp(IntakeRequests, ID = varIntake.ID));
Set(varIsIaap, varIntake.RequestTypeL1.Value = "Data Risk Assessment" && varIntake.RequestTypeL2 = "IAAP Request");
Set(varNeedsQa,
    !IsBlank(LookUp(colQAConfig, Level1 = varIntake.RequestTypeL1.Value && Level2 = varIntake.RequestTypeL2 && RequiresQA))
    || !IsEmpty(Filter(IntakeTasks, RequestItemId = varIntake.ID, WorkPackageId = 0, TaskType.Value = "QA/Testing")));
ClearCollect(colStages,
    If(varIsIaap, IaapStages,
       Filter(StandardStages,
          Value <> "QA Testing" || varNeedsQa || varIntake.Status.Value = "QA Testing",
          Value <> "DML Approval" || varIntake.RequestTypeL1.Value = "Data Risk Assessment")));
ClearCollect(colStagesN, ForAll(Sequence(CountRows(colStages)) As i, {Stage: Index(colStages, i.Value).Value, N: i.Value}));
Set(varStageN, LookUp(colStagesN, Stage = varIntake.Status.Value).N);
Set(varLocked, varIntake.Status.Value in ["Acceptance sign-off", "Closed"]);
Set(varIsOwner, Lower(varIntake.Owner.Email) = CurrentUserEmail);
Set(varIsTeamManager, !IsBlank(LookUp(MyManagedTeams, Title = varIntake.RoutedTeam.Value)));

// galStages.Items = colStagesN (horizontal gallery, one circle per stage)
// circle Fill:  If(ThisItem.N = varStageN, clrBlue, ThisItem.N < varStageN, clrGreen, White)
// circle text:  If(ThisItem.N < varStageN, "✓", Text(ThisItem.N))
// label:        ThisItem.Stage (bold when current)

// Requestor answers (all roles) – join applicable questions to stored answers
ClearCollect(colReqAnswers, Filter(IntakeAnswers, RequestItemId = varIntake.ID));
// build colAppliedDetail with the same rule-matching formula as S03 but using varIntake's team/L1/L2 and Audience "Requestor"
// galRequestorAnswers.Items
AddColumns(SortByColumns(colAppliedDetail, "SortOrder"), Ans, LookUp(colReqAnswers, QuestionKey = ThisRecord.QuestionKey).AnswerValue)
// Answers on file whose question no longer applies (after a re-route): show under "Also on file"
Filter(colReqAnswers, !(QuestionKey in colAppliedDetail.QuestionKey))

// galActivity.Items – requestors never see internal entries
SortByColumns(Filter(IntakeActivity, RequestItemId = varIntake.ID, varRole <> "Requestor" || !IsInternal), "Created", SortOrder.Descending)
// subtitle: ThisItem.ActorName & " · " & ThisItem.ActorRole & " · " & Text(ThisItem.Created, "d mmm yyyy h:mm")

// galFiles.Items – folder listing via a flow (library folder filters are not delegable)
ForAll(Table(ParseJSON(IntakeListFiles.Run(varIntake.RequestNumber).files)) As f,
    {Name: Text(f.Value.name), Url: Text(f.Value.url)})   // the flow returns a JSON text array
```

Note: "Data Risk Assessment", "IAAP Request" and the stage names are lifecycle rules. They stay in the app (and in F2) by decision, as in the POC. Everything team- or question-specific stays in configuration lists.

## Requestor actions (right column, requestor only)
```
// btnAddComment.OnSelect – comments are activity rows written by a flow
IntakeAskRequestor.Run(varIntake.ID, "Comment", txtComment.Text, CurrentUserEmail); Reset(txtComment)

// btnSignOffReq.DisplayMode
If(varIntake.Status.Value = "Requirements sign-off", DisplayMode.Edit, DisplayMode.Disabled)
// btnSignOffReq.OnSelect
Set(varResult, IntakeChangeStage.Run(varIntake.ID, "Move", "Approved", "", CurrentUserEmail));
If(varResult.ok = "true", Set(varIntake, LookUp(IntakeRequests, ID = varIntake.ID)), Notify(varResult.message, NotificationType.Error))

// btnSignOffAcc: same pattern with "Closed" when Status = "Acceptance sign-off"
// btnSendBack: opens a reason dialog, then IntakeChangeStage.Run(varIntake.ID, "Move", <send-back target>, txtReason.Text, CurrentUserEmail)
//   target = "Assigned / Under Review" from Requirements sign-off, "In Progress" from Acceptance sign-off

// Ask-the-requestor banner (requestor): visible when varIntake.AwaitingRequestor
// shows varIntake.OpenQuestion, a text box and btnAnswer:
IntakeAskRequestor.Run(varIntake.ID, "Answer", txtAnswer.Text, CurrentUserEmail)
```
IAAP intakes show "IAAP intakes don't need sign-off" instead of the sign-off buttons.

## Acceptance checks
- Requestor on INT-…-00037: stage bar at In Progress, work packages visible, no internal panel, activity has no internal rows.
- Manager on the same intake sees internal details and internal activity rows (blue "Internal" caption).
- A Data Quality intake does not show QA or DML stages unless configured; an IAAP intake shows the five-stage lifecycle.
- Sign-off buttons are enabled only at the right stage; send-back requires a reason.

## Prompt to paste
```
Build scrIntakeDetail (S05) to match wireframes W05 (requestor) and W06 (manager) and reference R01. Implement OnVisible,
the stage bar galStages, the detail sections in conDetails (Requestor, Routing, Dates priority and value), the requestor
answers gallery (same rule matching as S03 but for the intake's team and type, plus an "Also on file" list), galFiles via
IntakeListFiles, galActivity with the internal filter, and the requestor actions (comment, requirements sign-off, acceptance
sign-off, send back with reason, answer an open question) exactly as in 02-prompts/S05. Leave placeholders conInternal,
conManagerActions, conTeamActions and conWorkPackages for S06–S08. Then run the acceptance checks.
```
