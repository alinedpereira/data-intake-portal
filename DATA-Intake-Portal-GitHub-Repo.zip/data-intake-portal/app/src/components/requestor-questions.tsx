import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageCircleQuestionMark } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { REJECTED, appendLog, formatDate, statusOf, updateRequest, type IntakeRequest, type IntakeWrite } from "@/lib/intake";
import { daysWaiting, isAwaitingRequestor } from "@/lib/questions";
import { actorName, roleLabel, useAppStore } from "@/lib/store";

/** Questions from the team to the requestor, and the requestor's reply. Doesn't change the stage. */
export function RequestorQuestions({ r }: { r: IntakeRequest }) {
  const role = useAppStore((s) => s.role);
  const actor = useAppStore(actorName);
  const qc = useQueryClient();
  const awaiting = isAwaitingRequestor(r);
  const s = statusOf(r);
  const open = s !== "Closed" && s !== REJECTED;
  const [asking, setAsking] = useState(false);
  const [text, setText] = useState("");
  const [tried, setTried] = useState(false);

  const save = useMutation({
    mutationFn: ({ changes, note }: { changes: Partial<Omit<IntakeWrite, "ID">>; note: string }) =>
      updateRequest(r.ID as number, {
        ...changes,
        ActivityLog: appendLog(r.ActivityLog, { at: new Date().toISOString(), by: actor, role, text: note }),
      }),
    onSuccess: (_d, { note }) => {
      void qc.invalidateQueries({ queryKey: ["request", String(r.ID)] });
      void qc.invalidateQueries({ queryKey: ["requests"] });
      toast.success(note.startsWith("Requestor answered") ? "Answer sent" : note.startsWith("Question") ? "Question sent to the requestor" : "Saved");
      setText("");
      setAsking(false);
      setTried(false);
    },
    onError: () => toast.error("That couldn't be saved. Please try again."),
  });

  const submit = (fn: (t: string) => void) => (e: React.FormEvent) => {
    e.preventDefault();
    setTried(true);
    if (text.trim()) fn(text.trim());
  };
  const missing = tried && !text.trim();
  const d = daysWaiting(r);
  const askedLine = `Asked by ${r.QuestionAskedBy || "the team"} on ${formatDate(r.QuestionAskedOn)}${d ? ` · waiting ${d} day${d === 1 ? "" : "s"}` : ""}`;

  // Requestor with an open question: highlighted box with a reply form.
  if (role === "Requestor") {
    if (awaiting) {
      return (
        <section aria-labelledby="q-h" className="space-y-3 rounded-lg border-2 border-amber-500 bg-amber-50 p-4 dark:bg-amber-950">
          <h2 id="q-h" className="flex items-center gap-2 font-semibold">
            <MessageCircleQuestionMark className="size-5 text-amber-700 dark:text-amber-300" aria-hidden="true" /> The team has a question for you
          </h2>
          <p className="whitespace-pre-wrap rounded-md bg-card p-3 text-sm">{r.OpenQuestion}</p>
          <p className="text-xs text-muted-foreground">{askedLine}</p>
          <form onSubmit={submit((t) => save.mutate({
            changes: { AwaitingRequestor: false, RequestorAnswer: t, AnsweredOn: new Date().toISOString() },
            note: `Requestor answered: ${t}`,
          }))} className="space-y-2">
            <Label htmlFor="q-reply">Your answer</Label>
            <Textarea id="q-reply" rows={4} value={text} onChange={(e) => setText(e.target.value)} aria-invalid={missing} className="bg-card" />
            {missing && <p role="alert" className="text-sm text-destructive">Type your answer first.</p>}
            <Button type="submit" disabled={save.isPending}>{save.isPending ? "Sending…" : "Send answer"}</Button>
          </form>
        </section>
      );
    }
    return r.RequestorAnswer ? <LastExchange r={r} /> : null;
  }

  // Team member / manager.
  return (
    <section aria-labelledby="q-h" className="space-y-3 rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 id="q-h" className="flex items-center gap-2 font-semibold">
          <MessageCircleQuestionMark className="size-5 text-primary" aria-hidden="true" /> Questions for the requestor
        </h2>
        {open && !awaiting && !asking && (
          <Button size="sm" onClick={() => setAsking(true)}>Ask the requestor</Button>
        )}
      </div>

      {awaiting ? (
        <div className="space-y-2 rounded-md border-l-4 border-amber-500 bg-amber-50 p-3 dark:bg-amber-950">
          <p className="text-sm font-semibold">Waiting on the requestor</p>
          <p className="whitespace-pre-wrap text-sm">{r.OpenQuestion}</p>
          <p className="text-xs text-muted-foreground">{askedLine}</p>
          <Button
            size="sm"
            variant="outline"
            disabled={save.isPending}
            onClick={() => save.mutate({ changes: { AwaitingRequestor: false }, note: "Question to requestor withdrawn" })}
          >
            Withdraw question
          </Button>
        </div>
      ) : asking ? (
        <form onSubmit={submit((t) => save.mutate({
          changes: { AwaitingRequestor: true, OpenQuestion: t, QuestionAskedOn: new Date().toISOString(), QuestionAskedBy: `${actor} (${roleLabel(role)})`, RequestorAnswer: "" },
          note: `Question for the requestor: ${t}`,
        }))} className="space-y-2">
          <Label htmlFor="q-ask">Your question(s)</Label>
          <Textarea id="q-ask" rows={4} value={text} onChange={(e) => setText(e.target.value)} aria-invalid={missing} aria-describedby="q-ask-hint" />
          <p id="q-ask-hint" className="text-xs text-muted-foreground">The intake is flagged "Waiting on requestor" until they answer. The stage doesn't change.</p>
          {missing && <p role="alert" className="text-sm text-destructive">Type the question first.</p>}
          <div className="flex flex-wrap gap-2">
            <Button type="submit" disabled={save.isPending}>{save.isPending ? "Sending…" : "Send to requestor"}</Button>
            <Button type="button" variant="outline" onClick={() => { setAsking(false); setTried(false); }}>Cancel</Button>
          </div>
        </form>
      ) : r.RequestorAnswer ? (
        <LastExchange r={r} />
      ) : (
        <p className="text-sm text-muted-foreground">No open questions. Every question and answer is also kept in the activity history.</p>
      )}
    </section>
  );
}

function LastExchange({ r }: { r: IntakeRequest }) {
  return (
    <div className="space-y-2 rounded-md border border-border bg-muted/40 p-3 text-sm">
      <p className="font-semibold">Latest question and answer</p>
      {r.OpenQuestion && <p className="whitespace-pre-wrap"><span className="font-semibold">Q: </span>{r.OpenQuestion}</p>}
      <p className="whitespace-pre-wrap"><span className="font-semibold">A: </span>{r.RequestorAnswer}</p>
      <p className="text-xs text-muted-foreground">Answered {formatDate(r.AnsweredOn)}</p>
    </div>
  );
}
