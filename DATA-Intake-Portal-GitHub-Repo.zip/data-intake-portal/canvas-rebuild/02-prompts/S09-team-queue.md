# S09 – Intakes & tasks (team queue for managers and team members)

**Wireframe:** `W09-team-queue-manager.png`
**Depends on:** S01, S05

## Goal
Managers see their team's intakes (and a Tasks tab); team members see intakes and work packages they own. Date-range and status filters; row click opens the intake.

## Controls
| Control | Behaviour |
|---|---|
| lblHeading | Manager: `Concat(MyManagedTeams, Title, ", ") & " - Intakes & tasks"`; Team member: "My Work Queue" |
| drpMyTeam | Manager of more than one team picks the team (keeps the filter delegable) |
| drpDateRange | Last 30 / 90 / 365 days / All time on SubmittedOn; "Also show intakes still being worked on" checkbox |
| drpStatus | All open, each stage, Closed |
| tabQueue | "My team's intakes" / "My team's tasks" (tasks tab reuses galTeamTasks from S07) |
| galTeamQueue | Intake #, Title, Status pill, Priority, Requestor, Owner, Needed by, Tasks (done of total, intake-level only) |
| galMyWorkPackages (team member) | Packages where `WPOwner.Email = User().Email` and status is not Accepted, linking to scrWorkPackage |

## Formulas
```
// galTeamQueue.Items (manager)
With({team: Coalesce(drpMyTeam.Selected.Title, First(MyManagedTeams).Title),
      since: Switch(drpDateRange.Selected.Value, "Last 30 days", Today() - 30, "Last 90 days", Today() - 90, "Last 365 days", Today() - 365, Date(2000,1,1))},
  SortByColumns(
    Filter(IntakeRequests, RoutedTeam.Value = team,
        SubmittedOn >= since || (chkStillOpen.Value && Status.Value <> "Closed"),
        drpStatus.Selected.Value = "All open" && Status.Value <> "Closed" || Status.Value = drpStatus.Selected.Value),
    "NeededBy", SortOrder.Ascending))
// galTeamQueue.Items (team member)
Filter(IntakeRequests, Owner.Email = User().Email, Status.Value <> "Closed")
// Tasks cell (intake-level only)
With({t: Filter(IntakeTasks, RequestItemId = ThisItem.ID, WorkPackageId = 0)},
  CountRows(Filter(t, TaskStatus.Value = "Done")) & " of " & CountRows(t))
// OnSelect
Set(varIntake, ThisItem); Navigate(scrIntakeDetail)
```
Show a "Showing the latest 500" note if the gallery hits the data row limit.

## Acceptance checks
- The OMP manager sees only OMP intakes; a manager of two teams can switch.
- Team member sees only intakes they own plus their open work packages.
- Status and date filters combine correctly; rows open the intake.

## Prompt to paste
```
Build scrTeamQueue (S09) matching wireframe W09 using the formulas in 02-prompts/S09: heading with the manager's team(s),
team picker for multi-team managers, date-range and status filters, intakes/tasks tabs, and galTeamQueue. For team members,
show their owned intakes and galMyWorkPackages. Keep all filters delegable. Then run the acceptance checks for both roles.
```
