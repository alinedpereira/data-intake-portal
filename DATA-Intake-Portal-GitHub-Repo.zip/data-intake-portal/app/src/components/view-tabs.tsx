import type { ComponentProps } from "react";
import { TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

/** Prominent view switcher used for every Requests/Tasks toggle in the app. */
export function ViewTabsList({ className, ...props }: ComponentProps<typeof TabsList>) {
  return (
    <TabsList
      className={cn(
        "gap-1 rounded-lg border border-border bg-card p-1 shadow-sm group-data-[orientation=horizontal]/tabs:h-auto",
        className,
      )}
      {...props}
    />
  );
}

export function ViewTabsTrigger({ className, ...props }: ComponentProps<typeof TabsTrigger>) {
  return (
    <TabsTrigger
      className={cn(
        "h-auto px-5 py-2 text-sm font-semibold text-foreground/80 hover:bg-muted hover:text-foreground",
        "data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-sm data-[state=active]:hover:bg-primary",
        className,
      )}
      {...props}
    />
  );
}
