# Solution overview

## Purpose
One front door for analytics and data-governance requests ("intakes"). Each intake is routed to a team, worked through a lifecycle, and accepted by the requestor. Teams ask their own questions, some upfront (requestor) and some internal (team only), all driven by SharePoint configuration lists.

## Roles
| Role | Can do |
|---|---|
| Requestor | Submit intakes (3-page form + the routed team's questions); see only their own intakes; answer questions the team asks; sign off requirements and acceptance; accept or send back work packages. |
| Team Member | Work intakes and work packages they own; move stages forward via F2; manage tasks; ask the requestor a question; record QA evidence. |
| Manager | Everything for their team(s) (IntakeTeams.ManagerEmail): assign owners, re-route, edit intake details and requestor answers, fill internal questions, create work packages and tasks, set status, reopen, close, prioritization queue, dashboard, intakes needing attention. |
| DML (P&BB DMO manager) | Approves Data Risk Assessment intakes at the DML Approval stage (via Approvals in F7). |

## Lifecycle (Status column; RequestStatus is derived by flow F2)
Standard: Submitted → Queued → Assigned / Under Review → Requirements sign-off → Approved → In Progress → (QA Testing) → (DML Approval) → Acceptance sign-off → Closed.
- QA Testing only for types in IntakeQAConfig, or when an intake-level QA/Testing task starts (F5).
- DML Approval only for Level 1 = Data Risk Assessment.
- IAAP Request: Submitted → Queued → In Progress → DML Approval → Closed (assigning moves straight to In Progress).
- Requestor send-backs: Requirements sign-off → Assigned / Under Review; Acceptance sign-off → In Progress (reason required).
- Locked for the team at Acceptance sign-off and Closed; a manager can reopen to In Progress (reason required).
- Rejected is allowed from any open stage by a manager (reason required) and maps to RequestStatus "Cancelled".
- Work-package intakes stay In Progress until every package is Accepted; then the manager closes the intake.
All allowed moves are rows in **IntakeTransitions** (FromStage, ToStage, AllowedRole, ReasonRequired, Lifecycle, RequestStatus).

## Routing
- IntakeRequestTypes: one row per offered Level 1 + Level 2. `DefaultTeam` routes directly, or `AskFocusArea = Yes` means the team comes from the IntakeTeams row whose `FocusArea` matches the requestor's business focus area.
- The requestor can override the suggested team; a manager can re-route later (F2 logs it).

## Dynamic questions
- IntakeQuestions = library (QuestionKey, label, type: Text, Long text, Number, Date, Choice, Yes/No; Choices one per line with optional `|points`).
- IntakeQuestionRules = where asked: Team, RequestTypeL1, RequestTypeL2 (blank = any), Audience (Requestor | Internal), IsRequired, IsScored, SortOrder, ShowIfKey/ShowIfValue.
- Matching: a rule applies when each of Team/L1/L2 is blank or equal to the intake's value. If several rules bring the same QuestionKey, the most specific wins (Team 1, L1 1, L2 2).
- Requestor questions appear on New Intake page 3 ("Questions from {team}") and read-only on the intake page; managers can edit them in Edit intake details. Internal questions appear only in the internal panel.
- Score: sum of points of scored questions, only when every scored question has an answer. Stored in BacklogScore by F1/F3. Teams with any scored rule get the Intake Prioritization Queue.

## Work packages (teams that use them, e.g. Customer Analytics)
- Manager adds packages on the intake (sub-team from IntakeSubTeams, owner defaults to the sub-team lead).
- Package lifecycle: Not started → Requirements → In progress → QA/Review → Ready for acceptance → Accepted; Sent back returns to In progress.
- Requestor accepts or sends back each package from the intake page (cannot open the package screen).
- Intake history shows only package milestones: created, removed, sent for acceptance, accepted, sent back. Everything else stays in the package's own history.

## Other features
- Ask the requestor: owner/manager asks; intake flagged AwaitingRequestor; requestor answers on the intake page; both logged and notified (F6).
- Files: Documents library folder per RequestNumber, WP-{id} sub-folder per package; listed via a flow.
- Manager edit: title, description, priority, needed-by, Level 1/2, focus area and requestor answers; every change logged and visible to the requestor.

## Seeded configuration (POC)
- OMP: upfront revenue (scored), channel enablement (scored), existing offer (Yes/No), offer code (show if Yes), target launch; internal data classification, effort, legal review.
- P&BB DMO: upfront accountable data owner, contains PII.
- Customer Analytics: internal questions for all types plus per type (New Report / Dashboard, Report / Dashboard Change, Data Analysis / Extract); five sub-teams for work packages.
