import { useQuery } from "@tanstack/react-query";
import { IntakeRequestsService } from "../../generated";
import type {
  IntakeRequestsRead,
  IntakeRequestsWrite,
} from "../../generated/models/IntakeRequestsModel";

export type IntakeRequest = IntakeRequestsRead;
export type IntakeWrite = IntakeRequestsWrite;

/** Ordered lifecycle shown on every request timeline. */
export const LIFECYCLE = [
  "Submitted",
  "Queued",
  "Assigned / Under Review",
  "Requirements sign-off",
  "Approved",
  "In Progress",
  "Acceptance sign-off",
  "Closed",
] as const;

/** Stage inserted for request types configured to require QA Testing. */
export const QA_STAGE = "QA Testing";

/** Full lifecycle for QA-enabled request types: QA Testing sits between In Progress and Acceptance. */
export const QA_LIFECYCLE = [
  "Submitted",
  "Queued",
  "Assigned / Under Review",
  "Requirements sign-off",
  "Approved",
  "In Progress",
  QA_STAGE,
  "Acceptance sign-off",
  "Closed",
] as const;

export const REJECTED = "Rejected";

/** Manager/DML approval stage, used only by Data Risk Assessment intakes (after In Progress). */
export const DML_STAGE = "DML Approval";
/** Level 1 type that needs DML approval ("Risk Assessment" is its old name). */
export const DATA_RISK_L1 = "Data Risk Assessment";
const DATA_RISK_L1_NAMES = [DATA_RISK_L1, "Risk Assessment"];
/** Routed team whose manager is the DML. */
export const DML_TEAM = "P&BB DMO";

/** Every stage an intake can be in, in order (for dashboards). */
export const ALL_STAGES: readonly string[] = [...QA_LIFECYCLE.slice(0, 6), DML_STAGE, ...QA_LIFECYCLE.slice(6)];

export function isDataRisk(r: Pick<IntakeRequest, "RequestTypeL1">): boolean {
  return DATA_RISK_L1_NAMES.includes(r.RequestTypeL1?.Value ?? "");
}

/** Stages at which managers and assignees can no longer change the request or its tasks. */
export const LOCKED_STAGES = ["Acceptance sign-off", "Closed"] as const;

export function isLockedStatus(status: string | undefined): boolean {
  return !!status && (LOCKED_STAGES as readonly string[]).includes(status);
}

/** Where a requestor's send-back moves the request. */
export const SEND_BACK_TO: Record<string, string> = {
  "Requirements sign-off": "Assigned / Under Review",
  "Acceptance sign-off": "In Progress",
};

/** Stage a manager's reopen moves a locked request to. */
export const REOPEN_TO = "In Progress";

/**
 * Progress-bar stage (Status column) -> "Request Status" column choice.
 * Request Status has no requirements sign-off stage, so that stage stays "Assigned/Under Review".
 * "On Hold" has no progress-bar stage and is never set by the app.
 */
export const REQUEST_STATUS_BY_STAGE: Record<string, string> = {
  Submitted: "Submitted",
  Queued: "Queued",
  "Assigned / Under Review": "Assigned/Under Review",
  "Requirements sign-off": "Assigned/Under Review",
  Approved: "Approved",
  "In Progress": "In progress",
  [DML_STAGE]: "DML Approval",
  [QA_STAGE]: "QA Testing",
  "Acceptance sign-off": "Delivered/Pending Business Approval",
  Closed: "Closed",
  [REJECTED]: "Cancelled",
};

/** Add the matching Request Status whenever a change sets the progress-bar Status. */
function withRequestStatus<T extends Partial<Omit<IntakeWrite, "ID">>>(changes: T): T {
  const stage = changes.Status?.Value;
  if (!stage) return changes;
  const mapped = REQUEST_STATUS_BY_STAGE[stage];
  if (!mapped) {
    console.error("no Request Status mapping for stage", stage);
    return changes;
  }
  return { ...changes, RequestStatus: { Value: mapped } };
}

export interface LogEntry {
  at: string;
  by: string;
  role: string;
  text: string;
  /** Internal entries are hidden from the requestor. */
  internal?: boolean;
}

export function parseLog(raw: string | undefined): LogEntry[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (e): e is LogEntry =>
        typeof e === "object" &&
        e !== null &&
        typeof (e as LogEntry).at === "string" &&
        typeof (e as LogEntry).text === "string",
    );
  } catch {
    return [];
  }
}

export function appendLog(raw: string | undefined, entry: LogEntry): string {
  return JSON.stringify([...parseLog(raw), entry]);
}

export function statusOf(r: IntakeRequest): string {
  return r.Status?.Value ?? "Submitted";
}

export function stageIndex(status: string, stages: readonly string[] = LIFECYCLE): number {
  return stages.indexOf(status);
}

/**
 * Short lifecycle for Risk Assessment + IAAP Request. Uses existing Status values;
 * the final "Closed" stage is shown to people as "Completed".
 */
export const IAAP_LIFECYCLE = ["Submitted", "Queued", "In Progress", DML_STAGE, "Closed"] as const;

export function isIaap(r: Pick<IntakeRequest, "RequestTypeL1" | "RequestTypeL2">): boolean {
  return isDataRisk(r) && r.RequestTypeL2 === "IAAP Request";
}

/**
 * Stages this request goes through. QA-enabled types (see the QA config list) get QA Testing;
 * a request already sitting in QA Testing always shows it.
 */
export function lifecycleFor(
  r: Pick<IntakeRequest, "RequestTypeL1" | "RequestTypeL2" | "Status">,
  requiresQa = false,
): readonly string[] {
  if (isIaap(r)) return IAAP_LIFECYCLE;
  const base: readonly string[] = requiresQa || r.Status?.Value === QA_STAGE ? QA_LIFECYCLE : LIFECYCLE;
  if (!isDataRisk(r)) return base;
  const at = base.indexOf("In Progress") + 1;
  return [...base.slice(0, at), DML_STAGE, ...base.slice(at)];
}

/**
 * Stage an intake moves to when a manager assigns an owner: only from Submitted/Queued.
 * IAAP goes straight to In Progress (it has no review stage); everything else to Assigned / Under Review.
 */
export function stageAfterAssign(r: IntakeRequest): string | undefined {
  const s = statusOf(r);
  if (s !== "Submitted" && s !== "Queued") return undefined;
  return isIaap(r) ? "In Progress" : "Assigned / Under Review";
}

/** Stage name as shown to people for this request. */
export function stageLabel(stage: string, iaap: boolean): string {
  return iaap && stage === "Closed" ? "Completed" : stage;
}

/** Status as shown to people for this request. */
export function displayStatus(r: IntakeRequest): string {
  return stageLabel(statusOf(r), isIaap(r));
}

export function requestNumber(r: IntakeRequest): string {
  if (r.RequestNumber) return r.RequestNumber;
  return r.ID ? `INT-${String(r.ID).padStart(5, "0")}` : "INT-pending";
}

export function buildRequestNumber(id: number, when: Date): string {
  const y = when.getFullYear();
  const m = String(when.getMonth() + 1).padStart(2, "0");
  const d = String(when.getDate()).padStart(2, "0");
  return `INT-${y}${m}${d}-${String(id).padStart(5, "0")}`;
}

export function formatDate(iso: string | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

export function isOverdue(r: IntakeRequest): boolean {
  if (!r.NeededBy) return false;
  const s = statusOf(r);
  if (s === "Closed" || s === REJECTED) return false;
  return new Date(r.NeededBy).getTime() < Date.now();
}

export function odataString(v: string): string {
  return `'${v.replaceAll("'", "''")}'`;
}

/** Fields read for every list/detail view (all confirmed in the generated model). */
export const SELECT_FIELDS = [
  "ID",
  "Title",
  "RequestNumber",
  "Requestor",
  "Requestorsemail",
  "OnBehalfOf",
  "BusinessUnit",
  "RequestTypeL1",
  "RequestTypeL2",
  "RoutedTeam",
  "RequestComments",
  "RequestDescription",
  "NeededBy",
  "Priority",
  "BusinessValue",
  "BacklogScore",
  "AnalyticsDomain",
  "AwaitingRequestor",
  "OpenQuestion",
  "QuestionAskedOn",
  "QuestionAskedBy",
  "RequestorAnswer",
  "AnsweredOn",
  "Status",
  "RequestStatus",
  "Owner",
  "RequirementsSignedOff",
  "AcceptanceSignedOff",
  "SubmittedOn",
  "ActivityLog",
  "RequestorAnswers",
  "InternalAnswers",
  "Reference",
  "Created",
  "Modified",
];

export type ChoiceField =
  | "BusinessUnit"
  | "RequestTypeL1"
  | "RoutedTeam"
  | "Priority"
  | "Status"
  | "AnalyticsDomain";

/** Narrow the SharePoint Choice payload (direct array or { value: [...] }) to option labels. */
export function parseChoices(payload: unknown): string[] {
  const raw = Array.isArray(payload)
    ? payload
    : typeof payload === "object" &&
        payload !== null &&
        "value" in payload &&
        Array.isArray((payload as { value: unknown }).value)
      ? (payload as { value: unknown[] }).value
      : null;
  if (raw === null) throw new Error("Unsupported SharePoint Choice response shape");
  return raw.map((item) => {
    if (typeof item === "string") return item;
    if (typeof item === "object" && item !== null && "Value" in item) {
      const v = (item as { Value: unknown }).Value;
      if (typeof v === "string") return v;
    }
    throw new Error("Unsupported SharePoint Choice item shape");
  });
}

export function useChoices(field: ChoiceField) {
  return useQuery({
    queryKey: ["choices", field],
    staleTime: 10 * 60 * 1000,
    queryFn: async () => {
      const result = await IntakeRequestsService.getReferencedEntity("", field);
      if (!result.success) {
        console.error("choice load failed", field, result.error);
        throw new Error("Unable to load options.");
      }
      return parseChoices(result.data);
    },
  });
}

export const PAGE_SIZE = 50;

/** How often open screens re-read requests so stage changes made elsewhere appear. */
export const REQUEST_REFRESH_MS = 30_000;

export function useRequestPage(filter: string | undefined, skipToken: string | undefined, top = PAGE_SIZE) {
  return useQuery({
    queryKey: ["requests", { filter, skipToken, top }],
    staleTime: REQUEST_REFRESH_MS,
    refetchInterval: REQUEST_REFRESH_MS,
    refetchOnWindowFocus: true,
    queryFn: async () => {
      const result = await IntakeRequestsService.getAll({
        select: SELECT_FIELDS,
        filter,
        orderBy: ["ID desc"],
        top,
        skipToken,
      });
      if (!result.success) {
        console.error("intake list load failed", result.error);
        throw new Error("Unable to load intakes.");
      }
      return { rows: result.data ?? [], nextToken: result.skipToken?.trim() || undefined };
    },
  });
}

export function useRequest(id: string | undefined) {
  return useQuery({
    queryKey: ["request", id],
    enabled: !!id,
    staleTime: REQUEST_REFRESH_MS,
    refetchInterval: REQUEST_REFRESH_MS,
    refetchOnWindowFocus: true,
    queryFn: async () => {
      const n = Number(id);
      if (!Number.isInteger(n) || n <= 0) throw new Error("Invalid intake id.");
      // Single-item reads by id return 404 through this connector; read the row via a filtered list query instead.
      const result = await IntakeRequestsService.getAll({ select: SELECT_FIELDS, filter: `ID eq ${n}`, top: 1 });
      if (!result.success) {
        console.error("intake load failed", result.error);
        throw new Error("Unable to load this intake.");
      }
      const row = (result.data ?? [])[0];
      if (!row) throw new Error("Intake not found.");
      return row;
    },
  });
}

export async function createRequest(record: Omit<IntakeWrite, "ID">): Promise<IntakeRequest> {
  const result = await IntakeRequestsService.create(withRequestStatus(record));
  if (!result.success) {
    console.error("intake create failed", result.error);
    throw new Error("The intake could not be submitted.");
  }
  const created = result.data;
  if (created?.ID) {
    const num = buildRequestNumber(created.ID, new Date());
    const upd = await IntakeRequestsService.update(String(created.ID), { RequestNumber: num });
    if (!upd.success) console.error("request number update failed", upd.error);
    else return upd.data;
  }
  return created;
}

export async function updateRequest(
  id: number,
  changes: Partial<Omit<IntakeWrite, "ID">>,
): Promise<IntakeRequest> {
  const result = await IntakeRequestsService.update(String(id), withRequestStatus(changes));
  if (!result.success) {
    console.error("intake update failed", result.error);
    throw new Error("The change could not be saved.");
  }
  return result.data;
}

/** Most requests scanned to find which are locked (for the task board). */
export const LOCK_SCAN = 2000;

/** IDs of requests currently at a locked stage. */
export function useLockedRequestIds() {
  return useQuery({
    queryKey: ["requests", "locked-ids"],
    staleTime: REQUEST_REFRESH_MS,
    refetchInterval: REQUEST_REFRESH_MS,
    queryFn: async () => {
      const result = await IntakeRequestsService.getAll({ select: ["ID", "Status"], top: LOCK_SCAN });
      if (!result.success) {
        console.error("locked request scan failed", result.error);
        throw new Error("Unable to check intake status.");
      }
      const ids = new Set<number>();
      const seen = new Set<number>();
      for (const r of result.data ?? []) {
        if (!r.ID) continue;
        seen.add(r.ID);
        if (isLockedStatus(r.Status?.Value)) ids.add(r.ID);
      }
      return { ids, seen, partial: !!result.skipToken?.trim() };
    },
  });
}

/** Most team requests folded into one task filter; beyond this only the newest are included. */
export const TEAM_REQUEST_CAP = 100;

/** IDs of the newest requests matching a filter (used to scope tasks to a manager's teams). */
export function useRequestIds(filter: string | undefined) {
  return useQuery({
    queryKey: ["requests", "ids", filter],
    enabled: !!filter,
    staleTime: REQUEST_REFRESH_MS,
    queryFn: async () => {
      const result = await IntakeRequestsService.getAll({ select: ["ID"], filter, orderBy: ["ID desc"], top: TEAM_REQUEST_CAP });
      if (!result.success) {
        console.error("team request ids load failed", result.error);
        throw new Error("Unable to load team intakes.");
      }
      const ids = (result.data ?? []).map((r) => r.ID).filter((id): id is number => typeof id === "number");
      return { ids, partial: !!result.skipToken?.trim() };
    },
  });
}
