import type { IntakeRequest } from "@/lib/intake";

const DAY = 86_400_000;
/** How long an "Answered" tag stays on the team's lists after the requestor replies. */
const ANSWERED_TAG_DAYS = 7;

/** The intake has an open question for the requestor. */
export function isAwaitingRequestor(r: IntakeRequest): boolean {
  return r.AwaitingRequestor === true;
}

/** Whole days since the open question was asked (undefined when no date). */
export function daysWaiting(r: IntakeRequest): number | undefined {
  const t = r.QuestionAskedOn ? new Date(r.QuestionAskedOn).getTime() : NaN;
  return Number.isNaN(t) ? undefined : Math.max(0, Math.floor((Date.now() - t) / DAY));
}

/** The requestor answered the latest question recently (shown to the team as "Answered"). */
export function recentlyAnswered(r: IntakeRequest): boolean {
  if (isAwaitingRequestor(r) || !r.AnsweredOn) return false;
  const t = new Date(r.AnsweredOn).getTime();
  return !Number.isNaN(t) && Date.now() - t <= ANSWERED_TAG_DAYS * DAY;
}
