<#
  D.A.T.A. Intake Portal (VERSION 3, flow-brokered) - create all SharePoint lists,
  import the CSV data and lock the lists down to the flow service account.

  WHAT IT DOES
    1. Creates every list and column described in 01-Column-Definitions.csv
       (exact types, required, indexes, unique keys, defaults, choices).
    2. Imports the configuration CSVs (teams, roles, types, questions, rules).
    3. Optionally imports the sample transaction CSVs and re-links every child
       row (tasks, approvals, activity) to the real request ID.
    4. If you pass -ServiceAccount: stops the lists inheriting site permissions,
       leaves access ONLY for the site Owners group and the service account
       (Contribute on lists, Full Control on IntakeEvidence so flows can grant
       a requestor access to their own evidence folder).

  BEFORE YOU RUN
    - PowerShell 7.2 or later:   winget install Microsoft.PowerShell
    - PnP PowerShell module:     Install-Module PnP.PowerShell -Scope CurrentUser
    - An Entra ID app registration for PnP (your IT team may already have one):
        Register-PnPEntraIDAppForInteractiveLogin -ApplicationName "PnP Intake" -Tenant yourtenant.onmicrosoft.com
      and note the Client ID it prints.
    - You must be a Site Owner of the target site.

  RUN
    cd <folder where you unzipped this pack>
    ./04-Create-And-Import-Lists.ps1 -SiteUrl https://yourtenant.sharepoint.com/sites/DATA-Intake -ClientId <guid> -EmailDomain yourcompany.com
    Add -SkipSampleData to create the lists and config only (recommended for production).
    Add -ServiceAccount svc-intake@yourtenant.com to lock the lists down (do this
    once you have tested; you can run the script again with just this added).

  SAFE TO RE-RUN: existing lists and columns are skipped, not overwritten.
  Data rows are added again on each run, so only re-run the import on empty lists.
#>
param(
  [Parameter(Mandatory=$true)][string]$SiteUrl,
  [Parameter(Mandatory=$true)][string]$ClientId,
  # Your email domain, e.g. contoso.com. Replaces {EmailDomain} in the CSV files.
  [string]$EmailDomain,
  [switch]$SkipSampleData,
  [switch]$SkipConfigData,
  [string]$ServiceAccount
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if ((-not $SkipSampleData -or -not $SkipConfigData) -and [string]::IsNullOrWhiteSpace($EmailDomain)) {
  throw "Pass -EmailDomain (for example -EmailDomain contoso.com) so the sample emails become real accounts in your tenant."
}
$EmailDomain = $EmailDomain.Trim().TrimStart("@")
Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Interactive

$defs = Import-Csv (Join-Path $here "01-Column-Definitions.csv")
$libraries = @("IntakeEvidence")
function X([string]$s){ [System.Security.SecurityElement]::Escape($s) }

# ---------- 1. LISTS AND COLUMNS ----------
foreach ($listName in ($defs.List | Select-Object -Unique)) {
  $list = Get-PnPList -Identity $listName -ErrorAction SilentlyContinue
  if (-not $list) {
    $template = if ($libraries -contains $listName) { "DocumentLibrary" } else { "GenericList" }
    Write-Host "Creating $listName ($template)" -ForegroundColor Cyan
    $list = New-PnPList -Title $listName -Template $template -OnQuickLaunch
    Set-PnPList -Identity $listName -EnableVersioning $true | Out-Null
  } else { Write-Host "$listName already exists - adding missing columns only" -ForegroundColor Yellow }

  $existing = (Get-PnPField -List $listName).InternalName
  foreach ($d in ($defs | Where-Object List -eq $listName)) {
    if ($d.Column -eq "Title") {
      if ($d.Required -ne "Yes") { Set-PnPField -List $listName -Identity Title -Values @{Required=$false} | Out-Null }
      continue
    }
    if ($existing -contains $d.Column) { continue }
    $req = if ($d.Required -eq "Yes") { "TRUE" } else { "FALSE" }
    $name = X $d.Column
    $common = "DisplayName='$name' Name='$name' StaticName='$name' Required='$req'"
    switch ($d.Type) {
      "Single line of text"    { $xml = "<Field Type='Text' $common MaxLength='255' />" }
      "Multiple lines of text" { $xml = "<Field Type='Note' $common NumLines='6' RichText='FALSE' AppendOnly='FALSE' UnlimitedLengthInDocumentLibrary='TRUE' />" }
      "Number"                 { $xml = "<Field Type='Number' $common Decimals='0' />"; if ($d.Column -match "Score|Days|Weight") { $xml = "<Field Type='Number' $common />" } }
      "Date and time"          { $xml = "<Field Type='DateTime' $common Format='DateTime' />" }
      "Date only"              { $xml = "<Field Type='DateTime' $common Format='DateOnly' />" }
      "Yes/No"                 { $xml = "<Field Type='Boolean' $common />" }
      "Hyperlink"              { $xml = "<Field Type='URL' $common Format='Hyperlink' />" }
      "Choice" {
        $choices = ($d.Choices -split ";" | ForEach-Object { "<CHOICE>$(X $_.Trim())</CHOICE>" }) -join ""
        $xml = "<Field Type='Choice' $common Format='Dropdown' FillInChoice='FALSE'><CHOICES>$choices</CHOICES></Field>"
      }
      default { throw "Unknown type '$($d.Type)' for $listName.$($d.Column)" }
    }
    if ($d.Default) {
      $dv = switch ($d.Default) { "Yes" {"1"} "No" {"0"} default { X $d.Default } }
      $xml = $xml -replace "\s*/>$", "><Default>$dv</Default></Field>"
      $xml = $xml -replace "</CHOICES></Field>$", "</CHOICES><Default>$dv</Default></Field>"
    }
    Add-PnPFieldFromXml -List $listName -FieldXml $xml | Out-Null
    if ($d.Indexed -eq "Yes") {
      $vals = @{ Indexed = $true }
      if ($d.Unique -eq "Yes") { $vals.EnforceUniqueValues = $true }
      Set-PnPField -List $listName -Identity $d.Column -Values $vals | Out-Null
    }
    Write-Host "   + $($d.Column) ($($d.Type))"
  }
  # Default view: show every column except the technical JSON copies
  $view = Get-PnPView -List $listName | Where-Object DefaultView | Select-Object -First 1
  $first = if ($libraries -contains $listName) { @("DocIcon","LinkFilename") } else { @("LinkTitle") }
  $cols = $first + @(($defs | Where-Object { $_.List -eq $listName -and $_.Column -ne "Title" -and $_.Column -notin @("AnswersJson","InternalJson","PromotePending","RowVersion") }).Column)
  Set-PnPView -List $listName -Identity $view.Id -Fields $cols | Out-Null
}

# ---------- 2. DATA IMPORT ----------
$typeOf = @{}
foreach ($d in $defs) { $typeOf["$($d.List)|$($d.Column)"] = $d.Type }

function Convert-Value($list, $col, $raw) {
  if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
  switch ($typeOf["$list|$col"]) {
    "Yes/No"        { return ($raw -in @("Yes","TRUE","True","1")) }
    "Number"        { return [double]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture) }
    "Date only"     { return [datetime]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture) }
    "Date and time" { return [datetime]::Parse($raw, [Globalization.CultureInfo]::InvariantCulture).ToUniversalTime() }
    default         { return $raw }
  }
}
function Import-ListCsv($listName, $path, [hashtable]$idMap) {
  if (-not (Test-Path $path)) { return }
  $rows = Import-Csv $path -Encoding UTF8
  Write-Host "Importing $($rows.Count) rows into $listName" -ForegroundColor Cyan
  $created = @{}
  foreach ($r in $rows) {
    $vals = @{}
    foreach ($p in $r.PSObject.Properties) {
      $raw = if ($p.Value) { ([string]$p.Value).Replace("{EmailDomain}", $EmailDomain) } else { $p.Value }
      $v = Convert-Value $listName $p.Name $raw
      if ($null -ne $v) { $vals[$p.Name] = $v }
    }
    if ($idMap -and $r.RequestNumber -and $idMap.ContainsKey($r.RequestNumber)) {
      $vals["RequestID"] = $idMap[$r.RequestNumber]          # re-link to the real ID
    }
    $item = Add-PnPListItem -List $listName -Values $vals
    if ($listName -eq "IntakeRequests") { $created[$r.RequestNumber] = $item.Id }
  }
  return $created
}

if (-not $SkipConfigData) {
  foreach ($n in "IntakeTeams","IntakeRoleAssignments","IntakeRequestTypes","IntakeQuestions","IntakeQuestionRules") {
    Import-ListCsv $n (Join-Path $here "1-Configuration-Lists/$n.csv") $null | Out-Null
  }
}
if (-not $SkipSampleData) {
  $map = Import-ListCsv "IntakeRequests" (Join-Path $here "2-Transaction-Lists/IntakeRequests.csv") $null
  foreach ($n in "IntakeTasks","IntakeApprovals","IntakeActivity") {
    Import-ListCsv $n (Join-Path $here "2-Transaction-Lists/$n.csv") $map | Out-Null
  }
}
# ---------- 3. LOCK DOWN (optional) ----------
if ($ServiceAccount) {
  $owners = Get-PnPGroup -AssociatedOwnerGroup
  foreach ($listName in ($defs.List | Select-Object -Unique)) {
    Write-Host "Locking $listName to Owners + $ServiceAccount" -ForegroundColor Cyan
    # Break inheritance WITHOUT copying: removes Members and Visitors from this list
    Set-PnPList -Identity $listName -BreakRoleInheritance -ClearSubscopes | Out-Null
    Set-PnPListPermission -Identity $listName -Group $owners -AddRole "Full Control" | Out-Null
    $role = if ($libraries -contains $listName) { "Full Control" } else { "Contribute" }
    Set-PnPListPermission -Identity $listName -User $ServiceAccount -AddRole $role | Out-Null
  }
  Write-Host "Lock-down done. Check List settings > Permissions for this list on one list." -ForegroundColor Green
}
Write-Host "Done. Open the site and check each list (see README step 4)." -ForegroundColor Green
