import { useState } from "react";
import type { DateRange } from "react-day-picker";
import { subDays } from "date-fns";
import { CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { describeRange, rangeLabel, type RangePreset, type SubmittedRange } from "@/lib/date-range";

/** Submitted-date range control: quick picks plus a calendar for custom ranges. */
export function DateRangeFilter({ value, onChange }: { value: SubmittedRange; onChange: (r: SubmittedRange) => void }) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<DateRange | undefined>(value.preset === "custom" ? { from: value.from, to: value.to } : undefined);
  const isAll = value.preset === "all";
  return (
    <div className="space-y-2 rounded-lg border border-border bg-card p-3">
    <div className="flex flex-wrap items-end gap-3">
      <div className="grid gap-1">
        <Label htmlFor="range-preset">Submitted</Label>
        <div className="[&>[data-slot=native-select-wrapper]]:w-44">
          <NativeSelect
            id="range-preset"
            value={value.preset}
            onChange={(e) => {
              const preset = e.target.value as RangePreset;
              if (preset === "custom") {
                setOpen(true);
                return;
              }
              onChange({ ...value, preset, from: undefined, to: undefined });
            }}
          >
            <NativeSelectOption value="30">Last 30 days</NativeSelectOption>
            <NativeSelectOption value="90">Last 90 days</NativeSelectOption>
            <NativeSelectOption value="year">This year</NativeSelectOption>
            <NativeSelectOption value="all">All time</NativeSelectOption>
            <NativeSelectOption value="custom">Custom range…</NativeSelectOption>
          </NativeSelect>
        </div>
      </div>

      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" aria-label={`Choose dates. Current range: ${rangeLabel(value)}`}>
            <CalendarDays aria-hidden="true" /> {rangeLabel(value)}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-3" align="start">
          <Calendar
            mode="range"
            numberOfMonths={2}
            selected={draft}
            onSelect={setDraft}
            defaultMonth={draft?.from ?? subDays(new Date(), 60)}
            disabled={{ after: new Date() }}
          />
          <div className="mt-2 flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              size="sm"
              disabled={!draft?.from}
              onClick={() => {
                onChange({ ...value, preset: "custom", from: draft?.from, to: draft?.to ?? draft?.from });
                setOpen(false);
              }}
            >
              Apply
            </Button>
          </div>
        </PopoverContent>
      </Popover>

      <div className="flex items-center gap-2 pb-2">
        <Checkbox
          id="range-open"
          checked={value.includeOpen}
          disabled={isAll}
          onCheckedChange={(c) => onChange({ ...value, includeOpen: c === true })}
        />
        <Label htmlFor="range-open" className="font-normal">Also show intakes still being worked on</Label>
      </div>
    </div>
    <p className="text-sm text-muted-foreground" aria-live="polite">{describeRange(value)}</p>
    </div>
  );
}
