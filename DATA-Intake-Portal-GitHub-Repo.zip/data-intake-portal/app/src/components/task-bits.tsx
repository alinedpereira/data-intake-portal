import { useState, type ReactNode } from "react";
import { useWorkPackages } from "@/lib/workpackages";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { CalendarClock, Lock, Pencil, Tag, Trash2, User } from "lucide-react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useConfirm } from "@/hooks/use-confirm";
import { actorName, useAppStore } from "@/lib/store";
import { ownerOf, personWrite, useMyRequestScope, type Person } from "@/lib/people";
import { PersonPicker } from "@/components/person-picker";
import { formatDate, isLockedStatus, requestNumber, useRequestPage, type IntakeRequest } from "@/lib/intake";
import {
  createTask,
  deleteTask,
  isTaskOverdue,
  taskAssigneeName,
  taskStatusOf,
  updateTask,
  useTaskStatuses,
  useTaskTypes,
  type IntakeTask,
  type TaskWrite,
} from "@/lib/tasks";
import { cn } from "@/lib/utils";

export function TaskStatusSelect({ id, value, onChange, label }: { id: string; value: string; onChange: (v: string) => void; label?: string }) {
  const q = useTaskStatuses();
  if (q.isError)
    return (
      <p role="alert" className="text-sm text-destructive">
        Statuses could not be loaded. <button type="button" className="underline" onClick={() => void q.refetch()}>Retry</button>
      </p>
    );
  return (
    <div className="[&>[data-slot=native-select-wrapper]]:w-full">
      <NativeSelect id={id} aria-label={label} value={value} disabled={q.isPending} onChange={(e) => onChange(e.target.value)} className="bg-card">
        {q.isPending && <NativeSelectOption value={value}>Loading…</NativeSelectOption>}
        {(q.data ?? []).map((c) => (
          <NativeSelectOption key={c} value={c}>{c}</NativeSelectOption>
        ))}
      </NativeSelect>
    </div>
  );
}

export function TaskTypeSelect({ id, value, onChange }: { id: string; value: string; onChange: (v: string) => void }) {
  const q = useTaskTypes();
  if (q.isError)
    return (
      <p role="alert" className="text-sm text-destructive">
        Task types could not be loaded. <button type="button" className="underline" onClick={() => void q.refetch()}>Retry</button>
      </p>
    );
  return (
    <div className="[&>[data-slot=native-select-wrapper]]:w-full">
      <NativeSelect id={id} value={value} disabled={q.isPending} onChange={(e) => onChange(e.target.value)} className="bg-card">
        <NativeSelectOption value="">{q.isPending ? "Loading…" : "Choose…"}</NativeSelectOption>
        {(q.data ?? []).map((c) => (
          <NativeSelectOption key={c} value={c}>{c}</NativeSelectOption>
        ))}
      </NativeSelect>
    </div>
  );
}

function useTaskMutations() {
  const qc = useQueryClient();
  const done = () => void qc.invalidateQueries({ queryKey: ["tasks"] });
  const update = useMutation({
    mutationFn: ({ id, changes }: { id: number; changes: TaskWrite }) => updateTask(id, changes),
    onSuccess: done,
    onError: () => toast.error("The task could not be saved. Please try again."),
  });
  const remove = useMutation({
    mutationFn: (id: number) => deleteTask(id),
    onSuccess: () => { done(); toast.success("Task deleted"); },
    onError: () => toast.error("The task could not be deleted. Please try again."),
  });
  return { update, remove };
}

export function TaskCard({ task, showRequest = true, locked = false }: { task: IntakeTask; showRequest?: boolean; locked?: boolean }) {
  const { update, remove } = useTaskMutations();
  const confirm = useConfirm();
  const [editing, setEditing] = useState(false);
  const status = taskStatusOf(task);
  const overdue = isTaskOverdue(task);
  return (
    <article className="space-y-2 rounded-md border border-border bg-card p-3 text-sm shadow-xs">
      <div className="flex items-start justify-between gap-2">
        <h3 className={cn("font-semibold", status === "Done" && "line-through")}>{task.Title}</h3>
        {locked ? (
          <span className="inline-flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
            <Lock className="size-3.5" aria-hidden="true" /> Locked
          </span>
        ) : (
        <div className="flex shrink-0">
          <Button variant="ghost" size="icon" aria-label={`Edit task ${task.Title}`} onClick={() => setEditing(true)}>
            <Pencil aria-hidden="true" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Delete task ${task.Title}`}
            disabled={remove.isPending}
            onClick={async () => {
              if (await confirm({ title: "Delete this task?", confirmLabel: "Delete", destructive: true })) remove.mutate(task.ID as number);
            }}
          >
            <Trash2 aria-hidden="true" />
          </Button>
        </div>
        )}
      </div>
      {showRequest && task.RequestItemId ? (
        <Link to={`/work/${task.RequestItemId}`} className="block truncate text-xs font-medium text-primary hover:underline">
          {task.RequestNumber ?? "Intake"} · {task.RequestTitle}
        </Link>
      ) : null}
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs">
        {task.TaskType?.Value && (
          <span className="inline-flex items-center gap-1"><Tag className="size-3.5" aria-hidden="true" />{task.TaskType.Value}</span>
        )}
        <span className="inline-flex items-center gap-1"><User className="size-3.5" aria-hidden="true" />{taskAssigneeName(task) ?? "Unassigned"}</span>
        <span className={cn("inline-flex items-center gap-1", overdue && "font-semibold text-red-700 dark:text-red-400")}>
          <CalendarClock className="size-3.5" aria-hidden="true" />
          {task.DueDate ? `Due ${formatDate(task.DueDate)}` : "No due date"}
          {overdue && " · overdue"}
        </span>
      </div>
      {task.TaskNotes && <p className="line-clamp-3 whitespace-pre-wrap text-xs text-muted-foreground">{task.TaskNotes}</p>}
      {locked ? (
        <p className="text-xs font-semibold">{status}</p>
      ) : (
      <TaskStatusSelect
        id={`task-status-${task.ID}`}
        label={`Status of ${task.Title}`}
        value={status}
        onChange={(v) => v !== status && update.mutate({ id: task.ID as number, changes: { TaskStatus: { Value: v } } })}
      />
      )}
      {!locked && editing && <TaskDialog open onOpenChange={setEditing} task={task} />}
    </article>
  );
}

/** Create (optionally pre-linked to a request) or edit a task. */
export function TaskDialog({
  open,
  onOpenChange,
  task,
  request,
  workPackageId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  task?: IntakeTask;
  request?: IntakeRequest;
  /** Pre-select this work package for a new task. */
  workPackageId?: number;
}) {
  const qc = useQueryClient();
  const actor = useAppStore(actorName);
  const me = useAppStore((s) => s.me);
  const role = useAppStore((s) => s.role);
  const [title, setTitle] = useState(task?.Title ?? "");
  const [owner, setOwner] = useState<Person | null>(
    task ? (task.AssignedTo?.Claims ? task.AssignedTo : null) : role === "Assignee" && me ? me : request ? ownerOf(request) : null,
  );
  const [due, setDue] = useState(task?.DueDate ? task.DueDate.slice(0, 10) : "");
  const [status, setStatus] = useState(task ? taskStatusOf(task) : "Not started");
  const [taskType, setTaskType] = useState(task?.TaskType?.Value ?? "");
  const [notes, setNotes] = useState(task?.TaskNotes ?? "");
  const [requestId, setRequestId] = useState(task?.RequestItemId ? String(task.RequestItemId) : request?.ID ? String(request.ID) : "");
  const linkedFixed = !!task || !!request;
  const wpRequestId = task?.RequestItemId ?? request?.ID;
  const wps = useWorkPackages(wpRequestId);
  const [wpId, setWpId] = useState(task?.WorkPackageId ? String(task.WorkPackageId) : workPackageId ? String(workPackageId) : "");
  const scope = useMyRequestScope();
  const reqs = useRequestPage(role === "Manager" ? scope.filter : undefined, undefined, 200);
  const chosen: IntakeRequest | undefined = request ?? reqs.data?.rows.find((r) => String(r.ID) === requestId);

  const save = useMutation({
    mutationFn: async () => {
      const dueIso = due ? `${due}T12:00:00Z` : undefined;
      if (task) {
        const changes: TaskWrite = {};
        if (title.trim() !== task.Title) changes.Title = title.trim();
        if (owner && owner.Claims !== task.AssignedTo?.Claims) changes.AssignedTo = personWrite(owner);
        if ((task.DueDate?.slice(0, 10) ?? "") !== due) changes.DueDate = dueIso;
        if (status !== taskStatusOf(task)) changes.TaskStatus = { Value: status };
        if (taskType && taskType !== (task.TaskType?.Value ?? "")) changes.TaskType = { Value: taskType };
        if (notes.trim() !== (task.TaskNotes ?? "")) changes.TaskNotes = notes.trim();
        if (wpId !== (task.WorkPackageId ? String(task.WorkPackageId) : "")) changes.WorkPackageId = wpId ? Number(wpId) : (null as unknown as undefined);
        if (Object.keys(changes).length === 0) return;
        await updateTask(task.ID as number, changes);
      } else {
        await createTask({
          Title: title.trim(),
          RequestItemId: chosen?.ID,
          RequestNumber: chosen ? requestNumber(chosen) : undefined,
          RequestTitle: chosen?.Title,
          AssignedTo: owner ? personWrite(owner) : undefined,
          DueDate: dueIso,
          TaskStatus: { Value: status },
          TaskType: taskType ? { Value: taskType } : undefined,
          TaskNotes: notes.trim() || undefined,
          CreatedByName: actor,
          WorkPackageId: wpId ? Number(wpId) : undefined,
        });
      }
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["tasks"] });
      toast.success(task ? "Task saved" : "Task added");
      onOpenChange(false);
    },
    onError: () => toast.error("The task could not be saved. Please try again."),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{task ? "Edit task" : "New task"}</DialogTitle>
        </DialogHeader>
        <form
          id="task-form"
          className="grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            save.mutate();
          }}
        >
          <F id="t-request" label="Intake">
            {linkedFixed ? (
              <p id="t-request" className="text-sm font-semibold">
                {task ? `${task.RequestNumber ?? ""} · ${task.RequestTitle ?? ""}` : `${requestNumber(request as IntakeRequest)} · ${request?.Title}`}
              </p>
            ) : reqs.isError ? (
              <p role="alert" className="text-sm text-destructive">Intakes could not be loaded.</p>
            ) : (
              <div className="[&>[data-slot=native-select-wrapper]]:w-full">
                <NativeSelect id="t-request" required value={requestId} disabled={reqs.isPending} onChange={(e) => setRequestId(e.target.value)} className="bg-card">
                  <NativeSelectOption value="">{reqs.isPending ? "Loading intakes…" : "Choose an intake…"}</NativeSelectOption>
                  {(reqs.data?.rows ?? []).filter((r) => !isLockedStatus(r.Status?.Value)).map((r) => (
                    <NativeSelectOption key={r.ID} value={String(r.ID)}>{requestNumber(r)} · {r.Title}</NativeSelectOption>
                  ))}
                </NativeSelect>
              </div>
            )}
          </F>
          {(wps.data?.length ?? 0) > 0 && (
            <F id="t-wp" label="Work package">
              <div className="[&>[data-slot=native-select-wrapper]]:w-full">
                <NativeSelect id="t-wp" value={wpId} onChange={(e) => setWpId(e.target.value)} className="bg-card">
                  <NativeSelectOption value="">Not in a work package</NativeSelectOption>
                  {(wps.data ?? []).map((w, i) => (
                    <NativeSelectOption key={w.ID} value={String(w.ID)}>{`WP ${i + 1} · ${w.Title}`}</NativeSelectOption>
                  ))}
                </NativeSelect>
              </div>
            </F>
          )}
          <F id="t-title" label="Task">
            <Input id="t-title" required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What needs doing" />
          </F>
          <div className="grid gap-4 sm:grid-cols-2">
            <F id="t-owner" label="Assigned to">
              <PersonPicker id="t-owner" field="TaskAssignedTo" value={owner} onChange={setOwner} />
            </F>
            <F id="t-due" label="Due date">
              <Input id="t-due" type="date" value={due} onChange={(e) => setDue(e.target.value)} />
            </F>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <F id="t-type" label="Task type">
              <TaskTypeSelect id="t-type" value={taskType} onChange={setTaskType} />
            </F>
            <F id="t-status" label="Status">
              <TaskStatusSelect id="t-status" value={status} onChange={setStatus} />
            </F>
          </div>
          <F id="t-notes" label="Notes">
            <Textarea id="t-notes" rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </F>
        </form>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button type="submit" form="task-form" disabled={save.isPending || !title.trim() || (!linkedFixed && !requestId)}>
            {save.isPending ? "Saving…" : task ? "Save task" : "Add task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function F({ id, label, children }: { id: string; label: string; children: ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}
