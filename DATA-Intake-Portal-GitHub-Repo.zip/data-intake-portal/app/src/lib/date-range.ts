import { addDays, format, startOfDay, startOfYear, subDays } from "date-fns";

export type RangePreset = "30" | "90" | "year" | "all" | "custom";

export interface SubmittedRange {
  preset: RangePreset;
  from?: Date;
  to?: Date;
  /** Also include requests that are still being worked on, whatever their submitted date. */
  includeOpen: boolean;
}

export const DEFAULT_RANGE: SubmittedRange = { preset: "90", includeOpen: true };

function resolve(r: SubmittedRange): { from?: Date; to?: Date } {
  const today = startOfDay(new Date());
  if (r.preset === "30") return { from: subDays(today, 30) };
  if (r.preset === "90") return { from: subDays(today, 90) };
  if (r.preset === "year") return { from: startOfYear(today) };
  if (r.preset === "custom") return { from: r.from, to: r.to };
  return {};
}

/**
 * OData filter for the range on the request's submitted (Created) date. With includeOpen,
 * requests not yet Closed or Rejected are kept regardless of date. Undefined = no date limit.
 */
export function rangeFilter(r: SubmittedRange): string | undefined {
  const { from, to } = resolve(r);
  if (!from && !to) return undefined;
  const parts: string[] = [];
  if (from) parts.push(`Created ge '${from.toISOString()}'`);
  if (to) parts.push(`Created lt '${addDays(startOfDay(to), 1).toISOString()}'`);
  const dated = parts.join(" and ");
  return r.includeOpen ? `((${dated}) or (Status ne 'Closed' and Status ne 'Rejected'))` : `(${dated})`;
}

export function rangeLabel(r: SubmittedRange): string {
  const { from, to } = resolve(r);
  if (r.preset === "all") return "All time";
  if (r.preset === "custom")
    return from ? `${format(from, "d MMM yyyy")} – ${to ? format(to, "d MMM yyyy") : "today"}` : "Pick dates";
  return `Since ${from ? format(from, "d MMM yyyy") : ""}`;
}


/** Plain-language description of what the range shows. */
export function describeRange(r: SubmittedRange): string {
  const { from, to } = resolve(r);
  if (!from && !to) return "Showing all intakes, whenever they were submitted.";
  const when = to
    ? `submitted ${from ? format(from, "d MMM yyyy") : "any time"} to ${format(to, "d MMM yyyy")}`
    : `submitted since ${from ? format(from, "d MMM yyyy") : ""}`;
  return `Showing intakes ${when}${r.includeOpen ? ", plus any still being worked on." : "."}`;
}
