import { cn } from "@/lib/utils";

/** Same look for toggles built from plain buttons (e.g. My tasks / All team tasks). */
export const segmentGroupClass = "inline-flex gap-1 rounded-lg border border-border bg-card p-1 shadow-sm";
export function segmentButtonClass(active: boolean) {
  return cn(
    "rounded-md px-5 py-2 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50",
    active ? "bg-primary text-primary-foreground shadow-sm" : "text-foreground/80 hover:bg-muted hover:text-foreground",
  );
}
