import { useQuery } from "@tanstack/react-query";
import { SharePointService } from "../../generated";
import type { BlobMetadata } from "../../generated/models/SharePointModel";
import { safeUrl } from "@/lib/safe-url";
import { DOCUMENT_LIBRARY_ID, SHAREPOINT_HOST, SITE_PATH, SITE_URL } from "@/config";

export { SITE_URL };
/** The site's "Documents" library. */
const LIBRARY_ID = DOCUMENT_LIBRARY_ID;
const LIBRARY_PATH = "Shared Documents";

/** Folder segments are request numbers or "Task-<id>"; keep only safe characters. */
function safeSegment(seg: string): string {
  return seg.replace(/[^A-Za-z0-9-]/g, "");
}

/** Library-relative folder path, e.g. "INT-20261013-00001" or "INT-20261013-00001/Task-12". */
function folderName(folder: string): string {
  return folder.split("/").map(safeSegment).filter(Boolean).join("/");
}

/** Folder for one task's files, inside its request's folder. */
export function taskFolder(requestNo: string, taskId: number): string {
  return `${requestNo}/Task-${taskId}`;
}

export function folderUrl(folder: string): string | undefined {
  const path = folderName(folder).split("/").map(encodeURIComponent).join("/");
  return safeUrl(`${SITE_URL}/${encodeURI(LIBRARY_PATH)}/${path}`);
}

export function fileUrl(f: BlobMetadata): string | undefined {
  if (!f.Path) return undefined;
  const path = f.Path.split("/").map((p) => encodeURIComponent(p)).join("/");
  return safeUrl(`https://${SHAREPOINT_HOST}${path.startsWith("/sites/") ? "" : SITE_PATH}${path}`);
}

async function getFolderId(folder: string): Promise<string | undefined> {
  const res = await SharePointService.GetFolderMetadataByPath(SITE_URL, `/${LIBRARY_PATH}/${folderName(folder)}`);
  if (!res.success) return undefined;
  return res.data?.Id;
}

/** Creates a folder (and any missing parent folders) if it does not exist yet. */
export async function ensureFolder(folder: string): Promise<void> {
  const segments = folderName(folder).split("/");
  for (let i = 1; i <= segments.length; i++) {
    const path = segments.slice(0, i).join("/");
    if (await getFolderId(path)) continue;
    const res = await SharePointService.CreateNewFolder(SITE_URL, LIBRARY_ID, { path });
    if (!res.success) {
      console.error("folder create failed", res.error);
      throw new Error("The file folder could not be created.");
    }
  }
}

/** Creates the request's file folder if it does not exist yet. */
export async function ensureRequestFolder(requestNo: string): Promise<void> {
  await ensureFolder(requestNo);
}

export type FolderState = { exists: false } | { exists: true; files: BlobMetadata[] };

export function useFolderFiles(folder: string | undefined) {
  return useQuery({
    queryKey: ["request-files", folder],
    enabled: !!folder,
    queryFn: async (): Promise<FolderState> => {
      const id = await getFolderId(folder as string);
      if (!id) return { exists: false };
      const res = await SharePointService.ListFolder(SITE_URL, id);
      if (!res.success) {
        console.error("folder list failed", res.error);
        throw new Error("Files could not be loaded.");
      }
      const payload: unknown = res.data;
      const rows = Array.isArray(payload)
        ? (payload as BlobMetadata[])
        : typeof payload === "object" && payload !== null && Array.isArray((payload as { value?: unknown }).value)
          ? ((payload as { value: BlobMetadata[] }).value)
          : null;
      if (rows === null) throw new Error("Unsupported folder response.");
      return { exists: true, files: rows.filter((f) => !f.IsFolder) };
    },
  });
}

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

/** Plain-text types the SharePoint connection can carry unchanged. */
export const TEXT_EXTENSIONS = [".txt", ".csv", ".json", ".md", ".xml", ".log", ".tsv"];

export function isTextFile(f: File): boolean {
  const n = f.name.toLowerCase();
  return TEXT_EXTENSIONS.some((ext) => n.endsWith(ext));
}

/** Keep the user's file name but drop characters SharePoint rejects. */
export function safeFileName(name: string): string {
  const cleaned = name.replace(/["*:<>?/\\|#%]/g, "_").replace(/^[\s.]+|[\s.]+$/g, "").trim();
  return cleaned || "file";
}

/**
 * Upload one plain-text file into the request's folder.
 * The connection only carries text bodies, so the file's text is sent as-is.
 * The stored size is checked afterwards; on a mismatch the copy is removed and an error raised.
 */
export async function uploadFolderFile(folder: string, file: File): Promise<void> {
  if (!isTextFile(file)) throw new Error(`${file.name} is not a plain-text file. Use Open folder in SharePoint for this file.`);
  if (file.size > MAX_UPLOAD_BYTES) throw new Error(`${file.name} is larger than 5 MB.`);
  await ensureFolder(folder);
  const text = await file.text();
  const expected = new TextEncoder().encode(text).length;
  const name = safeFileName(file.name);
  const res = await SharePointService.CreateFile(SITE_URL, `/${LIBRARY_PATH}/${folderName(folder)}`, name, text);
  if (!res.success) {
    console.error("file upload failed", res.error);
    throw new Error(`${file.name} could not be uploaded.`);
  }
  const stored = res.data?.Size;
  if (typeof stored === "number" && stored !== expected) {
    console.error("uploaded size mismatch", { expected, stored });
    if (res.data?.Id) {
      const del = await SharePointService.DeleteFile(SITE_URL, res.data.Id);
      if (!del.success) console.error("cleanup of bad upload failed", del.error);
    }
    throw new Error(`${file.name} was not stored correctly, so it was removed.`);
  }
}
