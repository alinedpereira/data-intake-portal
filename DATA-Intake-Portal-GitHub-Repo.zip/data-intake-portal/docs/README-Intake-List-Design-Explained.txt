==========================================================================
 D.A.T.A. INTAKE PORTAL - SHAREPOINT LIST DESIGN EXPLAINED
 How the lists work together, what each one is used for, and the pros
 and cons of the normalized (configuration-driven) design
 Rebuild target: Power Apps canvas app + SharePoint lists + Power Automate
==========================================================================

CONTENTS
  1. The short answer: where are type-specific answers stored?
  2. Worked example: a "Type A" request from start to finish
  3. What IntakeQuestions is for (and why it is separate from the rules)
  4. Every list explained: purpose, who writes, who reads, when used
  5. Pros of the normalized design
  6. Cons of the normalized design, and how to handle each one
  7. Rule of thumb: core column or question?
  8. How to add a new attribute without changing the app
  9. Build tips for the canvas app

--------------------------------------------------------------------------
1. THE SHORT ANSWER
--------------------------------------------------------------------------

IntakeRequests does NOT hold the type-specific or team-specific questions.

  - IntakeRequests holds only the fixed CORE fields every request has
    (ID, title, requestor, type, team, status, stage, priority, dates,
    assignee, score).
  - Every answer to a dynamic question (default, team-specific or
    type-specific) is saved as ITS OWN ROW in IntakeAnswers, linked to
    the request by RequestID.
  - Answers to questions the TEAM fills in (Audience = Internal) are
    saved the same way in IntakeInternalAnswers, so requestors never
    see them.

  In one line:
    IntakeQuestions      = WHAT a question is
    IntakeQuestionRules  = WHEN / WHERE it is asked
    IntakeAnswers        = WHAT the requestor answered
    IntakeInternalAnswers= WHAT the team answered

--------------------------------------------------------------------------
2. WORKED EXAMPLE: A "TYPE A" REQUEST
--------------------------------------------------------------------------

A requestor submits a "New Report" request (RequestTypeCode RPT-NEW,
Level1 RPT) that routes to Product Analytics (TeamCode PA).

Step 1 - The app finds which questions to show.
  It reads IntakeQuestionRules for rows where IsActive = Yes, today is
  between EffectiveFrom and EffectiveTo, and the scope matches.
  A blank scope value means "any":
     TeamCode         is blank OR PA
     Level1           is blank OR RPT
     RequestTypeCode  is blank OR RPT-NEW
  If two rules match the same question, the most specific one wins
  (Team = 4 points, RequestType = 2, Level1 = 1).

Step 2 - It gets each question's details from IntakeQuestions.
  Each rule points to a QuestionKey. IntakeQuestions supplies the label,
  answer type, choice list, help text and placeholder.

Step 3 - It shows the questions in ONE gallery.
  There are no hard-coded fields for these questions in the app.
  The gallery shows a text box, dropdown, date picker or toggle
  depending on the question's AnswerType.

Step 4 - On submit the app saves in two parts.

  IntakeRequests gets ONE row:
    ID 1042 | Title "Churn by region" | Requestor | RPT-NEW | PA |
    Status Submitted

  IntakeAnswers gets ONE ROW PER QUESTION ANSWERED:

    RequestID | QuestionKey         | QuestionText (copy)               | AnswerText
    ----------+---------------------+-----------------------------------+--------------------
    1042      | business_objective  | What is the business objective?   | Track churn by region
    1042      | business_impact     | Business impact                   | High
    1042      | report_frequency    | How often is the report needed?   | Weekly
    1042      | data_sources        | Which data sources?               | CRM, Billing

  The question text is copied into each answer row so the request still
  shows exactly what was asked, even if the question is reworded later.

--------------------------------------------------------------------------
3. WHAT INTAKEQUESTIONS IS FOR
--------------------------------------------------------------------------

IntakeQuestions is the QUESTION CATALOGUE. Each question is defined
once: key, label, answer type (Text, MultiLineText, Choice, MultiChoice,
Number, Date, YesNo), choices with points, help text and placeholder.

It does NOT decide where a question appears. IntakeQuestionRules does.
Keeping the two apart means:

  - Reuse: "business_objective" is defined once and applied to EVERY
    request through one rule with all scope fields blank.
  - Placement changes touch only rules: to also ask "data_sources" for
    the CA team, add one rule row. The question itself is unchanged.
  - Wording is fixed in one place and the change shows everywhere the
    question is used.
  - Retiring a question: set IsActive = No. Old answers keep their copy
    of the question text, so history is intact.

--------------------------------------------------------------------------
4. EVERY LIST EXPLAINED
--------------------------------------------------------------------------

A. CONFIGURATION LISTS
   Maintained by admins / managers, read by the app and flows.
   Changing them changes the app's behaviour with no app change.

IntakeTeams
  Purpose : The teams that can receive work: code, name, manager group,
            triage settings.
  Used for: Team dropdown, routing targets, dashboard filters, and the
            team folder for evidence files.
  Edited by: Admin.
  App use : Loaded once at app start into a collection.

IntakeRoleAssignments
  Purpose : Who is a Manager, Team Member (Assignee) or DMO approver,
            and for which team.
  Used for: The app decides which screens and buttons a user sees
            (e.g. Manager dashboard). Flows use it to find who to
            notify or assign. Adding a manager = adding a row.
  Edited by: Admin.
  App use : Read at app start to set the user's role(s).

IntakeRequestTypes
  Purpose : The request type menu (Level 1 -> Level 2).
  Used for: Each type sets its default team, whether to ask for a focus
            area, whether it needs approval, and its lifecycle.
            Adding a request type = adding a row.
  Edited by: Admin.
  App use : New Request screen; flows use it for routing.

IntakeQuestions
  Purpose : The question catalogue (see section 3).
  Edited by: Admin or form owner.
  App use : Loaded at app start.

IntakeQuestionRules
  Purpose : Decides which question appears for which team, category
            (Level1) and request type. Also sets required/optional,
            display order, audience (Requestor or Internal),
            show-only-if conditions (ShowIfKey / ShowIfValue),
            effective dates and scoring weight.
  Used for: THIS is where a new attribute is added without changing
            the app.
  Edited by: Admin or form owner.
  App use : Applied when the requestor picks a type or team.

B. TRANSACTION LISTS
   Written while requests are being worked.

IntakeRequests
  Purpose : The queue. One row per request with core fields only.
  Used for: My Requests, the Manager dashboard, request status shown to
            the requestor, routing and SLA tracking.
  Written by: Requestor (submit), Manager and flows (status, assignment,
            priority).
  Read by : Every screen.

IntakeAnswers
  Purpose : Requestor answers to dynamic questions, one row per answer.
  Used for: Request detail screen, scoring, edit / "ask the requestor".
  Written by: Requestor, through the app.
  Read by : Requestor (own requests) and team.

IntakeInternalAnswers
  Purpose : Team-only details such as effort estimate, data assessment
            and QA notes.
  Used for: Internal tab on the request detail screen. Kept separate so
            requestors can never see it.
  Written by: Team members and managers.
  Read by : Team only.

IntakeTasks
  Purpose : The work breakdown for a request.
  Used for: Manager creates and assigns tasks; team members update them.
            Drives "my work" for team members and progress on the
            dashboard.
  Written by: Manager, Team Member.
  Read by : Team; requestor sees a summary through a flow.

IntakeApprovals
  Purpose : One row per approval step (DMO, DML, requestor sign-off):
            approver, decision, date, comments.
  Used for: The audit record of every approval, in one place.
  Written by: A flow creates the row; the approver records the decision.
  Read by : Everyone involved in the request.

IntakeActivity
  Purpose : Audit trail and conversation: status changes,
            "ask the requestor" questions and replies, comments.
  Used for: The timeline on the request detail screen. Answers
            "what happened and when".
  Written by: Mostly flows, plus the app for comments.
  Read by : Requestor (shared entries) and team.

IntakeEvidence (document library)
  Purpose : Every file for the request in one folder per request,
            for example /INT-001042/Shared and /INT-001042/Internal.
  Used for: Requestor attachments (Shared) and team evidence
            (Shared or Internal).
  Written by: Requestor (attachments), team (evidence).
  Read by : Requestor sees Shared; team sees both. A flow grants the
            requestor read access on the Shared folder.

--------------------------------------------------------------------------
5. PROS OF THE NORMALIZED DESIGN
--------------------------------------------------------------------------

Managing change
  A new question is two rows (one question + one rule) and is live
  immediately. No app change, no republish. This was the main
  requirement.

Scale of attributes
  IntakeRequests does not grow to 150+ columns. SharePoint limits
  columns, row size and lookups per view; a wide list hits them fast.

Reuse and consistency
  Questions shared across teams are defined once, so wording and
  choices stay the same everywhere.

History
  Answers keep a copy of the question text and config rows are retired
  (IsActive = No) instead of deleted, so old requests still show
  exactly what was asked.

Security
  Requestor answers, internal answers and internal files sit in
  separate lists/folders. Permissions stay simple; no per-column
  workarounds (SharePoint has no column-level security).

Simpler app
  One gallery-based form serves every team and type, instead of a
  separate form or screen per team.

Performance
  IntakeRequests stays narrow, so dashboard and My Requests galleries
  load fast. Answers load only when a request is opened.

--------------------------------------------------------------------------
6. CONS, AND HOW TO HANDLE EACH ONE
--------------------------------------------------------------------------

Reporting is harder
  Why : Answers are rows, not columns. A SharePoint view or Excel export
        cannot show "Request + Frequency + Data Sources" side by side.
  Fix : Use Power BI to pivot answers into columns, or have a flow write
        a readable AnswersSummary (multi-line text) onto the request.

Filtering requests by an answer
  Why : "All requests where regulatory_driver = Yes" needs a query on
        IntakeAnswers first, then a match back to requests.
  Fix : PROMOTION RULE - if you filter, sort or report on an attribute
        often, make it a core column on IntakeRequests.

Submitting writes many rows
  Why : One request row plus several answer rows. If the connection
        drops midway, a request can exist with only some answers.
  Fix : Save the request as Draft, write the answers, then set Status to
        Submitted. Or send the whole package to a flow that writes it.

IntakeAnswers grows fast
  Why : ~15 answers per request x 1,000 requests = ~15,000 rows, past
        the 5,000-item list view threshold.
  Fix : Index RequestID and QuestionKey from day one, before data
        arrives. Always filter by RequestID (an equality filter on a
        number column is delegable from Power Apps).

Weaker data typing
  Why : Answers are stored as text, so number/date checks are not
        enforced by SharePoint.
  Fix : Store AnswerType on each answer, validate in the app, and use
        AnswerNumber / AnswerDate columns where reports need them.

Configuration mistakes reach users
  Why : A wrong rule (bad code, missing Required flag) changes the live
        form immediately.
  Fix : Restrict edit rights on config lists, use a "TEST" team or a
        future EffectiveFrom date to trial rules, and keep an admin view
        that flags rules pointing to missing questions.

More lists to look after
  Why : 11 lists plus a library means more permissions, indexes and
        backups.
  Fix : Create them with a provisioning script and name an owner for
        each list.

Less friendly in plain SharePoint
  Why : Users editing in the SharePoint grid cannot see all fields of a
        request together.
  Fix : Treat the app as the front end and the lists as the back end.

App design work
  Why : The canvas app must filter rules and look up questions
        (an in-app join).
  Fix : Load config lists once at app start into collections and join
        in memory. They are small, so it is fast.

--------------------------------------------------------------------------
7. RULE OF THUMB: CORE COLUMN OR QUESTION?
--------------------------------------------------------------------------

  CORE COLUMN on IntakeRequests if the attribute
    - applies to EVERY request, AND
    - you filter, sort, route, secure or build dashboards on it.
    Examples: Status, TeamCode, Priority, DueDate, AssignedToEmail.

  QUESTION (IntakeQuestions + IntakeQuestionRules) for everything else,
  especially anything type- or team-specific or likely to change.
    Examples: report frequency, data sources, regulatory reference.

  This keeps the queue fast and reportable while most of what you
  capture stays editable without an app change.

--------------------------------------------------------------------------
8. HOW TO ADD A NEW ATTRIBUTE WITHOUT CHANGING THE APP
--------------------------------------------------------------------------

  Example: CA team wants "Target customer segment" (choice) on every
  CA request.

  1. IntakeQuestions - add a row:
       QuestionKey  = target_segment
       QuestionText = Target customer segment
       AnswerType   = Choice
       ChoiceOptions= Retail|0;Small Business|0;Enterprise|0
       IsActive     = Yes

  2. IntakeQuestionRules - add a row:
       QuestionKey     = target_segment
       TeamCode        = CA
       Level1          = (blank)
       RequestTypeCode = (blank)
       Audience        = Requestor
       IsRequired      = Yes
       SortOrder       = 40
       IsActive        = Yes

  3. Done. The next CA request shows the question; answers land in
     IntakeAnswers. No app edit, no publish.

  Other variations:
    - For ONE request type only : fill RequestTypeCode instead of TeamCode.
    - For ALL requests          : leave all three scope fields blank.
    - Only if another answer    : set ShowIfKey / ShowIfValue.
    - Team-only (internal)      : Audience = Internal (saved to
                                  IntakeInternalAnswers).
    - Retire it                 : IsActive = No or set EffectiveTo.

--------------------------------------------------------------------------
9. BUILD TIPS FOR THE CANVAS APP
--------------------------------------------------------------------------

  - App.OnStart / named formulas: load IntakeTeams, IntakeRequestTypes,
    IntakeQuestions, IntakeQuestionRules and the user's
    IntakeRoleAssignments into collections once.
  - Filter rules in memory for the chosen type/team, pick the most
    specific rule per QuestionKey, then add question details with
    AddColumns + LookUp against the questions collection.
  - Render with ONE gallery; show a text input, dropdown, date picker or
    toggle based on AnswerType.
  - Submit: Patch the request as Draft -> ForAll Patch answers with the
    new ID -> Patch Status = Submitted (or hand all of it to a flow).
  - Request detail: Filter(IntakeAnswers, RequestID = ThisRequest.ID).
  - Set the app's data row limit to 2000 and index the columns marked in
    the column definitions file before lists reach 5,000 items.
  - Let flows handle notifications, approvals, folder creation and
    permissions; keep the app focused on capture and display.

==========================================================================
 End of document
==========================================================================
