# S04 – My Intakes (requestor)

**Wireframe:** `W04-my-intakes.png`  **Original reference:** `R04-my-intakes-design.png`
**Depends on:** S01

## Goal
The requestor's intakes in a table with a status filter; work-package intakes show "x of y work packages accepted".

## Controls
| Control | Type | Key properties |
|---|---|---|
| lblHeading | Label | `"My Intakes (" & CountRows(galMyIntakes.AllItems) & ")"` |
| drpStatusFilter | Dropdown | `["All statuses", "Open", "Waiting on me", "Closed"]` |
| galMyIntakes | Vertical gallery styled as a table | Columns: Intake #, Title, Priority, Status (pill), Owner, Work packages |

## Formulas
```
// galMyIntakes.Items
With({mine: Filter(IntakeRequests, Requestor.Email = User().Email)},
  SortByColumns(
    Switch(drpStatusFilter.Selected.Value,
      "Open", Filter(mine, Status.Value <> "Closed"),
      "Waiting on me", Filter(mine, Status.Value = "Requirements sign-off" || Status.Value = "Acceptance sign-off" || AwaitingRequestor),
      "Closed", Filter(mine, Status.Value = "Closed"),
      mine),
    "Created", SortOrder.Descending))

// Work packages cell (only for rows that have packages)
With({wps: Filter(IntakeWorkPackages, RequestItemId = ThisItem.ID)},
  If(IsEmpty(wps), "", CountRows(Filter(wps, WPStatus.Value = "Accepted")) & " of " & CountRows(wps) & " work packages accepted"))

// galMyIntakes.OnSelect
Set(varIntake, ThisItem); Navigate(scrIntakeDetail)
```

## Acceptance checks
- Only the signed-in requestor's intakes appear; filters work; "Waiting on me" lists sign-off stages and open questions.
- INT-…-00037 shows "1 of 3 work packages accepted" (POC seed data).

## Prompt to paste
```
Build scrMyIntakes (S04) to match wireframe W04 and reference R04: heading with count, status filter dropdown, and a table-style
gallery galMyIntakes with Intake #, Title, Priority, Status pill, Owner and a work-package summary. Use the formulas in
02-prompts/S04 and keep every filter delegable. Then run the acceptance checks.
```
